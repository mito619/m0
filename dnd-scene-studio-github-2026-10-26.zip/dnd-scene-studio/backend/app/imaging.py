"""Работа с пикселями: чистка масок, вырезание спрайтов, сборка сцены."""
import io

import cv2, numpy as np
from PIL import Image


def png_bytes(img: Image.Image | np.ndarray) -> bytes:
    if isinstance(img, np.ndarray):
        img = Image.fromarray(img)
    buf = io.BytesIO(); img.save(buf, "PNG"); return buf.getvalue()


def to_rgb(png: bytes) -> np.ndarray:
    return np.array(Image.open(io.BytesIO(png)).convert("RGB"))


def clean_mask(mask: np.ndarray, pos_points=(), min_frac: float = 0.0) -> np.ndarray:
    """Маска SAM -> аккуратная маска объекта: одна связная область, без мелких дыр и «песка», гладкий край."""
    h, w = mask.shape
    m = (mask > 127).astype(np.uint8)
    n, lab = cv2.connectedComponents(m, connectivity=8)
    if n > 2:  # оставляем компоненты под положительными точками, иначе самую большую
        keep = {int(lab[y, x]) for x, y in pos_points if 0 <= x < w and 0 <= y < h} - {0}
        if not keep:
            sizes = np.bincount(lab.ravel())[1:]; keep = {int(sizes.argmax()) + 1}
            if min_frac > 0:  # крупные отдельные части (сапоги под юбкой, оружие) тоже остаются
                keep |= {i + 1 for i, a in enumerate(sizes) if a >= min_frac * sizes.max()}
        m = np.isin(lab, list(keep)).astype(np.uint8)
    area = int(m.sum())
    if area:  # закрываем небольшие дыры внутри (но не настоящие просветы вроде спинки стула)
        n, lab, stats, _ = cv2.connectedComponentsWithStats(1 - m, connectivity=4)
        limit = max(64, int(area * 0.01))
        for i in range(1, n):
            x, y, ww, hh, a = stats[i]
            touches = x == 0 or y == 0 or x + ww == w or y + hh == h
            if not touches and a < limit:
                m[lab == i] = 1
    m = cv2.medianBlur(m * 255, 5)
    return (m > 127).astype(np.uint8) * 255


def bbox(mask: np.ndarray):
    ys, xs = np.where(mask > 0)
    if len(xs) == 0:
        return None
    return int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1


def overlay(mask: np.ndarray) -> Image.Image:
    """Полупрозрачная заливка + контур для предпросмотра выделения."""
    fill = mask > 0
    edge = fill & ~(cv2.erode(mask, np.ones((3, 3), np.uint8), iterations=2) > 0)
    out = np.zeros((*mask.shape, 4), np.uint8)
    out[fill] = (74, 154, 140, 105)
    out[edge] = (235, 200, 110, 255)
    return Image.fromarray(out, "RGBA")


def clean_alpha(mask: np.ndarray) -> np.ndarray:
    """Keep the model's soft edge and real gaps; discard only detached specks."""
    alpha = np.clip(mask, 0, 255).astype(np.uint8).copy()
    alpha[alpha <= 8] = 0
    n, labels, stats, _ = cv2.connectedComponentsWithStats((alpha > 0).astype(np.uint8), connectivity=8)
    if n > 1:
        areas = stats[1:, cv2.CC_STAT_AREA]
        minimum = max(8, int(areas.max() * .001))
        keep = np.flatnonzero(areas >= minimum) + 1
        alpha[~np.isin(labels, keep)] = 0
    return alpha


def cut_sprite(rgb: np.ndarray, mask: np.ndarray, feather: int = 5, preserve_soft: bool = False):
    """RGBA-спрайт по маске. Край чуть поджимаем, чтобы не тянуть фоновый ореол."""
    x0, y0, x1, y1 = bbox(mask)
    alpha = mask if preserve_soft else cv2.GaussianBlur(cv2.erode(mask, np.ones((3, 3), np.uint8)), (feather, feather), 0)
    return np.dstack([rgb, alpha])[y0:y1, x0:x1], (x0, y0, x1, y1)


def hole_mask(mask: np.ndarray) -> np.ndarray:
    """Область для inpaint: маска + запас на ореол и тень по краю."""
    k = max(7, int(0.012 * max(mask.shape))) | 1
    return cv2.dilate(mask, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))


def composite_outside(original: np.ndarray, inpainted: np.ndarray, hole: np.ndarray) -> np.ndarray:
    """Вне дыры берём оригинал побайтно: inpaint не имеет права менять остальную картинку."""
    soft = (cv2.GaussianBlur(hole, (7, 7), 0).astype(np.float32) / 255)[..., None]
    return (inpainted * soft + original * (1 - soft)).astype(np.uint8)


def flip_png(path_in, path_out) -> None:
    Image.open(path_in).transpose(Image.FLIP_LEFT_RIGHT).save(path_out)


def place_layer(canvas_wh: tuple[int, int], sprite: Image.Image, l: dict) -> np.ndarray:
    """Слой на полотне сцены (float RGBA 0..1) с масштабом и поворотом вокруг левого верхнего угла, как в Konva."""
    W, H = canvas_wh
    sw, sh = sprite.size
    a = np.deg2rad(l.get("rotation", 0)); c, s = np.cos(a), np.sin(a)
    sx, sy = l["width"] / sw, l["height"] / sh
    linear = np.array([[c * sx, -s * sy], [s * sx, c * sy]], np.float32)
    # Pixel centers, matching a canvas drawImage whose geometry uses edges.
    translation = np.array([l["x"], l["y"]], np.float32) + linear @ np.array([.5, .5], np.float32) - .5
    arr = np.asarray(sprite.convert("RGBA"), dtype=np.float32) / 255
    arr[..., :3] *= arr[..., 3:4]
    # warpAffine's INTER_AREA is not a true area reduction. Prefilter on the
    # source grid so fingers, strings and soft alpha survive downsampling.
    rw, rh = max(1, round(sw * min(1., sx))), max(1, round(sh * min(1., sy)))
    if rw != sw or rh != sh:
        reduction = np.array([rw / sw, rh / sh], np.float32)
        arr = cv2.resize(arr, (rw, rh), interpolation=cv2.INTER_AREA)
        translation += linear @ (.5 / reduction - .5)
        linear = linear / reduction[None, :]
    M = np.column_stack([linear, translation])
    out = cv2.warpAffine(arr, M, (W, H), flags=cv2.INTER_LINEAR,
                         borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
    return np.clip(out, 0, 1)


def compose(bg: Image.Image, layers: list[tuple[dict, Image.Image]]) -> Image.Image:
    """Склейка фона и видимых слоёв снизу вверх."""
    canvas = np.array(bg.convert("RGB")).astype(np.float32) / 255
    for l, sp in layers:
        pm = place_layer(bg.size, sp, l)  # premultiplied
        canvas = pm[..., :3] + canvas * (1 - pm[..., 3:4])
    return Image.fromarray((np.clip(canvas, 0, 1) * 255).astype(np.uint8))


def layer_on_canvas(canvas_wh, sprite: Image.Image, l: dict) -> Image.Image:
    pm = place_layer(canvas_wh, sprite, l)
    a = pm[..., 3:4]
    rgb = np.where(a > 1e-4, pm[..., :3] / np.maximum(a, 1e-4), 0)
    return Image.fromarray((np.clip(np.dstack([rgb, a]), 0, 1) * 255).astype(np.uint8), "RGBA")


def blend_sprite(sprite: np.ndarray, bg: np.ndarray, box, strength: float = .85):
    """Вписывает спрайт в сцену без нейросети: подгоняет свет и цвет под фон вокруг места, где он стоит,
    и добавляет контактную тень под ногами. sprite RGBA (оригинал), bg RGB, box = (x, y, w, h) на сцене.
    Возвращает (RGBA с тенью, поля (left, top, right, bottom) в пикселях спрайта)."""
    H, W = bg.shape[:2]; x, y, w, h = box
    mx, my = w * .5, h * .3
    x0, y0, x1, y1 = max(0, int(x - mx)), max(0, int(y - my)), min(W, int(x + w + mx)), min(H, int(y + h + my))
    region = bg[y0:y1, x0:x1] if (x1 - x0 > 8 and y1 - y0 > 8) else bg
    rgb, a = sprite[..., :3], sprite[..., 3]
    sh, sw = a.shape

    solid = a > 200
    if solid.sum() > 100:  # перенос статистики в Lab: яркость сильнее, оттенок мягче
        ls = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB).astype(np.float32)
        lt = cv2.cvtColor(np.ascontiguousarray(region), cv2.COLOR_RGB2LAB).astype(np.float32).reshape(-1, 3)
        ms, ss = ls[solid].mean(0), ls[solid].std(0) + 1e-3
        mt, st = lt.mean(0), lt.std(0) + 1e-3
        k = float(np.clip(st[0] / ss[0], .75, 1.2))
        dL = float(np.clip(mt[0] - ms[0], -45, 30))
        out = ls.copy()
        out[..., 0] = ls[..., 0] + strength * (((ls[..., 0] - ms[0]) * k + ms[0] + dL) - ls[..., 0])
        out[..., 1:] = ls[..., 1:] + strength * .7 * (mt[1:] - ms[1:])
        rgb = cv2.cvtColor(np.clip(out, 0, 255).astype(np.uint8), cv2.COLOR_LAB2RGB)

    rows = np.where((a > 128).any(1))[0]
    if len(rows) == 0:
        return np.dstack([rgb, a]), (0, 0, 0, 0)
    bottom = int(rows.max())
    band = np.where(a[max(0, bottom - max(2, int(sh * .06))):bottom + 1] > 128)[1]
    fx0, fx1 = int(band.min()), int(band.max()) + 1
    cx, rx = (fx0 + fx1) / 2, max((fx1 - fx0) * .75, sw * .12); ry = rx * .22
    pl = pr = int(max(0, rx - min(cx, sw - cx)) + 10); pb = int(ry * 1.5 + 6)

    Hc, Wc = sh + pb, sw + pl + pr
    sha = np.zeros((Hc, Wc), np.float32)
    cv2.ellipse(sha, (int(pl + cx), bottom), (int(rx), max(1, int(ry))), 0, 0, 360, 1.0, -1)
    sig = max(2.0, ry * .5)
    sha = cv2.GaussianBlur(sha, (0, 0), sig) * .7
    tint = (region.reshape(-1, 3).mean(0) * .12).astype(np.float32)

    sa = np.zeros((Hc, Wc), np.float32); sa[:sh, pl:pl + sw] = a / 255.0
    srgb = np.zeros((Hc, Wc, 3), np.float32); srgb[:sh, pl:pl + sw] = rgb
    oa = sa + sha * (1 - sa)
    orgb = (srgb * sa[..., None] + tint * (sha * (1 - sa))[..., None]) / np.maximum(oa, 1e-4)[..., None]
    res = np.dstack([np.clip(orgb, 0, 255), np.clip(oa, 0, 1) * 255]).astype(np.uint8)
    return res, (pl, 0, pr, pb)


def refine_isolated(rgb: np.ndarray, sam_mask: np.ndarray) -> np.ndarray:
    """Предмет/персонаж на однотонном фоне: к маске SAM добавляем всё, что отличается от фона и касается её
    (лютня, посох, кружка в руках), потому что SAM такие мелкие предметы часто теряет."""
    lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB).astype(np.float32)
    bgc = np.median(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]), 0)
    fg = cv2.morphologyEx((np.linalg.norm(lab - bgc, axis=2) > 28).astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    base = (sam_mask > 0).astype(np.uint8)
    near = cv2.dilate(base, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (41, 41)))
    _, cc = cv2.connectedComponents(fg, connectivity=8)
    keep = np.unique(cc[(near > 0) & (fg > 0)]); keep = keep[keep > 0]
    extra = np.isin(cc, keep).astype(np.uint8)
    if extra.sum() > 2.2 * max(1, base.sum()):  # фон оказался неоднотонным: не рискуем, оставляем маску SAM
        return base * 255
    return np.maximum(extra, base) * 255


def recover_body(rgb: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Модель удаления фона иногда съедает тёмные части (штаны, плащ) на однотонном фоне. Достраиваем: всё, что заметно
    отличается от фона и крупное, добавляется к маске, если лежит в горизонтальных границах персонажа."""
    lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB).astype(np.float32)
    bgc = np.median(np.concatenate([lab[:6].reshape(-1, 3), lab[-6:].reshape(-1, 3), lab[:, :6].reshape(-1, 3), lab[:, -6:].reshape(-1, 3)]), 0)
    fg = cv2.morphologyEx((np.linalg.norm(lab - bgc, axis=2) > 22).astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    base = (mask > 127).astype(np.uint8)
    if base.sum() == 0:
        return mask
    xs = np.where(base.any(0))[0]; x0, x1 = xs.min(), xs.max()
    mx = int(.08 * (x1 - x0))
    n, cc, st, _ = cv2.connectedComponentsWithStats(fg, connectivity=8)
    near = cv2.dilate(base, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (41, 41)))
    out = base.copy(); big = base.sum()
    for i in range(1, n):
        x, y, w, h, a = st[i]
        inside = x >= x0 - mx and x + w <= x1 + mx
        if a > .015 * big and inside and ((near[cc == i] > 0).any() or a > .06 * big):
            out |= (cc == i).astype(np.uint8)
    if out.sum() > 1.8 * big:  # фон оказался неоднотонным: не рискуем
        return mask
    # пустоты между частями по вертикали (торс -> сапоги) закрываем
    out = cv2.morphologyEx(out, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (3, max(9, int(.05 * mask.shape[0])))))
    return out * 255


def integrated_scene(bg: Image.Image, layers):
    """Relight intact foreground pixels and anchor shadows to actual opaque feet."""
    background = np.array(bg.convert("RGB"))
    height, width = background.shape[:2]
    canvas = background.astype(np.float32)
    silhouette = np.zeros((height, width), np.uint8)
    ground = np.zeros((height, width), np.float32)
    light = cv2.GaussianBlur(cv2.cvtColor(background, cv2.COLOR_RGB2GRAY).astype(np.float32), (0, 0), max(12, width * .025))
    _, _, _, source = cv2.minMaxLoc(light)
    for layer, sprite in layers:
        pm = place_layer(bg.size, sprite, layer)
        alpha = pm[..., 3]
        support = alpha > 1e-6
        solid = alpha > .5
        box = bbox(support)
        if box is None:
            continue
        x0, y0, x1, y1 = box
        bw, bh = x1 - x0, y1 - y0
        margin = max(12, bw // 2)
        region = background[max(0, y0 - margin):min(height, y1 + margin), max(0, x0 - margin):min(width, x1 + margin)]
        rgb = np.clip(pm[..., :3] / np.maximum(alpha[..., None], 1e-6), 0, 1)
        lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB)
        target = cv2.cvtColor(np.ascontiguousarray(region, dtype=np.float32) / 255, cv2.COLOR_RGB2LAB).reshape(-1, 3)
        body = solid if solid.any() else support
        source_l = max(1, float(np.percentile(lab[..., 0][body], 65)))
        target_l = float(np.percentile(target[:, 0], 70))
        gain = float(np.clip(target_l / source_l, .48, 1.08) ** .8)
        direction = 1 if source[0] < (x0 + x1) / 2 else -1
        side = np.clip(((x0 + x1) / 2 - np.arange(width)) / max(1, bw / 2), -1, 1)
        lab[..., 0] *= gain * (1 + .16 * direction * side[None, :])
        # Add the local light cast without neutralising the garment's own hue.
        cast = np.clip(np.median(target[:, 1:], axis=0), -24, 24)
        lab[..., 1:] += cast * .45
        lab[..., 0] = np.clip(lab[..., 0], 0, 100)
        lab[..., 1:] = np.clip(lab[..., 1:], -128, 127)
        rgb = np.clip(cv2.cvtColor(lab, cv2.COLOR_LAB2RGB), 0, 1) * 255

        contact = np.zeros_like(ground)
        # Both soles get contact even when perspective puts them at different y.
        for x in range(x0, x1):
            ys = np.flatnonzero(solid[:, x])
            if len(ys) and ys[-1] >= y1 - max(3, int(bh * .16)):
                cv2.ellipse(contact, (x, int(ys[-1]) + 1), (2, 2), 0, 0, 360, 1., -1)
        contact = cv2.GaussianBlur(contact, (0, 0), 1.4)

        # Cast away from the brightest broad light source, not from the padded box.
        stretch = .32 * direction
        bottom = float(y1 - 1)
        transform = np.float32([[1, -stretch, stretch * bottom], [0, -.10, 1.10 * bottom]])
        cast_shadow = cv2.warpAffine(solid.astype(np.float32), transform, (width, height))
        cast_shadow = cv2.GaussianBlur(cast_shadow, (0, 0), max(2, bw * .045))
        shade = np.clip(contact * .52 + cast_shadow * .22, 0, .65)
        shade[silhouette > 0] = 0
        canvas *= (1 - shade[..., None])
        canvas = rgb * alpha[..., None] + canvas * (1 - alpha[..., None])
        silhouette[support] = 255
        ground = np.maximum(ground, shade)
    return Image.fromarray(np.clip(canvas, 0, 255).astype(np.uint8)), silhouette, (ground > .015).astype(np.uint8) * 255


def harmonize_compose(comp: np.ndarray, out: np.ndarray, sil: np.ndarray, ring: np.ndarray) -> np.ndarray:
    """Use neural output only at the seam and shadow; preserve the relit subject and distant scenery."""
    # Whole-body illumination is already matched by integrated_scene. Diffusion
    # may refine the seam and ground, but must not repaint the face or costume.
    protected = cv2.dilate(sil, np.ones((3, 3), np.uint8)) > 0
    weight = cv2.GaussianBlur((ring > 0).astype(np.float32), (0, 0), 1.2) * .35
    weight[protected] = 0
    weight[cv2.dilate(ring, np.ones((9, 9), np.uint8)) == 0] = 0
    return np.clip(comp.astype(np.float32) * (1 - weight[..., None]) + out.astype(np.float32) * weight[..., None], 0, 255).astype(np.uint8)


