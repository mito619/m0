import io, random, threading, zipfile
from typing import Literal

import cv2, numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from fastapi.staticfiles import StaticFiles
from PIL import Image
from pydantic import BaseModel, Field

from . import imaging as im, scenes as sc
from . import poses
from .rig import RAN as RAN_, LAN as LAN_, RHIP as RHIP_, LHIP as LHIP_
from .prompts import PLACE_AVOID, PLACE_HINT, guess_place, lighting_hint, strip_empty, wants_people
from .worker_client import Holder

app = FastAPI(title="DnD Scene Studio")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
                   allow_methods=["*"], allow_headers=["*"])
app.mount("/files", StaticFiles(directory=sc.DATA), name="files")
holder = Holder(sc.DATA)
LOCK = threading.RLock()  # операции, меняющие сцену, идут строго по очереди (один пользователь, одна GPU)

SPRITE_SIZE = {"character": (768, 1024), "object": (832, 832)}
SPRITE_HEIGHT = {"character": .38, "object": .25}  # доля высоты сцены для нового спрайта
Kind = Literal["character", "object"]


# ───────────── модели запросов ─────────────
class GenReq(BaseModel):
    prompt: str = Field(min_length=1, max_length=1000)
    width: int = Field(1024, ge=256, le=1536)
    height: int = Field(768, ge=256, le=1536)
    seed: int | None = None
    place: Literal["auto", "inside", "outside"] = "auto"  # где происходит сцена
    people: Literal["auto", "yes", "no"] = "auto"  # персонажи в сцене: по тексту / да / нет


class Pt(BaseModel):
    x: int
    y: int
    label: Literal[0, 1] = 1  # 1 = «это объект», 0 = «это не он»


class SegReq(BaseModel):
    points: list[Pt] = Field(min_length=1, max_length=12)


class ExtractReq(BaseModel):
    mask_id: str


class SpriteReq(BaseModel):
    prompt: str = Field(min_length=1, max_length=1000)
    seed: int | None = None
    kind: Kind = "character"


class WorkerReq(BaseModel):
    url: str
    token: str = ""


class StateReq(BaseModel):
    layers: list[dict]


# ───────────── служебные ─────────────
@app.get("/api/health")
def health():
    return {"ok": True, "worker": holder.worker.status()}


@app.post("/api/worker")
def connect_worker(req: WorkerReq):
    return holder.connect(req.url, req.token)


@app.delete("/api/worker")
def disconnect_worker():
    holder.disconnect(); return holder.worker.status()


# ───────────── генерация сцены ─────────────
@app.post("/api/scenes")
def generate(req: GenReq):
    with LOCK:
        with_people = req.people == "yes" or (req.people == "auto" and wants_people(req.prompt))
        place = req.place if req.place != "auto" else guess_place(req.prompt)
        png = holder.worker.generate(strip_empty(req.prompt) if with_people else req.prompt, req.width, req.height, req.seed,
                                     "scene_people" if with_people else "scene", PLACE_HINT.get(place, ""), PLACE_AVOID.get(place, ""))
        p, m = sc.create(req.prompt, req.seed, "bg_0.png")
        (p / "bg_0.png").write_bytes(png)
        m["prompt_en"] = getattr(holder.worker, "last_prompt", None); sc._write(p, "scene.json", m)
        return sc.view(p, m)


@app.get("/api/scenes/{sid}")
def get_scene(sid: str):
    p = sc.sdir(sid); return sc.view(p, sc.load(p))


@app.get("/api/scenes")
def saved_scenes():
    files = sorted(sc.DATA.glob("*/scene.json"), key=lambda path: path.stat().st_mtime, reverse=True)
    return {"scenes": [sc.view(path.parent, sc.load(path.parent)) for path in files]}


# ───────────── выбор объекта: предпросмотр -> подтверждение ─────────────
@app.post("/api/scenes/{sid}/segment")
def segment(sid: str, req: SegReq):
    """Предпросмотр: ничего не меняет в сцене. Возвращает подсветку маски и её id для /extract."""
    p = sc.sdir(sid); m = sc.load(p)
    png = (p / m["bg"]).read_bytes()
    h, w = im.to_rgb(png).shape[:2]
    for pt in req.points:
        if not (0 <= pt.x < w and 0 <= pt.y < h):
            raise HTTPException(400, "Клик вне изображения")
    pos = [(pt.x, pt.y) for pt in req.points if pt.label == 1]
    if not pos:
        raise HTTPException(400, "Нужна хотя бы одна точка «это объект»")

    mask = holder.worker.segment(png, [(pt.x, pt.y) for pt in req.points], [pt.label for pt in req.points])
    if mask.shape != (h, w):
        mask = cv2.resize(mask, (w, h), interpolation=cv2.INTER_NEAREST)
    mask = im.clean_mask(mask, pos)
    box = im.bbox(mask)
    if box is None or int((mask > 0).sum()) < 50:
        raise HTTPException(422, "Объект не найден, кликните точнее")

    mid = sc.new_id()
    md = p / "masks"; md.mkdir(exist_ok=True)
    Image.fromarray(mask).save(md / f"{mid}.png"); im.overlay(mask).save(md / f"{mid}_ov.png")
    for old in sorted(md.glob("*.png"), key=lambda f: f.stat().st_mtime)[:-16]:  # не копим мусор
        old.unlink(missing_ok=True)
    return {"mask_id": mid, "preview_url": f"/files/{sid}/masks/{mid}_ov.png", "bbox": box,
            "area_pct": round(100 * float((mask > 0).mean()), 1)}


@app.post("/api/scenes/{sid}/extract")
def extract(sid: str, req: ExtractReq):
    """Подтверждение: вырезаем спрайт и зачищаем фон под ним (LaMa на воркере)."""
    with LOCK:
        p = sc.sdir(sid); m = sc.load(p)
        mf = p / "masks" / f"{req.mask_id}.png"
        if not req.mask_id.isalnum() or not mf.exists():
            raise HTTPException(404, "Выделение устарело, выберите объект заново")
        mask = np.array(Image.open(mf).convert("L"))
        png = (p / m["bg"]).read_bytes(); rgb = im.to_rgb(png)
        if mask.shape != rgb.shape[:2]:
            raise HTTPException(409, "Фон изменился, выберите объект заново")

        sprite, (x0, y0, x1, y1) = im.cut_sprite(rgb, mask)
        hole = im.hole_mask(mask)
        clean = im.composite_outside(rgb, im.to_rgb(holder.worker.inpaint(png, hole)), hole)

        lid = sc.new_id(); ver = len(list(p.glob("bg_*.png")))
        Image.fromarray(sprite, "RGBA").save(p / f"layer_{lid}.png")
        Image.fromarray(clean).save(p / f"bg_{ver}.png"); m["bg"] = f"bg_{ver}.png"
        m["layers"].append({"id": lid, "src": f"layer_{lid}.png", "x": x0, "y": y0, "width": x1 - x0,
                            "height": y1 - y0, "rotation": 0, "visible": True,
                            "name": f"Объект {len(m['layers']) + 1}"})
        mf.unlink(missing_ok=True); (p / "masks" / f"{req.mask_id}_ov.png").unlink(missing_ok=True)
        return sc.view(p, sc.commit(p, m))


# ───────────── новые спрайты: добавить / заменить ─────────────
def new_sprite(prompt: str, seed: int | None, kind: str, hint: str = "", skeleton: bytes | None = None, ref: bytes | None = None, ip_scale: float = .6) -> np.ndarray:
    """Генерируем объект на нейтральном фоне (с позой, если передан скелет) и отделяем фон. Возвращает RGBA."""
    w, h = SPRITE_SIZE[kind]
    png = holder.worker.pose(prompt, seed, skeleton, hint, ref, ip_scale) if skeleton else holder.worker.generate(prompt, w, h, seed, kind, hint)
    return cutout_sprite(png, kind)


def cutout_sprite(png: bytes, kind: str) -> np.ndarray:
    """Apply the same matte pipeline to generated and edited characters."""
    rgb = im.to_rgb(png); h, w = rgb.shape[:2]
    mask = holder.worker.matte(png)  # основной путь: модель удаления фона (держит и предметы в руках)
    soft_mask = mask is not None
    if mask is None:  # запасной: SAM по рамке + добор предметов
        box = (int(w * .04), int(h * .03), int(w * .96), int(h * .97))
        mask = holder.worker.segment(png, [], [], box)
        if mask.shape != (h, w):
            mask = cv2.resize(mask, (w, h), interpolation=cv2.INTER_NEAREST)
        mask = im.refine_isolated(rgb, mask)
    if mask.shape != (h, w):
        mask = cv2.resize(mask, (w, h), interpolation=cv2.INTER_NEAREST)
    if kind == "character" and not soft_mask:
        mask = im.recover_body(rgb, mask)
    mask = im.clean_alpha(mask) if soft_mask else im.clean_mask((mask > 127).astype(np.uint8) * 255, min_frac=.04 if kind == "character" else 0)
    cover = float((mask > 0).mean())
    if cover < .02 or cover > .6:  # вырезался весь кадр или почти ничего: не вставляем «серый прямоугольник»
        raise HTTPException(422, "Фон не отделился от персонажа. Попробуйте ещё раз (или другое описание).")
    return im.cut_sprite(rgb, mask, feather=3, preserve_soft=soft_mask)[0]


@app.post("/api/scenes/{sid}/characters")
def add_sprite(sid: str, req: SpriteReq):
    with LOCK:
        p = sc.sdir(sid); m = sc.load(p)
        W, H = Image.open(p / m["bg"]).size
        seed = req.seed if req.seed is not None else random.randrange(2**31)
        spr = new_sprite(req.prompt, seed, req.kind, lighting_hint(m["prompt"]))
        sh, sw = spr.shape[:2]
        nh = int(H * SPRITE_HEIGHT[req.kind]); nw = int(sw * nh / sh)
        n = len(m["layers"])
        x = int(min(max((W - nw) / 2 + (n % 5 - 2) * nw * .8, 0), W - nw)); y = int(H - nh - H * .04)
        lid = sc.new_id(); Image.fromarray(spr, "RGBA").save(p / f"layer_{lid}.png")
        m["layers"].append({"id": lid, "src": f"layer_{lid}.png", "x": x, "y": y, "width": nw, "height": nh,
                            "rotation": 0, "visible": True, "name": req.prompt[:28],
                            "prompt": req.prompt, "seed": seed, "kind": req.kind, "pose": "stand"})
        apply_blend(p, m, m["layers"][-1])
        return sc.view(p, sc.commit(p, m))


def apply_blend(p, m: dict, l: dict, strength: float = .65) -> None:
    """Вписывает слой в сцену (свет, цвет, контактная тень). Оригинал спрайта хранится в l['orig'],
    поэтому можно вызывать повторно после перемещения: эффекты не накапливаются."""
    bg = im.to_rgb((p / m["bg"]).read_bytes())
    orig = l.get("orig", l["src"]); pl, pt, pr, pb = l.get("pad", (0, 0, 0, 0))
    ow, oh = Image.open(p / orig).size
    kx, ky = l["width"] / (ow + pl + pr), l["height"] / (oh + pt + pb)
    a = np.deg2rad(l.get("rotation", 0)); c, s_ = np.cos(a), np.sin(a)
    def off(dx, dy): return dx * c - dy * s_, dx * s_ + dy * c
    ox, oy = off(pl * kx, pt * ky)
    bx, by = l["x"] + ox, l["y"] + oy  # левый верх исходного спрайта на сцене
    out, (npl, npt, npr, npb) = im.blend_sprite(np.array(Image.open(p / orig).convert("RGBA")), bg,
                                                (bx, by, ow * kx, oh * ky), strength)
    src = f"layer_{sc.new_id()}.png"; Image.fromarray(out, "RGBA").save(p / src)
    ox, oy = off(npl * kx, npt * ky)
    l.update(orig=orig, pad=[npl, npt, npr, npb], src=src, x=int(bx - ox), y=int(by - oy),
             width=int((ow + npl + npr) * kx), height=int((oh + npt + npb) * ky))


@app.post("/api/scenes/{sid}/layers/{lid}/blend")
def blend_layer(sid: str, lid: str):
    """«Вписать в сцену»: подогнать свет/цвет под место, где слой стоит сейчас, и добавить тень."""
    with LOCK:
        p = sc.sdir(sid); m = sc.load(p); l = find_layer(m, lid)
        apply_blend(p, m, l)
        return sc.view(p, sc.commit(p, m))


@app.post("/api/scenes/{sid}/layers/{lid}/matte")
def clean_layer_background(sid: str, lid: str):
    """Recompute transparency without regenerating pixels or moving the layer."""
    with LOCK:
        p = sc.sdir(sid); m = sc.load(p); l = find_layer(m, lid)
        original = Image.open(p / l.get("orig", l["src"])).convert("RGBA")
        pad = 32
        canvas = Image.new("RGBA", (original.width + 2 * pad, original.height + 2 * pad), (200, 200, 200, 255))
        canvas.alpha_composite(original, (pad, pad))
        mask = holder.worker.matte(im.png_bytes(canvas.convert("RGB")))
        if mask is None:
            raise HTTPException(503, "Модель удаления фона недоступна. Проверьте подключение GPU.")
        mask = cv2.resize(mask, canvas.size, interpolation=cv2.INTER_LINEAR)
        alpha = im.clean_alpha(np.minimum(np.array(original.getchannel("A")), mask[pad:pad + original.height, pad:pad + original.width]))
        if (alpha > 127).sum() < 50:
            raise HTTPException(422, "Не удалось отделить объект. Исходный слой сохранён.")
        original.putalpha(Image.fromarray(alpha))
        src = f"layer_{sc.new_id()}.png"; original.save(p / src)
        l["orig"] = src
        l.pop("rig", None)
        apply_blend(p, m, l)
        return sc.view(p, sc.commit(p, m))


def find_layer(m: dict, lid: str) -> dict:
    for l in m["layers"]:
        if l["id"] == lid:
            return l
    raise HTTPException(404, "Слой не найден")


@app.post("/api/scenes/{sid}/layers/{lid}/replace")
def replace_layer(sid: str, lid: str, req: SpriteReq):
    """Заменить объект: новый спрайт встаёт на место старого (вписан в его рамку, ноги/низ на той же линии)."""
    with LOCK:
        p = sc.sdir(sid); m = sc.load(p); l = find_layer(m, lid)
        seed = req.seed if req.seed is not None else random.randrange(2**31)
        spr = new_sprite(req.prompt, seed, req.kind, lighting_hint(m["prompt"]))
        sh, sw = spr.shape[:2]
        k = min(l["width"] / sw, l["height"] / sh); nw, nh = max(1, int(sw * k)), max(1, int(sh * k))
        new_src = f"layer_{sc.new_id()}.png"; Image.fromarray(spr, "RGBA").save(p / new_src)
        l.pop("orig", None); l.pop("pad", None); l.pop("rig", None)
        l.update(src=new_src, x=int(l["x"] + (l["width"] - nw) / 2), y=int(l["y"] + l["height"] - nh),
                 width=nw, height=nh, rotation=0, name=req.prompt[:28],
                 prompt=req.prompt, seed=seed, kind=req.kind, pose="stand")
        apply_blend(p, m, l)
        return sc.view(p, sc.commit(p, m))


@app.post("/api/scenes/{sid}/layers/{lid}/flip")
def flip_layer(sid: str, lid: str):
    with LOCK:
        p = sc.sdir(sid); m = sc.load(p); l = find_layer(m, lid)
        new_src = f"layer_{sc.new_id()}.png"; im.flip_png(p / l["src"], p / new_src); l["src"] = new_src
        if "orig" in l:  # отражаем и оригинал, поля тени меняем местами
            o2 = f"layer_{sc.new_id()}.png"; im.flip_png(p / l["orig"], p / o2); l["orig"] = o2
            pl, pt, pr, pb = l["pad"]; l["pad"] = [pr, pt, pl, pb]
        if l.get("rig"):  # скелет и база отражаются вместе со спрайтом
            from . import rig
            r = l["rig"]; bw = r["size"][0]; ow = Image.open(p / l.get("orig", l["src"])).size[0]
            b2 = f"layer_{sc.new_id()}.png"; im.flip_png(p / r["base"], p / b2)
            r.update(base=b2, kp0=rig.mirror_kp(r["kp0"], bw).round(1).tolist(),
                     kp=rig.mirror_kp(r["kp"], bw).round(1).tolist() if r.get("kp") else None,
                     org=[bw - (r["org"][0] + ow), r["org"][1]])
        return sc.view(p, sc.commit(p, m))


@app.post("/api/scenes/{sid}/layers/{lid}/duplicate")
def duplicate_layer(sid: str, lid: str):
    with LOCK:
        p = sc.sdir(sid); m = sc.load(p); l = find_layer(m, lid)
        copy = {**l, "id": sc.new_id(), "x": l["x"] + 30, "y": l["y"] + 30, "name": f"{l.get('name', 'Объект')} (копия)"}
        m["layers"].insert(m["layers"].index(l) + 1, copy)
        return sc.view(p, sc.commit(p, m))


# ───────────── состояние, история, экспорт ─────────────
@app.put("/api/scenes/{sid}/state")
def put_state(sid: str, req: StateReq):
    """Позиции, порядок, видимость, удаления (src и id не принимаются от клиента)."""
    with LOCK:
        p = sc.sdir(sid); m = sc.load(p)
        sc.apply_state(m, req.layers)
        return sc.view(p, sc.commit(p, m))


@app.post("/api/scenes/{sid}/undo")
def undo(sid: str):
    with LOCK:
        p = sc.sdir(sid); return sc.view(p, sc.move_cursor(p, sc.load(p), -1))


@app.post("/api/scenes/{sid}/redo")
def redo(sid: str):
    with LOCK:
        p = sc.sdir(sid); return sc.view(p, sc.move_cursor(p, sc.load(p), +1))


@app.get("/api/scenes/{sid}/export")
def export(sid: str):
    """ZIP: готовая сцена, чистый фон и каждый слой отдельным PNG на полотне размера сцены (для Krita/Photoshop)."""
    p = sc.sdir(sid); m = sc.load(p)
    bg = Image.open(p / m["bg"]).convert("RGB")
    vis = [(l, Image.open(p / l["src"])) for l in m["layers"] if l.get("visible", True)]
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("scene.png", im.png_bytes(im.compose(bg, vis)))
        z.writestr("background.png", im.png_bytes(bg))
        for i, (l, sp) in enumerate(vis, 1):
            safe = "".join(ch if ch.isalnum() or ch in "-_ " else "_" for ch in l.get("name", "layer"))[:24].strip() or "layer"
            z.writestr(f"layers/{i:02d}_{safe}.png", im.png_bytes(im.layer_on_canvas(bg.size, sp, l)))
    return Response(buf.getvalue(), media_type="application/zip",
                    headers={"Content-Disposition": f'attachment; filename="scene_{sid}.zip"'})


@app.post("/api/scenes/{sid}/render")
def final_render(sid: str):
    """Финальный рендер: сцена склеивается, затем нейросеть переписывает область вокруг объектов
    (свет, тени, швы). Слои не меняются: можно двигать и рендерить снова."""
    with LOCK:
        p = sc.sdir(sid); m = sc.load(p)
        bg = Image.open(p / m["bg"]).convert("RGB")
        vis = [(l, Image.open(p / l["src"])) for l in m["layers"] if l.get("visible", True)]
        if not vis:
            raise HTTPException(409, "Добавьте на сцену хотя бы один объект")
        originals = []
        for layer, sprite in vis:
            original = Image.open(p / layer.get("orig", layer["src"])).convert("RGBA")
            pl, pt, pr, pb = layer.get("pad", (0, 0, 0, 0))
            kx, ky = layer["width"] / (original.width + pl + pr), layer["height"] / (original.height + pt + pb)
            angle = np.deg2rad(layer.get("rotation", 0)); c, s = np.cos(angle), np.sin(angle)
            dx, dy = pl * kx, pt * ky
            geometry = {**layer, "x": layer["x"] + dx * c - dy * s, "y": layer["y"] + dx * s + dy * c,
                        "width": original.width * kx, "height": original.height * ky}
            originals.append((geometry, original))
        comp, sil, shadow = im.integrated_scene(bg, originals)
        # Do not inpaint the body outline or gaps between fingers/strings.
        # Geometry and antialiasing come from the intact original; the model
        # may only finish the ground shadow.
        ring = shadow.copy()
        ring[sil > 0] = 0
        out = holder.worker.harmonize(im.png_bytes(comp), ring, m["prompt"], .4, lighting_hint(m["prompt"]))
        rgb = im.harmonize_compose(np.array(comp), im.to_rgb(out), sil, ring)
        name = f"final_{sc.new_id()}.png"; Image.fromarray(rgb).save(p / name)
        return {"url": f"/files/{sid}/{name}"}


# ───────────── позы: скелет персонажа и деформация самого спрайта ─────────────
# Принцип: пиксели персонажа не перерисовываются, а двигаются вместе с костями (rig.warp_sprite). Поэтому это тот же
# самый персонаж, а скелет «липнет» к нему: он подгоняется по самому спрайту (детектор + силуэт) и правится вручную.
class KpReq(BaseModel):
    kp0: list[list[float]]  # скелет персонажа в исходной стойке, пиксели исходного спрайта (база)
    kp: list[list[float]]  # желаемая поза, те же координаты


class ApplyReq(KpReq):
    refine: bool = False  # необязательная лёгкая полировка нейросетью (нужен GPU-воркер)
    strength: float = Field(.35, ge=.15, le=.7)


class MeshReq(KpReq):
    protected: list[tuple[float, float, float, float]] = Field(default_factory=list, max_length=16)


class RetargetReq(BaseModel):
    kp0: list[list[float]]
    pose: str
    strategy: Literal["relative", "absolute"] = "relative"
    preserve_hands: bool = False


class SavePoseReq(BaseModel):
    name: str
    kp0: list[list[float]]
    kp: list[list[float]]


def check_kp(kp, lim: float = 4.0) -> np.ndarray:
    try:
        a = np.array(kp, float)
    except (TypeError, ValueError):
        raise HTTPException(400, "Некорректный скелет")
    if a.shape != (18, 2) or not np.isfinite(a).all() or np.abs(a).max() > 1e5 * lim:
        raise HTTPException(400, "Нужно 18 точек скелета (x, y)")
    return a


def _png(rgba: np.ndarray) -> bytes:
    buf = io.BytesIO(); Image.fromarray(rgba, "RGBA").save(buf, "PNG"); return buf.getvalue()


def _user_poses() -> list:
    import json as _j
    f = sc.DATA / "poses.json"
    try:
        return _j.loads(f.read_text(encoding="utf-8")) if f.exists() else []
    except ValueError:
        return []


def _pose_kp(pid: str):
    """Заготовка позы -> (kp, ref) в одинаковых изотропных единицах (для rig.retarget нужны только углы и отношения длин)."""
    ASPECT = 768 / 1024  # заготовки заданы в долях кадра 768x1024
    stand = np.array(poses.POSES["stand"]["kp"], float) * (ASPECT, 1)
    if pid in poses.POSES:
        return np.array(poses.POSES[pid]["kp"], float) * (ASPECT, 1), stand
    for u in _user_poses():
        if u["id"] == pid:
            if "ref" in u:
                return np.array(u["kp"], float), np.array(u["ref"], float)
            return np.array(u["kp"], float) * (ASPECT, 1), stand  # поза из ранней версии (доли кадра)
    raise HTTPException(404, "Поза не найдена")


@app.get("/api/poses")
def list_poses():
    lower_body = {"stand", "sit", "walk", "run", "crouch"}
    return ([{"id": k, "name": v["name"],
              "description": v["text"] + ("; change the lower-body pose, keeping BOTH original hands in their original grip on any held instrument or object; no extra hand on the knee" if k in lower_body else ""),
              "preserve_hands": k in lower_body, "user": False} for k, v in poses.POSES.items()]
            + [{"id": u["id"], "name": u["name"], "user": True} for u in _user_poses()])


@app.post("/api/poses")
def save_pose(req: SavePoseReq):
    """Сохранить позу из редактора в личную библиотеку. Хранится в единицах роста фигуры, поэтому подходит любому персонажу."""
    import json as _j
    name = req.name.strip()[:40]
    if not name:
        raise HTTPException(400, "Введите название позы")
    k0, k = check_kp(req.kp0), check_kp(req.kp)
    H = max(float(np.ptp(k0[:, 1])), 1.0)
    with LOCK:
        lib = _user_poses()
        item = {"id": "u_" + sc.new_id(6), "name": name, "kp": (k / H).round(4).tolist(), "ref": (k0 / H).round(4).tolist()}
        lib.append(item); (sc.DATA / "poses.json").write_text(_j.dumps(lib, ensure_ascii=False), encoding="utf-8")
    return {"id": item["id"], "name": name, "user": True}


def _base_file(l: dict) -> str:
    return l["rig"]["base"] if l.get("rig") else l.get("orig", l["src"])


def _frame(w: int, h: int) -> list[int]:
    """Окно редактора вокруг спрайта: поле для поднятых рук, шага и т. д."""
    mx, my = int(.5 * w), int(.2 * h)
    return [-mx, -my, w + 2 * mx, h + 2 * my]


def _rig_view(sid: str, l: dict) -> dict:
    r = l["rig"]; w, h = r["size"]
    return {"base_url": f"/files/{sid}/{r['base']}", "w": w, "h": h, "frame": _frame(w, h), "kp0": r["kp0"],
            "kp": r.get("kp") or r["kp0"], "method": r["method"], "protected": r.get("protected", [])}


def _fit(png: bytes, rgba: np.ndarray):
    """Подгонка скелета: детектор на воркере (если есть GPU) и запасной вариант по силуэту."""
    from . import rig
    det = None
    try:
        det = holder.worker.skeleton(png)
    except HTTPException:
        det = None  # воркер недоступен: достаточно силуэта
    kp, method, used = rig.merge_detected(rgba[..., 3], det["kp"] if det else None, det["conf"] if det else None)
    return kp, method


@app.post("/api/scenes/{sid}/layers/{lid}/rig")
def get_rig(sid: str, lid: str, refit: bool = False):
    """Скелет слоя для редактора. Первый раз он подгоняется автоматически; refit=true подгоняет заново."""
    with LOCK:
        p = sc.sdir(sid); m = sc.load(p); l = find_layer(m, lid)
        if not l.get("rig") or refit:
            old = l.get("rig")
            base = old["base"] if old else l.get("orig", l["src"])
            raw = (p / base).read_bytes(); rgba = np.array(Image.open(io.BytesIO(raw)).convert("RGBA"))
            if (rgba[..., 3] > 127).sum() < 200:
                raise HTTPException(409, "Спрайт слишком мал для скелета")
            try:
                kp, method = _fit(raw, rgba)
            except ValueError:
                raise HTTPException(409, "Не удалось найти фигуру в спрайте")
            l["rig"] = {**(old or {}), "base": base, "size": [rgba.shape[1], rgba.shape[0]], "kp0": kp.round(1).tolist(),
                        "kp": None, "method": method, "org": (old or {}).get("org", [0, 0])}
            sc.commit(p, m)
        return _rig_view(sid, l)


@app.post("/api/scenes/{sid}/layers/{lid}/rig/retarget")
def retarget(sid: str, lid: str, req: RetargetReq):
    """Заготовка позы, пересчитанная под скелет ЭТОГО персонажа (его пропорции; ступни остаются на месте)."""
    from . import rig
    k0 = check_kp(req.kp0); kp_pose, kp_ref = _pose_kp(req.pose)
    return {"kp": rig.retarget(k0, kp_pose * np.ptp(k0[:, 1]), kp_ref * np.ptp(k0[:, 1]), absolute=req.strategy == "absolute", preserve_hands=req.preserve_hands).round(1).tolist()}


def _warp_args(sid: str, lid: str, req: KpReq):
    from . import rig
    p = sc.sdir(sid); m = sc.load(p); l = find_layer(m, lid)
    if not l.get("rig"):
        raise HTTPException(409, "Сначала откройте редактор позы у этого слоя")
    return rig, p, m, l, np.array(Image.open(p / l["rig"]["base"]).convert("RGBA")), check_kp(req.kp0), check_kp(req.kp)


@app.post("/api/scenes/{sid}/layers/{lid}/pose/preview")
def pose_preview(sid: str, lid: str, req: KpReq):
    """Быстрый черновик позы (CPU, доли секунды): картинка во всём окне редактора."""
    rig, p, m, l, rgba, k0, k = _warp_args(sid, lid, req)
    fx, fy, fw, fh = _frame(rgba.shape[1], rgba.shape[0])
    out, _, _ = rig.warp_sprite(rgba, k0, k, scale=min(1.0, 560 / max(fw, fh)), window=(fx, fy, fw, fh))
    return Response(_png(out), media_type="image/png", headers={"Cache-Control": "no-store"})


def _mesh_result(base, k0, k, protected):
    from . import mesh_pose
    try:
        return mesh_pose.deform(base, k0, k, protected=protected)
    except ValueError as exc:
        message = str(exc)
        if "protected rectangle" in message.lower():
            raise HTTPException(400, "Некорректная закреплённая область") from exc
        if "protected region" in message:
            raise HTTPException(409, "Сустав попал в закреплённую область. Снимите закрепление или двигайте другую часть тела.") from exc
        raise HTTPException(409, "Для бережного движения это слишком большая смена позы. Уменьшите движение; для большой смены нужен режим редактирования изображения.") from exc


@app.post("/api/scenes/{sid}/layers/{lid}/pose/mesh/preview")
def mesh_preview(sid: str, lid: str, req: MeshReq):
    with LOCK:
        _, _, _, _, base, k0, k = _warp_args(sid, lid, req)
        out, origin, _ = _mesh_result(base, k0, k, req.protected)
        fx, fy, fw, fh = _frame(base.shape[1], base.shape[0])
        scale = min(1., 560 / max(fw, fh))
        matrix = np.array([[scale, 0, (origin[0] - fx) * scale], [0, scale, (origin[1] - fy) * scale]], float)
        preview = cv2.warpAffine(out, matrix, (max(1, round(fw * scale)), max(1, round(fh * scale))))
        return Response(_png(preview), media_type="image/png", headers={"Cache-Control": "no-store"})


@app.post("/api/scenes/{sid}/layers/{lid}/pose/mesh/apply")
def mesh_apply(sid: str, lid: str, req: MeshReq):
    with LOCK:
        _, p, m, l, base, k0, k = _warp_args(sid, lid, req)
        out, origin, _ = _mesh_result(base, k0, k, req.protected)
        _put_pose(p, m, l, out, origin, k0, k)
        l["rig"]["protected"] = [list(rect) for rect in req.protected]
        return sc.view(p, sc.commit(p, m))


def _trim(img: np.ndarray, origin):
    ys, xs = np.where(img[..., 3] > 8)
    if len(xs) == 0:
        return img, origin
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    return img[y0:y1, x0:x1], (int(origin[0]) + int(x0), int(origin[1]) + int(y0))


def _posed(base: np.ndarray, k0: np.ndarray, k: np.ndarray, fill_holes: bool = True):
    """Деформация в полном качестве в окне редактора, обрезка по содержимому, дыры внутри тела (LaMa).
    Возвращает (RGBA, маска «что перерисовать», origin в координатах базы)."""
    from . import rig
    h, w = base.shape[:2]; fx, fy, fw, fh = _frame(w, h)
    out, org, fill = rig.warp_sprite(base, k0, k, scale=1.0, window=(fx, fy, fw, fh))
    rmask = rig.repair_mask(out[..., 3], fill, base, k0, k, org)
    x0, y0, x1, y1 = rig.content_box(out[..., 3], np.maximum(rmask, fill), .04)
    out, fill, rmask = out[y0:y1, x0:x1], fill[y0:y1, x0:x1], rmask[y0:y1, x0:x1]
    origin = (int(round(org[0])) + int(x0), int(round(org[1])) + int(y0))
    if fill_holes and (fill > 0).sum() > 25:  # дыры (рука закрывала торс и т. п.): контекст без серой подложки
        ctx = rig.bleed_rgb(out)
        buf = io.BytesIO(); Image.fromarray(ctx).save(buf, "PNG")
        out = rig.apply_fill(out, fill, im.to_rgb(holder.worker.inpaint(buf.getvalue(), fill)))
    return out, rmask, origin


def _foot_scene(l: dict, base_pt, org, pad, kk):
    """Точка базы -> координаты сцены (с учётом поворота слоя)."""
    a = np.deg2rad(l.get("rotation", 0)); c, s_ = np.cos(a), np.sin(a)
    lx, ly = (base_pt[0] - org[0] + pad[0]) * kk, (base_pt[1] - org[1] + pad[1]) * kk
    return np.array([l["x"] + lx * c - ly * s_, l["y"] + lx * s_ + ly * c])


def _layer_scale(p, l: dict):
    old_orig = l.get("orig", l["src"]); ow, oh = Image.open(p / old_orig).size
    pl, pt, pr, pb = l.get("pad", (0, 0, 0, 0))
    return l["width"] / (ow + pl + pr), (pl, pt)


def _foot_of(kp):
    return np.array([(kp[RHIP_][0] + kp[LHIP_][0]) / 2, max(kp[RAN_][1], kp[LAN_][1])])


def _put_pose(p, m, l, out: np.ndarray, origin, k0: np.ndarray, k: np.ndarray):
    """Записать результат в слой: масштаб прежний, ступни остаются на той же точке сцены."""
    out, origin = _trim(out, origin)
    if out.shape[0] < 8 or out.shape[1] < 8 or (out[..., 3] > 127).sum() < 100:
        raise HTTPException(422, "Поза получилась пустой: проверьте скелет")
    r = l["rig"]; k_prev = np.array(r.get("kp") or r["kp0"], float)
    kk, pad = _layer_scale(p, l)
    a = np.deg2rad(l.get("rotation", 0)); c, s_ = np.cos(a), np.sin(a)
    S = _foot_scene(l, _foot_of(k_prev), r.get("org", [0, 0]), pad, kk)
    F = _foot_of(k); lx, ly = (F[0] - origin[0]) * kk, (F[1] - origin[1]) * kk
    nx, ny = S[0] - (lx * c - ly * s_), S[1] - (lx * s_ + ly * c)
    new = f"layer_{sc.new_id()}.png"; Image.fromarray(out, "RGBA").save(p / new)
    l.update(orig=new, pad=[0, 0, 0, 0], src=new, x=int(round(nx)), y=int(round(ny)),
             width=max(4, int(round(out.shape[1] * kk))), height=max(4, int(round(out.shape[0] * kk))))
    r.update(kp0=k0.round(1).tolist(), kp=k.round(1).tolist(), org=[origin[0], origin[1]])
    apply_blend(p, m, l)


def _polish(img: np.ndarray, l: dict, m: dict, strength: float, seed=None) -> np.ndarray:
    res = holder.worker.refine(_png(img), l.get("prompt", ""), strength, seed if seed is not None else l.get("seed"), lighting_hint(m["prompt"]))
    return np.array(Image.open(io.BytesIO(res)).convert("RGBA")) if res is not None else img


@app.post("/api/scenes/{sid}/layers/{lid}/pose/apply")
def pose_apply(sid: str, lid: str, req: ApplyReq):
    """Быстро применить позу: деформация, дыры дорисовывает LaMa, опционально лёгкая полировка нейросетью. Ступни остаются на месте."""
    with LOCK:
        rig, p, m, l, base, k0, k = _warp_args(sid, lid, req)
        if rig.needs_regeneration(k0, k):
            raise HTTPException(409, "Рука закрывает торс в исходном изображении. Для такой смены позы включите «перерисовка по образцу» и создайте варианты: быстрая деформация даст артефакты.")
        out, _, origin = _posed(base, k0, k)
        if req.refine:
            out = _polish(out, l, m, req.strength)
        _put_pose(p, m, l, out, origin, k0, k)
        return sc.view(p, sc.commit(p, m))


# ── варианты: деформация / деформация + починка стыков нейросетью (с образцом внешности) / перерисовка по образцу ──
class VariantsReq(KpReq):
    n: int = Field(3, ge=1, le=4)  # сколько вариантов починки
    ip_scale: float = Field(.6, ge=.2, le=1.0)  # насколько строго держаться образца
    regen: bool = False  # добавить вариант «перерисовка по образцу» (для больших поз)
    polish: bool = False  # слегка отполировать каждый вариант (img2img)
    strength: float = Field(.25, ge=.15, le=.6)
    text: str = ""  # описание позы словами


class CommitReq(KpReq):
    vid: str
    index: int


class EditPoseReq(KpReq):
    action: str = Field("", max_length=1500)
    n: int = Field(1, ge=1, le=4)


def _skeleton_png(k: np.ndarray) -> bytes:
    """Скелет цели в кадре 768x1024 (как у заготовок): фигура по высоте как у стоячих заготовок, ступни на линии."""
    k = np.asarray(k, float); top, bot = k[:, 1].min(), k[:, 1].max()
    sc_ = .79 * 1024 / max(bot - top, 1.0)
    wide = np.ptp(k[:, 0]) * sc_
    if wide > .9 * 768:
        sc_ *= .9 * 768 / wide
    cx = (k[RHIP_][0] + k[LHIP_][0]) / 2
    pts = (k - (cx, bot)) * sc_ + (384, .92 * 1024)
    return poses.render_kp([[x / 768, y / 1024] for x, y in pts])


@app.post("/api/scenes/{sid}/layers/{lid}/pose/edit/variants")
def edit_pose_variants(sid: str, lid: str, req: EditPoseReq):
    """Edit the actual source image, never silently substitute text generation."""
    import json as _j
    with LOCK:
        _, p, m, l, base, k0, k = _warp_args(sid, lid, req)
        guide = _skeleton_png(k)
        reference = _png(base)
        seed = l.get("seed") if l.get("seed") is not None else random.randrange(2**31)
        vid = sc.new_id(6)
        items = []
        try:
            for index in range(req.n):
                png = holder.worker.pose_edit(reference, guide, req.action, (seed + 101 * index) % 2**31)
                sprite = cutout_sprite(png, "character")
                name = f"var_{vid}_{index}.png"
                Image.fromarray(sprite, "RGBA").save(p / name)
                items.append({"kind": "edit", "origin": [0, 0], "file": name})
        except Exception:
            for item in items:
                (p / item["file"]).unlink(missing_ok=True)
            raise
        ys, _ = np.where(base[..., 3] > 8)
        reference_height = float(np.ptp(ys) + 1) if len(ys) else float(base.shape[0])
        ref_h = reference_height * float(np.ptp(k[:, 1])) / max(1., float(np.ptp(k0[:, 1])))
        (p / f"var_{vid}.json").write_text(_j.dumps({"items": items, "ref_h": ref_h, "quality_version": 1,
            "kp0": k0.tolist(), "kp": k.tolist(), "rig_base": l["rig"]["base"]}), encoding="utf-8")
        return {"vid": vid, "note": "Редактирование по исходной картинке. Автопроверка кистей ограничена: проверьте лицо, руки и предмет перед применением.",
                "items": [{"kind": "edit", "url": f"/files/{sid}/{item['file']}"} for item in items]}


@app.post("/api/scenes/{sid}/layers/{lid}/pose/variants")
def pose_variants(sid: str, lid: str, req: VariantsReq):
    """Несколько вариантов позы на выбор. Ничего не записывает в сцену: результат выбирается в /pose/commit."""
    import json as _j
    with LOCK:
        rig, p, m, l, base, k0, k = _warp_args(sid, lid, req)
        needs_redraw = rig.needs_regeneration(k0, k)
        if needs_redraw and not req.regen:
            raise HTTPException(409, "Для этой позы нужна «перерисовка по образцу»: иначе останутся части старых рук. Включите её в редакторе и повторите.")
        for f in p.glob("var_*"):
            f.unlink(missing_ok=True)
        out, rmask, origin = _posed(base, k0, k)
        prompt = ((req.text.strip() + ", ") if req.text.strip() else "") + (l.get("prompt") or "")
        hint = lighting_hint(m["prompt"]); base_png = _png(base)
        notes, aligned = [], [out]
        seed0 = l.get("seed") if l.get("seed") is not None else random.randrange(2**31)
        if rmask.any() and not needs_redraw:
            for i in range(req.n):
                res = holder.worker.repair(_png(out), rmask, base_png, prompt, (seed0 + 101 * (i + 1)) % 2**31, req.ip_scale, hint)
                if res is None:
                    notes.append("Починка стыков нейросетью недоступна: нужен GPU-воркер."); break
                img = np.array(Image.open(io.BytesIO(res)).convert("RGBA"))
                aligned.append(_polish(img, l, m, req.strength, seed0 + i) if req.polish else img)
        elif not needs_redraw:
            notes.append("Поза почти не отличается от исходной: чинить нечего.")
        vid = sc.new_id(6); items = []
        ref_h = int(np.ptp(np.where(out[..., 3] > 8)[0])) if (out[..., 3] > 8).any() else 1
        for i, img in enumerate(aligned):
            if needs_redraw:
                continue
            Image.fromarray(img, "RGBA").save(p / f"var_{vid}_{i}.png")
            items.append({"kind": "warp" if i == 0 else "repair", "origin": list(origin), "file": f"var_{vid}_{i}.png"})
        if req.regen:
            if not l.get("prompt"):
                notes.append("Перерисовка по образцу доступна только персонажам, созданным кнопкой «Добавить» (нужно описание).")
            else:
                try:
                    for j in range(req.n if needs_redraw else 1):
                        spr = new_sprite(prompt, (seed0 + j * 101) % 2**31, "character", hint, _skeleton_png(k), base_png, req.ip_scale)
                        i = len(items); Image.fromarray(spr, "RGBA").save(p / f"var_{vid}_{i}.png")
                        items.append({"kind": "regen", "origin": [0, 0], "file": f"var_{vid}_{i}.png"})
                except HTTPException as e:
                    notes.append(f"Перерисовка по образцу не удалась: {e.detail}")
        if not items:
            raise HTTPException(503, "Не удалось построить корректный вариант. " + " ".join(notes))
        (p / f"var_{vid}.json").write_text(_j.dumps({"items": items, "ref_h": ref_h,
            "kp0": k0.tolist(), "kp": k.tolist(), "rig_base": l["rig"]["base"]}), encoding="utf-8")
        return {"vid": vid, "note": " ".join(notes),
                "items": [{"kind": it["kind"], "url": f"/files/{sid}/{it['file']}"} for it in items]}


@app.post("/api/scenes/{sid}/layers/{lid}/pose/commit")
def pose_commit(sid: str, lid: str, req: CommitReq):
    """Взять один из вариантов, созданных в /pose/variants."""
    import json as _j
    if not req.vid.isalnum():
        raise HTTPException(400, "Некорректный вариант")
    with LOCK:
        rig, p, m, l, base, k0, k = _warp_args(sid, lid, req)
        mf = p / f"var_{req.vid}.json"
        if not mf.exists():
            raise HTTPException(404, "Варианты устарели, создайте их заново")
        meta = _j.loads(mf.read_text(encoding="utf-8"))
        if (meta.get("rig_base") != l["rig"]["base"]
                or not np.allclose(meta.get("kp0", []), k0, atol=.1)
                or not np.allclose(meta.get("kp", []), k, atol=.1)):
            raise HTTPException(409, "Скелет изменился. Создайте варианты заново для новой позы.")
        if not 0 <= req.index < len(meta["items"]):
            raise HTTPException(400, "Нет такого варианта")
        it = meta["items"][req.index]; img = np.array(Image.open(p / it["file"]).convert("RGBA"))
        if it["kind"] == "edit" and meta.get("quality_version") != 1:
            raise HTTPException(409, "Этот вариант создан до обновления проверки позы. Создайте новые варианты.")
        if it["kind"] not in ("regen", "edit"):
            _put_pose(p, m, l, img, it["origin"], k0, k)
        else:  # новый спрайт: свои пропорции, масштаб подбираем по высоте деформированной фигуры, ступни остаются на месте
            if "pose_original" not in l:
                l["pose_original"] = _j.loads(_j.dumps(l))
            r = l["rig"]; k_prev = np.array(r.get("kp") or r["kp0"], float)
            kk, pad = _layer_scale(p, l)
            S = _foot_scene(l, _foot_of(k_prev), r.get("org", [0, 0]), pad, kk)
            img, _ = _trim(img, (0, 0)); sh, sw = img.shape[:2]
            f = max(1e-3, meta["ref_h"] * kk / sh)
            ys, xs = np.where(img[..., 3] > 127); bx, by = float(xs[ys > ys.max() - max(2, int(.05 * sh))].mean()), float(ys.max())
            a = np.deg2rad(l.get("rotation", 0)); c, s_ = np.cos(a), np.sin(a)
            nx, ny = S[0] - (bx * f * c - by * f * s_), S[1] - (bx * f * s_ + by * f * c)
            new = f"layer_{sc.new_id()}.png"; Image.fromarray(img, "RGBA").save(p / new)
            l.pop("rig", None)  # у нового спрайта свой скелет: он подгонится при следующем открытии редактора
            l.update(orig=new, pad=[0, 0, 0, 0], src=new, x=int(round(nx)), y=int(round(ny)),
                     width=max(4, int(sw * f)), height=max(4, int(sh * f)))
            apply_blend(p, m, l)
        for f_ in p.glob("var_*"):
            f_.unlink(missing_ok=True)
        return sc.view(p, sc.commit(p, m))


@app.post("/api/scenes/{sid}/layers/{lid}/pose/reset")
def pose_reset(sid: str, lid: str):
    """Вернуть исходную стойку."""
    with LOCK:
        p = sc.sdir(sid); m = sc.load(p); l = find_layer(m, lid)
        original = l.get("pose_original")
        if original:
            l.clear(); l.update(original)
            r = l.get("rig")
            if r and r.get("kp"):
                base = np.array(Image.open(p / r["base"]).convert("RGBA"))
                k0 = np.asarray(r["kp0"], float)
                _put_pose(p, m, l, base, (0, 0), k0, k0)
            return sc.view(p, sc.commit(p, m))
        if not l.get("rig") or not l["rig"].get("kp"):
            return sc.view(p, m)
        r = l["rig"]; k0 = np.asarray(r["kp0"], float)
        base = np.array(Image.open(p / r["base"]).convert("RGBA"))
        _put_pose(p, m, l, base, (0, 0), k0, k0)
        return sc.view(p, sc.commit(p, m))
