"""Experimental continuous ARAP deformation for modest 2D pose changes.

Unlike cut-and-paste limb warping, triangles share vertices. Protected regions
move rigidly with the torso. Large edits and folded meshes are rejected.
"""
import cv2
import numpy as np
from scipy.spatial import Delaunay, cKDTree
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import factorized


def deform(rgba, source, target, protected=(), spacing=26, iterations=12):
    image = np.asarray(rgba)
    src, dst = np.asarray(source, float), np.asarray(target, float)
    if image.ndim != 3 or image.shape[2] != 4 or src.shape != (18, 2) or dst.shape != src.shape:
        raise ValueError("Expected RGBA image and two 18-point skeletons")
    if not np.isfinite(src).all() or not np.isfinite(dst).all():
        raise ValueError("Non-finite skeleton coordinates")
    height, width = image.shape[:2]
    body_height = max(1., float(np.ptp(src[:, 1])))
    if np.linalg.norm(dst - src, axis=1).max() > .13 * body_height:
        raise ValueError("This change needs image editing, not the small-motion mesh")
    if np.allclose(src, dst, atol=1e-6):
        return image.copy(), (0, 0), {"max_motion": 0., "minimum_area_ratio": 1.}

    # Include the transparent background: the raster keeps its complete outline,
    # rather than losing hair or thin instrument strings at a sampled contour.
    xs = np.unique(np.r_[np.arange(0, width, spacing), width - 1])
    ys = np.unique(np.r_[np.arange(0, height, spacing), height - 1])
    xx, yy = np.meshgrid(xs, ys)
    points = np.vstack([np.c_[xx.ravel(), yy.ravel()], src])
    points = np.unique(np.round(points, 5), axis=0)
    mesh = Delaunay(points)
    triangles = mesh.simplices
    edges = np.unique(np.sort(np.vstack([triangles[:, [0, 1]], triangles[:, [1, 2]], triangles[:, [2, 0]]]), axis=1), axis=0)
    i, j = edges.T
    mid = (points[i] + points[j]) / 2
    mx = np.clip(np.round(mid[:, 0]).astype(int), 0, width - 1)
    my = np.clip(np.round(mid[:, 1]).astype(int), 0, height - 1)
    weights = np.where(image[my, mx, 3] > 64, 1., .025)
    count = len(points)
    laplacian = coo_matrix((np.r_[weights, weights, -weights, -weights],
                           (np.r_[i, j, i, j], np.r_[i, j, j, i])), shape=(count, count)).tocsr()

    handles = {}
    torso_delta = (dst[[1, 8, 11]] - src[[1, 8, 11]]).mean(axis=0)
    for rectangle in protected:
        if len(rectangle) != 4 or not np.isfinite(rectangle).all():
            raise ValueError("Invalid protected rectangle")
        x0, y0, x1, y1 = rectangle
        if x1 <= x0 or y1 <= y0:
            raise ValueError("Protected rectangle has no area")
        selected = np.where((points[:, 0] >= x0) & (points[:, 0] <= x1)
                            & (points[:, 1] >= y0) & (points[:, 1] <= y1))[0]
        for index in selected:
            handles[int(index)] = points[index] + torso_delta
    joint_indices = cKDTree(points).query(src)[1]
    for joint, index in enumerate(joint_indices):
        if index in handles and np.linalg.norm(handles[index] - dst[joint]) > 2:
            raise ValueError("A joint is inside a protected region; unlock it or use image editing")
        handles[int(index)] = dst[joint]
    fixed = np.array(sorted(handles))
    fixed_positions = np.array([handles[int(index)] for index in fixed])
    free = np.setdiff1d(np.arange(count), fixed)
    solve = factorized(laplacian[free][:, free].tocsc())
    coupling = laplacian[free][:, fixed]
    q = points.copy()
    displacements = fixed_positions - points[fixed]
    for axis in range(2):
        q[free, axis] += solve(-coupling @ displacements[:, axis])
    q[fixed] = fixed_positions
    original_edges = points[i] - points[j]
    for _ in range(iterations):
        current_edges = q[i] - q[j]
        products = weights[:, None, None] * original_edges[:, :, None] * current_edges[:, None, :]
        covariance = np.zeros((count, 2, 2))
        np.add.at(covariance, i, products)
        np.add.at(covariance, j, products)
        u, _, vt = np.linalg.svd(covariance)
        rotation = vt.transpose(0, 2, 1) @ u.transpose(0, 2, 1)
        reflected = np.linalg.det(rotation) < 0
        vt[reflected, -1, :] *= -1
        rotation = vt.transpose(0, 2, 1) @ u.transpose(0, 2, 1)
        terms = .5 * weights[:, None] * np.einsum('eij,ej->ei', rotation[i] + rotation[j], original_edges)
        rhs = np.zeros_like(points)
        np.add.at(rhs, i, terms)
        np.add.at(rhs, j, -terms)
        for axis in range(2):
            q[free, axis] = solve(rhs[free, axis] - coupling @ fixed_positions[:, axis])
        q[fixed] = fixed_positions

    def area(vertices):
        a = vertices[triangles[:, 1]] - vertices[triangles[:, 0]]
        b = vertices[triangles[:, 2]] - vertices[triangles[:, 0]]
        return a[:, 0] * b[:, 1] - a[:, 1] * b[:, 0]
    ratio = area(q) / area(points)
    if ratio.min() < .20 or ratio.max() > 4:
        raise ValueError("The mesh would fold or stretch excessively; use image editing")

    origin = np.floor(np.minimum(q.min(axis=0), [0, 0])).astype(int) - 2
    bound = np.ceil(np.maximum(q.max(axis=0), [width - 1, height - 1])).astype(int) + 3
    out_width, out_height = bound - origin
    if out_width * out_height > 16 * width * height:
        raise ValueError("Unreasonable output size")
    map_x = np.full((out_height, out_width), -1, np.float32)
    map_y = np.full_like(map_x, -1)
    for triangle in triangles:
        dest = (q[triangle] - origin).astype(np.float32)
        x0, y0 = np.maximum(np.floor(dest.min(axis=0)).astype(int), 0)
        x1, y1 = np.minimum(np.ceil(dest.max(axis=0)).astype(int) + 1, [out_width, out_height])
        if x1 <= x0 or y1 <= y0:
            continue
        local = dest - (x0, y0)
        mask = np.zeros((y1 - y0, x1 - x0), np.uint8)
        cv2.fillConvexPoly(mask, np.round(local * 256).astype(np.int32), 1, shift=8)
        py, px = np.where(mask)
        matrix = cv2.getAffineTransform(dest, points[triangle].astype(np.float32))
        coordinates = np.c_[px + x0, py + y0] @ matrix[:, :2].T + matrix[:, 2]
        map_x[py + y0, px + x0] = coordinates[:, 0]
        map_y[py + y0, px + x0] = coordinates[:, 1]
    premultiplied = image.astype(np.float32)
    premultiplied[..., :3] *= premultiplied[..., 3:4] / 255
    output = cv2.remap(premultiplied, map_x, map_y, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
    alpha = output[..., 3:4]
    output[..., :3] = np.divide(output[..., :3] * 255, alpha, out=np.zeros_like(output[..., :3]), where=alpha > 0)
    return np.clip(np.round(output), 0, 255).astype(np.uint8), tuple(map(int, origin)), {
        "max_motion": float(np.linalg.norm(dst - src, axis=1).max()),
        "minimum_area_ratio": float(ratio.min()),
    }
