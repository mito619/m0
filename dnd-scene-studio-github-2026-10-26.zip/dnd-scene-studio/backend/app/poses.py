"""Библиотека поз. Ключевые точки COCO-18 в долях кадра: нос, шея, плечи, локти, запястья, бёдра, колени, щиколотки, глаза, уши.
Правая сторона персонажа находится слева на картинке (фигура смотрит на зрителя)."""
import re

import cv2, numpy as np

def _face(nx, ny):  # глаза и уши вокруг носа
    return [(nx - .02, ny - .015), (nx + .02, ny - .015), (nx - .05, ny), (nx + .05, ny)]

def _pose(nose, neck, rs, re, rw, ls, le, lw, rh, rk, ra, lh, lk, la):
    return [nose, neck, rs, re, rw, ls, le, lw, rh, rk, ra, lh, lk, la, *_face(*nose)]

POSES = {
    "stand":  {"name": "Стоит", "text": "standing relaxed, facing viewer", "kp": _pose(
        (.5, .13), (.5, .22), (.42, .23), (.39, .37), (.38, .50), (.58, .23), (.61, .37), (.62, .50),
        (.45, .52), (.45, .72), (.45, .92), (.55, .52), (.55, .72), (.55, .92))},
    "walk":   {"name": "Идёт", "text": "walking forward mid-stride", "kp": _pose(
        (.5, .13), (.5, .22), (.42, .23), (.45, .37), (.50, .49), (.58, .23), (.55, .37), (.52, .49),
        (.46, .52), (.40, .71), (.34, .91), (.54, .52), (.58, .71), (.63, .91))},
    "wave":   {"name": "Машет рукой", "text": "waving with the right hand raised, friendly greeting", "kp": _pose(
        (.5, .13), (.5, .22), (.42, .23), (.35, .17), (.33, .06), (.58, .23), (.61, .37), (.62, .50),
        (.45, .52), (.45, .72), (.45, .92), (.55, .52), (.55, .72), (.55, .92))},
    "cast":   {"name": "Колдует", "text": "casting a spell, both arms raised", "kp": _pose(
        (.5, .14), (.5, .23), (.42, .24), (.34, .17), (.31, .07), (.58, .24), (.66, .17), (.69, .07),
        (.45, .53), (.45, .72), (.45, .92), (.55, .53), (.55, .72), (.55, .92))},
    "attack": {"name": "Атакует", "text": "attacking in a dynamic combat stance, wide legs, one arm raised", "kp": _pose(
        (.5, .15), (.5, .24), (.42, .25), (.36, .15), (.41, .05), (.58, .25), (.65, .34), (.73, .29),
        (.45, .53), (.37, .72), (.33, .92), (.55, .53), (.64, .72), (.68, .92))},
    "sit":    {"name": "Сидит", "text": "sitting on a wooden stool, relaxed", "kp": _pose(
        (.49, .16), (.49, .25), (.40, .27), (.34, .40), (.43, .46), (.58, .26), (.66, .40), (.57, .46),
        (.43, .54), (.62, .65), (.60, .90), (.55, .54), (.74, .64), (.72, .90))},
}
COLORS = [(255, 0, 0), (255, 85, 0), (255, 170, 0), (255, 255, 0), (170, 255, 0), (85, 255, 0), (0, 255, 0), (0, 255, 85),
          (0, 255, 170), (0, 255, 255), (0, 170, 255), (0, 85, 255), (0, 0, 255), (85, 0, 255), (170, 0, 255), (255, 0, 255), (255, 0, 170), (255, 0, 85)]
LIMBS = [(1, 2), (1, 5), (2, 3), (3, 4), (5, 6), (6, 7), (1, 8), (8, 9), (9, 10), (1, 11), (11, 12), (12, 13), (1, 0), (0, 14), (14, 16), (0, 15), (15, 17)]


def fig_h(name: str) -> float:
    ys = [y for _, y in POSES[name]["kp"]]
    return max(ys) - min(ys)


def kp_h(kp) -> float:
    ys = [p[1] for p in kp]
    return max(ys) - min(ys)


def render_kp(kp, w: int = 768, h: int = 1024) -> bytes:
    """Картинка-скелет в формате OpenPose для ControlNet (чёрный фон, цветные конечности)."""
    ratio = 1 if max(w, h) < 500 else 2 if max(w, h) < 1000 else 3
    pts = [(x * w, y * h) for x, y in kp]
    img = np.zeros((h, w, 3), np.uint8)
    for i, (a, b) in enumerate(LIMBS):
        (x1, y1), (x2, y2) = pts[a], pts[b]
        poly = cv2.ellipse2Poly((int((x1 + x2) / 2), int((y1 + y2) / 2)), (int(np.hypot(x1 - x2, y1 - y2) / 2), 4 * ratio),
                                int(np.degrees(np.arctan2(y1 - y2, x1 - x2))), 0, 360, 1)
        cv2.fillConvexPoly(img, poly, COLORS[i])
    img = (img * .6).astype(np.uint8)
    for i, (x, y) in enumerate(pts):
        cv2.circle(img, (int(x), int(y)), 4 * ratio, COLORS[i], -1)
    ok, buf = cv2.imencode(".png", cv2.cvtColor(img, cv2.COLOR_RGB2BGR)); return buf.tobytes()


# слова в описании позы -> ближайший каркас. Нет совпадения = генерация без каркаса, только по тексту.
KEYS = [("sit", r"сид|присел|на стул|на табурет|sit"),
        ("cast", r"колду|заклин|магию|руки вверх|руки подня|cast|spell"),
        ("attack", r"атак|удар|бь[её]т|бой|боев|замах|меч|атакуе|attack|strike|fight|sword"),
        ("wave", r"маш|приветств|wave|greet"),
        ("walk", r"идёт|идет|шага|бежит|бег|walk|run|step")]


def guess(text: str):
    t = text.lower()
    return next((k for k, pat in KEYS if re.search(pat, t)), None)


def render(name: str, w: int = 768, h: int = 1024) -> bytes:
    return render_kp(POSES[name]["kp"], w, h)


_LEGS = ((.45, .52), (.45, .72), (.45, .92), (.55, .52), (.55, .72), (.55, .92))
POSES.update({
    "run":    {"name": "Бежит", "text": "running fast, leaning forward, dynamic", "kp": _pose(
        (.5, .14), (.5, .23), (.42, .24), (.36, .36), (.42, .28), (.58, .24), (.66, .34), (.60, .44),
        (.46, .53), (.42, .66), (.34, .76), (.54, .53), (.58, .73), (.62, .92))},
    "point":  {"name": "Указывает рукой", "text": "pointing with the right arm outstretched", "kp": _pose(
        (.5, .13), (.5, .22), (.42, .23), (.32, .24), (.20, .25), (.58, .23), (.61, .37), (.62, .50), *_LEGS)},
    "drink":  {"name": "Пьёт из кружки", "text": "raising a mug to drink, cheerful", "kp": _pose(
        (.5, .13), (.5, .22), (.42, .23), (.37, .34), (.46, .17), (.58, .23), (.61, .37), (.62, .50), *_LEGS)},
    "crouch": {"name": "Крадётся", "text": "crouching low, sneaking", "kp": _pose(
        (.5, .30), (.5, .39), (.42, .40), (.38, .52), (.42, .62), (.58, .40), (.62, .52), (.58, .62),
        (.45, .62), (.38, .76), (.43, .92), (.55, .62), (.62, .76), (.57, .92))},
})
