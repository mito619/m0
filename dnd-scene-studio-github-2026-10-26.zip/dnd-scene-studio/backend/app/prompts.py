"""Эвристики по тексту промпта."""
import re

# Корни слов с границей слова в начале: «гном», «эльфийка», «воины», но не «оркестр» или «бардак».
_PEOPLE = re.compile(
    r"\b(гном|эльф|гоблин|дварф|полуросл|человек|люди|людей|мужчин|женщин|девушк|девочк|мальчик|старик|старуш|ребён|ребен|"
    r"воин|бард(а|ом|у|ы|ов)?\b|маг(и|ов|ом)?\b|волшебн|чародей|колдун|рыцар|паладин|жрец|монах|разбойник|следопыт|охотник|"
    r"страж|торговец|трактирщик|официант|персонаж|существ|дракон|монстр|скелет|зомби|демон|ангел|орк(а|и|ов|ом)?\b|"
    r"bard|gnome|elf\b|elves|elven|dwarf|dwarves|orc\b|orcs|goblin|halfling|human|people|person|\bmen\b|\bman\b|woman|women|"
    r"girl|\bboy|warrior|wizard|mage\b|knight|paladin|cleric|monk\b|rogue|ranger|hunter|guard|merchant|innkeeper|"
    r"character|creature|dragon|monster|skeleton|zombie|demon|angel)", re.I)


_EMPTY = re.compile(r"\bпуст\w*\s+|\bempty\s+", re.I)


def strip_empty(prompt: str) -> str:
    """Если в сцене нужны персонажи, слова «пустой/empty» только мешают: нейросеть рисует пустую комнату."""
    return _EMPTY.sub("", prompt).strip() or prompt


def wants_people(prompt: str) -> bool:
    return bool(_PEOPLE.search(prompt))


def lighting_hint(scene_prompt: str) -> str:
    """Освещение сцены -> английская подсказка для нового персонажа. Без слов «огонь/факел»: нейросеть рисует их в руках."""
    t = scene_prompt.lower()
    if re.search(r"камин|свеч|факел|костер|костёр|таверн|fire|candle|torch|tavern", t):
        return "warm amber ambient light, soft orange rim light, dim cozy lighting"
    if re.search(r"ночь|луна|night|moon", t):
        return "cold blue moonlight, soft rim light, dim lighting"
    if re.search(r"подземел|пещер|dungeon|cave", t):
        return "dim warm light, dark surroundings, deep shadows"
    if re.search(r"день|солнц|поле|лес|day|sun|forest", t):
        return "natural daylight, soft shadows"
    return ""


_IN = re.compile(r"камин|стол|зал\b|комнат|внутри|интерьер|подвал|подземел|пещер|коридор|inside|interior|indoor|dungeon|cave|room|hall", re.I)
_OUT = re.compile(r"снаружи|улиц|площад|лес|поле|гор[аы]|берег|снег|outside|exterior|forest|field|street|mountain|village", re.I)
PLACE_HINT = {"inside": "interior view, indoors, inside the room, walls and ceiling visible", "outside": "outdoor view, open air"}
PLACE_AVOID = {"inside": "exterior, outdoors, snow, building exterior, sky", "outside": "interior, indoors, ceiling"}


def guess_place(prompt: str):
    """«Таверна, камин, столы» -> внутри; «площадь, лес» -> снаружи; иначе не вмешиваемся."""
    return "inside" if _IN.search(prompt) else "outside" if _OUT.search(prompt) else None
