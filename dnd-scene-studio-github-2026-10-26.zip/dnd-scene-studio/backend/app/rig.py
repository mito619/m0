"""Скелет персонажа и смена позы деформацией САМОГО спрайта (puppet warp).

Почему так, а не перерисовкой: перерисовка нейросетью по тексту и новому скелету даёт другого персонажа.
Здесь пиксели остаются теми же самыми: части тела двигаются вместе со своими костями, поэтому лицо,
одежда, цвета и детали сохраняются на 100%. Цена: подходят умеренные изменения позы (руки, шаг, наклон, поворот
головы). Для сильных (сесть, присесть) результат грубее, и тут помогает необязательное «улучшение» нейросетью
с малой силой (img2img): оно чинит швы и тени, но не придумывает человека заново.

Скелет: 18 точек в порядке OpenPose (нос, шея, правое плечо/локоть/запястье, левое ..., бёдра, колени, щиколотки,
глаза, уши). «Правая» сторона персонажа находится слева на картинке.
Координаты везде в пикселях спрайта, если не сказано иное.
"""
import numpy as np, cv2

NOSE, NECK, RSH, REL, RWR, LSH, LEL, LWR, RHIP, RKN, RAN, LHIP, LKN, LAN, REYE, LEYE, REAR, LEAR = range(18)
PELVIS = 18  # виртуальная точка: середина бёдер

# (родитель, потомок) для переноса поз по углам
FK_BONES = [(PELVIS, NECK), (NECK, NOSE), (NECK, RSH), (NECK, LSH), (RSH, REL), (REL, RWR), (LSH, LEL), (LEL, LWR),
            (PELVIS, RHIP), (PELVIS, LHIP), (RHIP, RKN), (RKN, RAN), (LHIP, LKN), (LKN, LAN),
            (NOSE, REYE), (NOSE, LEYE), (NOSE, REAR), (NOSE, LEAR)]


def pelvis(kp: np.ndarray) -> np.ndarray:
    return (kp[RHIP] + kp[LHIP]) / 2


def _ext(kp):
    return np.vstack([kp, pelvis(kp)[None]])  # 19 точек, последняя виртуальная


# ───────────────────────── подгонка скелета по силуэту ─────────────────────────
def fit_from_mask(alpha: np.ndarray) -> np.ndarray:
    """Скелет по силуэту (когда детектор позы недоступен или не нашёл человека). Рассчитан на вертикально стоящую
    фигуру, как генерирует приложение. Это стартовая расстановка: точки лежат внутри силуэта, их можно поправить."""
    m = alpha > 127
    ys, xs = np.where(m)
    if len(xs) < 50:
        raise ValueError("пустой спрайт")
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    H = float(y1 - y0)

    def ext(y):
        r = np.where(m[int(np.clip(y, 0, m.shape[0] - 1))])[0]
        return (r.min(), r.max() + 1) if r.size else None

    mids = [(a + b) / 2 for y in range(int(y0 + .2 * H), int(y0 + .55 * H) + 1) if (e := ext(y)) for a, b in [e]]
    cx = float(np.median(mids)) if mids else (x0 + x1) / 2

    widths = np.array([(lambda e: e[1] - e[0] if e else 0)(ext(y0 + i)) for i in range(int(.4 * H))], float)
    widths = np.convolve(widths, np.ones(5) / 5, mode="same")
    lo, hi = int(.11 * H), int(.27 * H)
    neck_y = y0 + .19 * H
    if hi > lo + 2 and widths[:hi].max() > 0:
        i = lo + int(np.argmin(widths[lo:hi]))
        if widths[i] < .8 * widths[:hi].max():  # настоящая «талия» шеи, а не борода/капюшон
            neck_y = y0 + i
    head_h = neck_y - y0

    sh_y = neck_y + .035 * H
    e = ext(sh_y + .03 * H)
    hw = np.clip(.5 * ((e[1] - e[0]) if e else .3 * H) * .78, .07 * H, .2 * H)
    hip_y = y0 + .52 * H
    hhw = .45 * hw
    k = np.zeros((18, 2))
    k[NECK] = (cx, neck_y)
    k[NOSE] = (cx, y0 + .62 * head_h)
    k[REYE] = (cx - .18 * head_h, k[NOSE][1] - .12 * head_h); k[LEYE] = (cx + .18 * head_h, k[REYE][1])
    k[REAR] = (cx - .42 * head_h, k[NOSE][1] - .05 * head_h); k[LEAR] = (cx + .42 * head_h, k[REAR][1])
    k[RSH] = (cx - hw, sh_y); k[LSH] = (cx + hw, sh_y)
    k[REL] = (cx - hw * 1.08, sh_y + .16 * H); k[LEL] = (cx + hw * 1.08, k[REL][1])
    k[RWR] = (cx - hw * 1.1, sh_y + .31 * H); k[LWR] = (cx + hw * 1.1, k[RWR][1])
    k[RHIP] = (cx - hhw, hip_y); k[LHIP] = (cx + hhw, hip_y)
    k[RKN] = (cx - hhw, hip_y + .22 * H); k[LKN] = (cx + hhw, k[RKN][1])
    k[RAN] = (cx - hhw, y1 - .035 * H); k[LAN] = (cx + hhw, k[RAN][1])

    # суставы конечностей прижимаем к «хребту» карты расстояний: они лежат по центру руки/ноги
    dt = cv2.distanceTransform(m.astype(np.uint8), cv2.DIST_L2, 5)
    rad = int(.05 * H)
    for j in (REL, RWR, LEL, LWR, RKN, LKN, RAN, LAN):
        x, y = int(round(k[j][0])), int(round(k[j][1]))
        xa, xb, ya, yb = max(x - rad, 0), min(x + rad + 1, m.shape[1]), max(y - rad, 0), min(y + rad + 1, m.shape[0])
        win = dt[ya:yb, xa:xb]
        if win.size and win.max() > .01 * H:
            iy, ix = np.unravel_index(int(win.argmax()), win.shape)
            k[j] = (xa + ix, ya + iy)
    for j in range(18):  # всё должно лежать внутри силуэта
        for _ in range(40):
            x, y = int(np.clip(round(k[j][0]), 0, m.shape[1] - 1)), int(np.clip(round(k[j][1]), 0, m.shape[0] - 1))
            if m[y, x]:
                break
            k[j][0] += (cx - k[j][0]) * .08
    return k


# ───────────────────────── перенос заготовки позы на персонажа ─────────────────────────
def _rot(v, ang):
    c, s_ = np.cos(ang), np.sin(ang)
    return np.array([c * v[0] - s_ * v[1], s_ * v[0] + c * v[1]])


def retarget(kp_char: np.ndarray, kp_pose, kp_ref, keep_feet: bool = True, absolute: bool = False, preserve_hands: bool = False) -> np.ndarray:
    """Поза из библиотеки -> скелет ЭТОГО персонажа. Для каждой кости берётся, НА СКОЛЬКО поворот и укорочение позы
    отличаются от опорной стойки kp_ref, и это применяется к собственной кости персонажа. Поэтому меняется только то,
    что в позе реально другое (в «машет рукой» уходит одна рука, ноги не трогаются), длины и пропорции остаются
    персонажа (гном остаётся приземистым), а сидящее бедро получается короче, как в ракурсе.
    Ступни остаются на прежней линии, таз по горизонтали на месте."""
    c, p, r = _ext(np.asarray(kp_char, float)), _ext(np.asarray(kp_pose, float)), _ext(np.asarray(kp_ref, float))
    out = c.copy()
    for par, ch in FK_BONES:
        vc, vp, vr = c[ch] - c[par], p[ch] - p[par], r[ch] - r[par]
        lp, lr = np.hypot(*vp), np.hypot(*vr)
        if lp < 1e-6 or lr < 1e-6:
            out[ch] = out[par] + vc; continue
        orientation = vc if absolute else vr
        d = np.arctan2(vp[1], vp[0]) - np.arctan2(orientation[1], orientation[0])
        out[ch] = out[par] + _rot(vc, d) * float(np.clip(lp / lr, .35, 1.3))
    out = out[:18]
    if preserve_hands:
        # A lower-body action must not ask the model for new lap hands while
        # the reference already has both hands attached to an instrument.
        torso = cv2.getAffineTransform(c[[NECK, RHIP, LHIP]].astype(np.float32), out[[NECK, RHIP, LHIP]].astype(np.float32))
        arms = [RSH, REL, RWR, LSH, LEL, LWR]
        out[arms] = c[arms] @ torso[:, :2].T + torso[:, 2]
    if keep_feet:
        dy = max(c[RAN][1], c[LAN][1]) - max(out[RAN][1], out[LAN][1])
        dx = pelvis(c)[0] - pelvis(out)[0]
        out += (dx, dy)
    return out


def anchor(kp: np.ndarray) -> np.ndarray:
    """Точка опоры фигуры: таз по x, самая низкая щиколотка по y."""
    return np.array([pelvis(kp)[0], max(kp[RAN][1], kp[LAN][1])])


def needs_regeneration(kp_src, kp_dst):
    """A hand crossing the torso hides clothing that a 2D warp cannot recover."""
    source, target = np.asarray(kp_src, float), np.asarray(kp_dst, float)
    height = max(1., float(np.ptp(source[:, 1])))
    centre = pelvis(source)[0]
    for elbow, wrist in ((REL, RWR), (LEL, LWR)):
        across_body = abs(source[wrist, 0] - centre) < .9 * abs(source[elbow, 0] - centre)
        at_waist = source[NECK, 1] < source[wrist, 1] < pelvis(source)[1] + .08 * height
        if across_body and at_waist and np.linalg.norm(target[wrist] - source[wrist]) > .2 * height:
            return True
    return False


# ───────────────────────── деформация спрайта ─────────────────────────
def _seg_dist(X, Y, a, b):
    ab = b - a; L2 = float(ab @ ab) + 1e-9
    t = np.clip(((X - a[0]) * ab[0] + (Y - a[1]) * ab[1]) / L2, 0, 1)
    return np.hypot(X - (a[0] + t * ab[0]), Y - (a[1] + t * ab[1]))


def _march(mask, start, direction, max_len):
    """Длина луча от start по direction, пока он внутри маски (не больше max_len)."""
    d = direction / (np.hypot(*direction) + 1e-9)
    n = 0
    for s in range(1, int(max_len) + 1):
        x, y = int(round(start[0] + d[0] * s)), int(round(start[1] + d[1] * s))
        if not (0 <= x < mask.shape[1] and 0 <= y < mask.shape[0]) or not mask[y, x]:
            break
        n = s
    return float(n)


def _bones(ks: np.ndarray, kt: np.ndarray, mask: np.ndarray):
    """Кости как пары (начало, конец) в исходной и целевой позе + z-порядок. Голова, кисти и стопы продлены
    до края силуэта, чтобы шляпа, предмет в руке и обувь ехали вместе со своей костью."""
    S, T = _ext(ks), _ext(kt)
    H = float(max(np.ptp(ks[:, 1]), 1))

    def extend(a, b, cap):
        """Продолжение кости a->b за точку b до края маски. Возвращает (b_src, b_dst)."""
        v = S[b] - S[a]; L = np.hypot(*v)
        extra = _march(mask, S[b], v, cap * max(L, 1.0)) if L > 1e-6 else 0.0
        bs = S[b] + v / (L + 1e-9) * extra
        vt = T[b] - T[a]; Lt = np.hypot(*vt)
        ratio = float(np.clip(Lt / max(L, 1e-6), .5, 1.6))
        bt = T[b] + vt / (Lt + 1e-9) * extra * ratio
        return bs, bt

    crown_s, crown_t = extend(NECK, NOSE, 1.2)
    hand_r = extend(REL, RWR, .6); hand_l = extend(LEL, LWR, .6)
    foot_r = extend(RKN, RAN, .5); foot_l = extend(LKN, LAN, .5)
    B = [  # z от дальнего к ближнему
        ("thigh_r", S[RHIP], S[RKN], T[RHIP], T[RKN]), ("thigh_l", S[LHIP], S[LKN], T[LHIP], T[LKN]),
        ("shin_r", S[RKN], foot_r[0], T[RKN], foot_r[1]), ("shin_l", S[LKN], foot_l[0], T[LKN], foot_l[1]),
        ("hip_r", S[PELVIS], S[RHIP], T[PELVIS], T[RHIP]), ("hip_l", S[PELVIS], S[LHIP], T[PELVIS], T[LHIP]),
        ("spine", S[NECK], S[PELVIS], T[NECK], T[PELVIS]),
        ("sh_r", S[NECK], S[RSH], T[NECK], T[RSH]), ("sh_l", S[NECK], S[LSH], T[NECK], T[LSH]),
        ("head", S[NECK], crown_s, T[NECK], crown_t),
        ("uarm_r", S[RSH], S[REL], T[RSH], T[REL]), ("uarm_l", S[LSH], S[LEL], T[LSH], T[LEL]),
        ("farm_r", S[REL], hand_r[0], T[REL], hand_r[1]), ("farm_l", S[LEL], hand_l[0], T[LEL], hand_l[1]),
    ]
    return B


def warp_sprite(rgba: np.ndarray, kp_src, kp_dst, scale: float = 1.0, window=None, max_side: int = 1600):
    """Деформирует спрайт по скелету: тело делится на части по костям, каждая часть переносится своим преобразованием
    (поворот и растяжение вдоль кости) и накладывается по z. Швы между частями размыты и перекрываются.
    rgba: HxWx4 uint8; kp_src/kp_dst: 18x2 в пикселях спрайта. scale<1: черновой размер для живого предпросмотра.
    window=(x0,y0,w,h) в пикселях спрайта: рисовать в фиксированное окно (для редактора). Иначе окно по содержимому.
    Возвращает (rgba_out, origin_xy, fill_mask): origin: левый верх результата в координатах спрайта; fill_mask:
    «дыры» внутри тела, открывшиеся при смене позы (их стоит дорисовать inpaint'ом); оба в масштабе результата."""
    h0, w0 = rgba.shape[:2]
    k = max(.25, min(scale * 2.0, max_side / max(h0, w0)))  # работаем крупнее и сжимаем: ровные края
    big = cv2.resize(rgba, (max(2, int(round(w0 * k))), max(2, int(round(h0 * k)))),
                     interpolation=cv2.INTER_CUBIC if k > 1 else cv2.INTER_AREA)
    h, w = big.shape[:2]
    ks, kt = np.asarray(kp_src, float) * k, np.asarray(kp_dst, float) * k
    A = big[..., 3]
    mask = A > 127
    Hs = float(max(np.ptp(ks[:, 1]), 1))

    bones = _bones(ks, kt, mask)
    J = len(bones)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    dt = cv2.distanceTransform(mask.astype(np.uint8), cv2.DIST_L2, 5)

    # радиус кости = полутолщина тела вдоль неё (по карте расстояний): им нормируем «чья это часть»
    rad = []
    for name, a, b, _, _ in bones:
        pts = a[None] + (b - a)[None] * np.linspace(.2, .8, 12)[:, None]
        v = np.array([dt[int(np.clip(round(y), 0, h - 1)), int(np.clip(round(x), 0, w - 1))] for x, y in pts])
        r = np.percentile(v, 35) if name not in ("spine", "head") else v.max()
        rad.append(float(np.clip(r, 2.0, .3 * Hs)))

    # владелец пикселя: кость с наименьшим расстоянием/радиус
    best = np.full((h, w), np.inf, np.float32); own = np.zeros((h, w), np.int16)
    for j, (name, a, b, _, _) in enumerate(bones):
        nd = _seg_dist(xx, yy, a, b) / (rad[j] + .02 * Hs)
        upd = nd < best
        best[upd] = nd[upd]; own[upd] = j
    # Hands in front of the waist are closer (after radius normalisation) to
    # the broad torso than to their own forearm. Give the arm's narrow capsule
    # ownership before moving it, so the old hand is not left on the stomach.
    arm_best = np.full((h, w), np.inf, np.float32)
    for j, (name, a, b, _, _) in enumerate(bones):
        if not name.startswith(("uarm", "farm")):
            continue
        radius = float(np.clip(rad[j], .018 * Hs, .055 * Hs))
        distance = _seg_dist(xx, yy, a, b)
        score = distance / radius
        selected = (score < 1.45) & (score < arm_best) & mask
        own[selected] = j
        arm_best[selected] = score[selected]
    W = []
    for j in range(J):
        # Each source pixel moves with exactly one bone. Growing every part
        # before rotation duplicates hands and pieces of sleeves in two places.
        W.append((own == j).astype(np.float32))

    pm = big.astype(np.float32); pm[..., :3] *= pm[..., 3:4] / 255.0  # премультипликация: чистые края

    # affine каждой кости: вдоль кости длина масштабируется, толщина нет
    Ms, corners = [], []
    for j, (name, a_s, b_s, a_t, b_t) in enumerate(bones):
        us = b_s - a_s; Ls = max(np.hypot(*us), 1.0); us = us / Ls; vs = np.array([-us[1], us[0]])
        ut = b_t - a_t; Lt = np.hypot(*ut); ut = ut / (Lt + 1e-9) if Lt > 1e-6 else us; vt = np.array([-ut[1], ut[0]])
        sl = float(np.clip(Lt / Ls, .35, 2.5))
        Lm = sl * np.outer(ut, us) + np.outer(vt, vs)
        t = a_t - Lm @ a_s
        Ms.append(np.hstack([Lm, t[:, None]]))
        yj, xj = np.where((W[j] > .05) & (A > 0))
        if len(xj):
            c = np.array([[xj.min(), yj.min()], [xj.max(), yj.min()], [xj.min(), yj.max()], [xj.max(), yj.max()]], float)
            corners.append(c @ Lm.T + t)
    allc = np.vstack(corners) if corners else np.array([[0, 0], [w, h]], float)
    if window is None:
        x0, y0 = np.floor(allc[:, 0].min()) - 2, np.floor(allc[:, 1].min()) - 2
        Wo, Ho = int(np.ceil(allc[:, 0].max() - x0)) + 3, int(np.ceil(allc[:, 1].max() - y0)) + 3
    else:
        x0, y0, Wo, Ho = window[0] * k, window[1] * k, int(round(window[2] * k)), int(round(window[3] * k))

    out = np.zeros((Ho, Wo, 4), np.float32)
    moved_arms = np.zeros((Ho, Wo), np.uint8)
    for j in range(J):  # от дальних костей к ближним
        M = Ms[j].copy(); M[:, 2] -= (x0, y0)
        part = cv2.warpAffine(pm * W[j][..., None], M, (Wo, Ho), flags=cv2.INTER_LINEAR,
                              borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
        out = part + out * (1 - part[..., 3:4] / 255.0)
        if bones[j][0].startswith(("uarm", "farm")):
            moved_arms[part[..., 3] > 100] = 255
    covered = out[..., 3] > 128

    # дыры, открывшиеся внутри тела (был закрыт рукой): замыкание по контуру
    kc = max(3, int(.07 * Hs)) | 1
    closed = cv2.morphologyEx(covered.astype(np.uint8), cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kc, kc)))
    fill = (closed > 0) & ~covered
    inv = (~covered).astype(np.uint8)  # полностью замкнутые «окна» внутри фигуры заполняем при любом размере
    padded = cv2.copyMakeBorder(inv, 1, 1, 1, 1, cv2.BORDER_CONSTANT, value=1)
    cv2.floodFill(padded, np.zeros((Ho + 4, Wo + 4), np.uint8), (0, 0), 2)
    fill |= (inv == 1) & (padded[1:-1, 1:-1] != 2)
    # Reconstruct the torso revealed by a hand that was resting on the waist.
    # Closing the silhouette alone misses these open-sided occlusion holes.
    torso = np.zeros((Ho, Wo), np.uint8)
    torso_pts = kt[[RSH, LSH, LHIP, RHIP]] - (x0, y0)
    cv2.fillConvexPoly(torso, np.round(torso_pts).astype(np.int32), 255)
    fill |= (torso > 0) & ~covered
    spine_matrix = Ms[next(i for i, bone in enumerate(bones) if bone[0] == "spine")]
    for elbow, wrist in ((REL, RWR), (LEL, LWR)):
        if np.linalg.norm(kt[wrist] - ks[wrist]) < .05 * Hs:
            continue
        point = spine_matrix[:, :2] @ ks[wrist] + spine_matrix[:, 2] - (x0, y0)
        old_hand = np.zeros((Ho, Wo), np.uint8)
        cv2.circle(old_hand, tuple(np.round(point).astype(int)), int(.085 * Hs), 255, -1)
        fill |= (old_hand > 0) & (torso > 0) & (moved_arms == 0)
    fill = cv2.morphologyEx(fill.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8)) > 0

    a = np.maximum(out[..., 3:4], 1e-6)
    rgb = np.clip(out[..., :3] / a * 255.0, 0, 255)
    res = np.dstack([rgb, np.clip(out[..., 3:4], 0, 255)]).astype(np.uint8)
    fill_u8 = fill.astype(np.uint8) * 255

    if abs(k - scale) > 1e-6:  # вернуться к масштабу scale
        tw, th = max(1, int(round(Wo * scale / k))), max(1, int(round(Ho * scale / k)))
        pmr = cv2.resize(np.dstack([res[..., :3].astype(np.float32) * res[..., 3:4] / 255.0, res[..., 3:4].astype(np.float32)]),
                         (tw, th), interpolation=cv2.INTER_AREA)
        a2 = np.maximum(pmr[..., 3:4], 1e-6)
        res = np.dstack([np.clip(pmr[..., :3] / a2 * 255.0, 0, 255), pmr[..., 3:4]]).astype(np.uint8)
        fill_u8 = cv2.resize(fill_u8, (tw, th), interpolation=cv2.INTER_AREA)
    origin = (x0 / k, y0 / k)
    if window is None:  # обрезаем по содержимому
        ys, xs = np.where((res[..., 3] > 0) | (fill_u8 > 0))
        if len(xs):
            cx0, cx1, cy0, cy1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
            res, fill_u8 = res[cy0:cy1, cx0:cx1], fill_u8[cy0:cy1, cx0:cx1]
            origin = (origin[0] + cx0 / scale, origin[1] + cy0 / scale)
    return res, origin, fill_u8


def bleed_rgb(rgba: np.ndarray) -> np.ndarray:
    """RGB спрайта, где прозрачные места закрашены продолжением соседних цветов (а не серым): контекст для inpaint."""
    rgb = np.ascontiguousarray(rgba[..., :3])
    transparent = (rgba[..., 3] < 128).astype(np.uint8) * 255
    if not transparent.any() or transparent.all():
        return rgb
    return cv2.inpaint(rgb, transparent, 3, cv2.INPAINT_TELEA)


def apply_fill(rgba: np.ndarray, fill: np.ndarray, filled_rgb: np.ndarray) -> np.ndarray:
    """Вклеить дорисованные пиксели в дыры: цвет из inpaint, альфа = полная, края мягкие."""
    sel = cv2.GaussianBlur((fill > 0).astype(np.float32), (5, 5), 0)[..., None]
    out = rgba.copy()
    out[..., :3] = (filled_rgb * sel + rgba[..., :3] * (1 - sel)).astype(np.uint8)
    out[..., 3] = np.maximum(rgba[..., 3], (sel[..., 0] * 255).astype(np.uint8))
    return out


# ───────────────────────── подгонка стартового скелета ─────────────────────────
_SWAP = [0, 1, 5, 6, 7, 2, 3, 4, 11, 12, 13, 8, 9, 10, 15, 14, 17, 16]  # перестановка правая<->левая при отражении


def mirror_kp(kp, width: float) -> np.ndarray:
    """Скелет отражённого по горизонтали спрайта шириной width: x -> width - x, правая и левая стороны меняются местами."""
    k = np.asarray(kp, float).copy(); k[:, 0] = width - k[:, 0]
    return k[_SWAP]


def _sane(k: np.ndarray, H: float) -> bool:
    """Грубая проверка человеческой геометрии: голова над шеей, ноги ниже таза, плечи и бёдра не схлопнуты."""
    p = pelvis(k)
    return bool(k[NOSE][1] < k[NECK][1] < p[1] and p[1] < k[RKN][1] + .05 * H and p[1] < k[LKN][1] + .05 * H
                and k[RKN][1] < max(k[RAN][1], k[LAN][1]) + .02 * H
                and abs(k[RSH][0] - k[LSH][0]) > .05 * H and np.ptp(k[:, 1]) > .5 * H)


def merge_detected(alpha: np.ndarray, kp_det, conf, min_conf: float = .25):
    """Скелет от детектора + запасной по силуэту. Точки с низкой уверенностью или вне силуэта заменяются силуэтными.
    Возвращает (kp 18x2, method, число точек от детектора)."""
    ks = fit_from_mask(alpha)
    m = alpha > 127
    ys, xs = np.where(m); H = float(ys.max() - ys.min() + 1)
    if kp_det is None:
        return ks, "silhouette", 0
    kd = np.asarray(kp_det, float); cf = np.asarray(conf, float)
    if kd.shape != (18, 2) or not _sane(kd, H):
        return ks, "silhouette", 0
    dist, lab = cv2.distanceTransformWithLabels((~m).astype(np.uint8), cv2.DIST_L2, 5, labelType=cv2.DIST_LABEL_PIXEL)
    # координаты ближайшего пикселя маски для каждой метки
    ids = lab[m]; pos = {int(i): (x, y) for i, x, y in zip(ids, xs, ys)}
    out, used = ks.copy(), 0
    for j in range(18):
        x, y = kd[j]
        xi, yi = int(np.clip(round(x), 0, m.shape[1] - 1)), int(np.clip(round(y), 0, m.shape[0] - 1))
        d = float(dist[yi, xi])
        if cf[j] < min_conf or d > .06 * H:  # не уверены или далеко за силуэтом: берём силуэтную точку
            continue
        if d > 0:  # слегка снаружи: прижимаем к ближайшему пикселю силуэта
            x, y = pos.get(int(lab[yi, xi]), (x, y))
        out[j] = (x, y); used += 1
    if used < 10 or not _sane(out, H):
        return ks, "silhouette", 0
    return out, "detector", used


# ───────────────────────── что нужно перерисовать после деформации ─────────────────────────
LIMBS_B = [(RSH, REL), (REL, RWR), (LSH, LEL), (LEL, LWR), (RHIP, RKN), (RKN, RAN), (LHIP, LKN), (LKN, LAN)]
JOINTS = [(RSH, REL, RWR), (LSH, LEL, LWR), (RHIP, RKN, RAN), (LHIP, LKN, LAN)]  # (корень, сустав, конец)


def _limb_radii(alpha: np.ndarray, ks: np.ndarray, H: float) -> dict:
    dt = cv2.distanceTransform((alpha > 127).astype(np.uint8), cv2.DIST_L2, 5)
    out = {}
    for a, b in LIMBS_B:
        pts = ks[a][None] + (ks[b] - ks[a])[None] * np.linspace(.2, .8, 10)[:, None]
        v = [dt[int(np.clip(round(y), 0, dt.shape[0] - 1)), int(np.clip(round(x), 0, dt.shape[1] - 1))] for x, y in pts]
        out[(a, b)] = float(np.clip(np.percentile(v, 40), .012 * H, .08 * H))
    return out


def _ang(v):
    return np.degrees(np.arctan2(v[1], v[0]))


def repair_mask(out_alpha: np.ndarray, fill: np.ndarray, rgba_src: np.ndarray, kp_src, kp_dst, origin) -> np.ndarray:
    """Где после деформации картинка ненадёжна и её стоит перерисовать (uint8 0/255 в координатах результата):
    1) дыры внутри тела; 2) участки, где по скелету должна быть рука или нога, а пикселей нет; 3) сильно согнутые суставы
    (швы между частями). Остальное остаётся исходными пикселями."""
    h, w = out_alpha.shape
    ks, kt = np.asarray(kp_src, float), np.asarray(kp_dst, float) - np.asarray(origin, float)[None]
    H = float(max(np.ptp(ks[:, 1]), 1))
    rad = _limb_radii(rgba_src[..., 3], ks, H)
    covered = out_alpha > 127
    miss = np.zeros((h, w), np.uint8)
    for (a, b), r in rad.items():
        cap = np.zeros((h, w), np.uint8)
        cv2.line(cap, tuple(np.round(kt[a]).astype(int)), tuple(np.round(kt[b]).astype(int)), 255, max(2, int(2 * r * .9)))
        cv2.circle(cap, tuple(np.round(kt[b]).astype(int)), int(r * .9), 255, -1)
        miss |= cap & (~covered).astype(np.uint8) * 255
        rotation = abs((_ang(kt[b] - kt[a]) - _ang(ks[b] - ks[a]) + 180) % 360 - 180)
        if rotation > 30:
            # Repair the entire rotated limb, including its cut boundaries,
            # rather than just a tiny circle at the elbow.
            miss |= cap
    miss = cv2.morphologyEx(miss, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    seams = np.zeros((h, w), np.uint8)
    for r0, j, e in JOINTS:
        d_src = abs((_ang(ks[e] - ks[j]) - _ang(ks[j] - ks[r0]) + 180) % 360 - 180)
        d_dst = abs((_ang(kt[e] - kt[j]) - _ang(kt[j] - kt[r0]) + 180) % 360 - 180)
        if abs(d_dst - d_src) > 22:  # сустав согнули заметно сильнее/слабее, чем он был
            r = rad[(r0, j)]
            cv2.circle(seams, tuple(np.round(kt[j]).astype(int)), int(r * 1.5), 255, -1)
    # плечо/бедро: ось «торс -> конечность» повернулась
    for r0, j, _ in JOINTS:
        par = NECK if r0 in (RSH, LSH) else PELVIS
        pk_s, pk_t = _ext(ks)[par], _ext(kt)[par]
        d = abs((_ang(kt[j] - kt[r0]) - _ang(ks[j] - ks[r0]) + 180) % 360 - 180)
        if d > 35:
            cv2.circle(seams, tuple(np.round(kt[r0]).astype(int)), int(rad[(r0, j)] * 1.4), 255, -1)
    m = np.maximum(miss, seams) | (fill > 0).astype(np.uint8) * 255
    torso_affine = cv2.getAffineTransform(ks[[NECK, RHIP, LHIP]].astype(np.float32), kt[[NECK, RHIP, LHIP]].astype(np.float32))
    for wrist in (RWR, LWR):
        original_in_torso = torso_affine[:, :2] @ ks[wrist] + torso_affine[:, 2]
        if np.linalg.norm(kt[wrist] - original_in_torso) > .08 * H:
            cv2.circle(m, tuple(np.round(original_in_torso).astype(int)), int(.11 * H), 255, -1)
    m = cv2.dilate(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7)))
    # снимаем лишнее: перерисовываем только там, где либо есть персонаж, либо должна быть конечность
    area = max(1, int((out_alpha > 127).sum()))
    if (m > 0).sum() < .004 * area:  # поза почти не менялась: чинить нечего
        return np.zeros_like(m)
    return m


def content_box(alpha: np.ndarray, mask: np.ndarray, pad_frac: float = .06):
    """Рамка вокруг тела и маски (x0, y0, x1, y1) с полем."""
    ys, xs = np.where((alpha > 8) | (mask > 0))
    if len(xs) == 0:
        return 0, 0, alpha.shape[1], alpha.shape[0]
    p = int(pad_frac * max(ys.max() - ys.min(), xs.max() - xs.min()))
    return (max(0, xs.min() - p), max(0, ys.min() - p), min(alpha.shape[1], xs.max() + p + 1), min(alpha.shape[0], ys.max() + p + 1))
