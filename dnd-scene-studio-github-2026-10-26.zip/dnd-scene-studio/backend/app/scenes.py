"""Хранилище сцен и история изменений.

Файлы (фон-версии, спрайты) неизменяемы и никогда не перезаписываются, поэтому undo/redo = переключение
между снимками состояния {bg, layers}. Тяжёлых данных история не дублирует.
"""
import json, os, uuid
from pathlib import Path

from fastapi import HTTPException

DATA = Path(os.getenv("DATA_DIR", "data")); DATA.mkdir(parents=True, exist_ok=True)
HISTORY_LIMIT = 200
EDITABLE = ("x", "y", "width", "height", "rotation", "visible", "name")


def new_id(n: int = 8) -> str:
    return uuid.uuid4().hex[:n]


def sdir(sid: str) -> Path:
    p = DATA / sid
    if not sid.isalnum() or not (p / "scene.json").exists():
        raise HTTPException(404, "Сцена не найдена")
    return p


def load(p: Path) -> dict:
    return json.loads((p / "scene.json").read_text(encoding="utf-8"))


def _state(m: dict) -> dict:
    return {"bg": m["bg"], "layers": m["layers"]}


def _write(p: Path, name: str, obj) -> None:
    tmp = p / (name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False), encoding="utf-8"); tmp.replace(p / name)


def create(prompt: str, seed: int | None, bg: str) -> tuple[Path, dict]:
    sid = new_id(10); p = DATA / sid; (p / "masks").mkdir(parents=True)
    m = {"id": sid, "prompt": prompt, "seed": seed, "bg": bg, "layers": []}
    _write(p, "scene.json", m); _write(p, "history.json", {"stack": [_state(m)], "cursor": 0})
    return p, m


def commit(p: Path, m: dict) -> dict:
    """Сохранить новое состояние и добавить его в историю (всё, что после курсора, отбрасывается)."""
    h = json.loads((p / "history.json").read_text(encoding="utf-8"))
    stack = h["stack"][: h["cursor"] + 1] + [_state(m)]
    stack = stack[-HISTORY_LIMIT:]
    _write(p, "scene.json", m); _write(p, "history.json", {"stack": stack, "cursor": len(stack) - 1})
    return m


def move_cursor(p: Path, m: dict, step: int) -> dict:
    h = json.loads((p / "history.json").read_text(encoding="utf-8"))
    c = h["cursor"] + step
    if not 0 <= c < len(h["stack"]):
        raise HTTPException(409, "Больше нечего отменять" if step < 0 else "Больше нечего повторять")
    m.update(h["stack"][c]); h["cursor"] = c
    _write(p, "scene.json", m); _write(p, "history.json", h)
    return m


def history_info(p: Path) -> dict:
    h = json.loads((p / "history.json").read_text(encoding="utf-8"))
    return {"can_undo": h["cursor"] > 0, "can_redo": h["cursor"] < len(h["stack"]) - 1}


def view(p: Path, m: dict) -> dict:
    """Метаданные сцены + URL-ы для фронтенда."""
    base = f"/files/{m['id']}/"
    return {**m, **history_info(p), "bg_url": base + m["bg"],
            "layers": [{**{"visible": True, "name": "Объект"}, **l, "url": base + l["src"]} for l in m["layers"]]}


def apply_state(m: dict, layers: list[dict]) -> None:
    """Принять от клиента порядок слоёв, удаления и правку геометрии. src и id клиент менять не может."""
    known = {l["id"]: l for l in m["layers"]}
    m["layers"] = [{**known[l["id"]], **{k: l[k] for k in EDITABLE if k in l}}
                   for l in layers if l.get("id") in known]
