"""Клиент GPU-воркера.

Воркер не задан -> mock-режим (работает без GPU, нужен для разработки и тестов).
Адрес и токен можно менять на лету через POST /api/worker: перезапускать бэкенд после каждого
перезапуска Colab не нужно. Последние значения сохраняются в data/worker.json.
"""
import hashlib, io, json, os, random, re
from pathlib import Path

import cv2, httpx, numpy as np
from fastapi import HTTPException
from PIL import Image, ImageDraw, ImageFilter

Point = tuple[int, int]


def describe(e: Exception) -> str:
    """Причина сбоя связи человеческим языком."""
    if isinstance(e, httpx.HTTPStatusError):
        c = e.response.status_code
        if c in (502, 503, 504, 520, 521, 522, 523, 524, 530) or c == 404:
            return f"туннель вернул {c}: сессия Colab остановлена или адрес устарел. Перезапустите последнюю ячейку и возьмите новый адрес"
        return f"воркер вернул HTTP {c}"
    if isinstance(e, (httpx.ConnectTimeout, httpx.ReadTimeout, httpx.PoolTimeout)):
        return "таймаут: адрес не открывается с этого компьютера (сеть, VPN или блокировка trycloudflare.com)"
    if isinstance(e, httpx.ConnectError):
        return "не удалось соединиться: проверьте адрес и интернет (возможно, мешает VPN или блокировка trycloudflare.com)"
    return f"{type(e).__name__}: {e}"[:200]


def clean_url(raw: str) -> str:
    """Принимает адрес в любом виде: с «Адрес =», пробелами, /health на конце, без https://."""
    m = re.search(r"https?://[^\s'\"<>]+", raw)
    u = m.group(0) if m else raw.strip().split("=")[-1].strip()
    if not u.startswith("http"):
        u = "https://" + u.lstrip("/")
    u = u.rstrip("/")
    return u[:-7] if u.endswith("/health") else u


def clean_token(raw: str) -> str:
    return raw.strip().split("=")[-1].strip() if "=" in raw else raw.strip()


def image_id(png: bytes) -> str:
    return hashlib.sha1(png).hexdigest()[:16]


from urllib.parse import unquote


class MockWorker:
    kind = "mock"

    def status(self) -> dict:
        return {"kind": "mock", "connected": True, "ready": True, "gpu": False, "lama": False}

    def generate(self, prompt: str, w: int, h: int, seed: int | None, kind: str = "scene", hint: str = "", avoid: str = "") -> bytes:
        self.last_prompt = prompt
        if kind in ("character", "object"):
            img = Image.new("RGB", (w, h), (200, 200, 200)); d = ImageDraw.Draw(img)
            if kind == "character":
                d.ellipse([w*.4, h*.12, w*.6, h*.27], fill=(150, 90, 60)); d.rectangle([w*.35, h*.27, w*.65, h*.8], fill=(70, 100, 160))
            else:
                d.rectangle([w*.25, h*.4, w*.75, h*.75], fill=(120, 80, 40)); d.rectangle([w*.2, h*.35, w*.8, h*.42], fill=(90, 60, 30))
            buf = io.BytesIO(); img.save(buf, "PNG"); return buf.getvalue()
        rnd = random.Random(seed if seed is not None else prompt)
        img = Image.new("RGB", (w, h), (40, 34, 30))
        d = ImageDraw.Draw(img)
        d.rectangle([0, int(h * .62), w, h], fill=(78, 62, 48))
        for _ in range(5):  # условные «объекты»
            cx, cy, r = rnd.randint(120, w - 120), rnd.randint(int(h * .4), int(h * .8)), rnd.randint(40, 80)
            d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=tuple(rnd.randint(80, 230) for _ in range(3)))
        d.text((16, 12), f"MOCK: {prompt[:70]}", fill=(232, 220, 196))
        buf = io.BytesIO(); img.filter(ImageFilter.GaussianBlur(.6)).save(buf, "PNG")
        return buf.getvalue()

    def segment(self, png: bytes, points: list[Point], labels: list[int], box=None) -> np.ndarray:
        rgb = np.array(Image.open(io.BytesIO(png)).convert("RGB"))
        h, w, _ = rgb.shape
        if box:
            diff = np.abs(rgb.astype(int) - rgb[2, 2].astype(int)).sum(2)
            return ((diff > 40) * 255).astype(np.uint8)
        pos = [p for p, l in zip(points, labels) if l == 1]
        if not pos:
            raise HTTPException(422, "Объект не найден, кликните точнее")
        yy, xx = np.ogrid[:h, :w]
        out = np.zeros((h, w), np.uint8)
        for (x, y) in pos:  # заливка похожего цвета вокруг каждой положительной точки
            ff = np.zeros((h + 2, w + 2), np.uint8)
            cv2.floodFill(rgb.copy(), ff, (int(x), int(y)), (0, 0, 0), (28,) * 3, (28,) * 3,
                          cv2.FLOODFILL_MASK_ONLY | (255 << 8) | 4)
            near = (ff[1:-1, 1:-1] > 0) & ((xx - x) ** 2 + (yy - y) ** 2 < 170 ** 2)
            out |= near.astype(np.uint8)
        for (x, y), l in zip(points, labels):
            if l == 0:
                out[(xx - x) ** 2 + (yy - y) ** 2 < 40 ** 2] = 0
        return out * 255

    def inpaint(self, png: bytes, mask: np.ndarray) -> bytes:
        bgr = cv2.cvtColor(np.array(Image.open(io.BytesIO(png)).convert("RGB")), cv2.COLOR_RGB2BGR)
        out = cv2.inpaint(bgr, (mask > 0).astype(np.uint8) * 255, 5, cv2.INPAINT_TELEA)
        buf = io.BytesIO(); Image.fromarray(cv2.cvtColor(out, cv2.COLOR_BGR2RGB)).save(buf, "PNG")
        return buf.getvalue()

    def harmonize(self, png: bytes, mask: np.ndarray, prompt: str, strength: float, hint: str = "") -> bytes:
        return png  # демо-режим: без нейросети картинка не меняется

    def matte(self, png: bytes):
        img = np.array(Image.open(io.BytesIO(png)).convert("RGB")).astype(int)
        return ((np.abs(img - img[2, 2]).sum(2) > 40) * 255).astype(np.uint8)

    def pose(self, prompt: str, seed, skeleton_png: bytes, hint: str = "", ref: bytes | None = None, ip_scale: float = .6) -> bytes:
        return self.generate(prompt, 768, 1024, seed, "character", hint)

    def pose_edit(self, image: bytes, guide: bytes, action: str, seed: int) -> bytes:
        raise HTTPException(503, "Новый редактор позы требует GPU-воркер; демо-режим его не заменяет.")

    def repair(self, png: bytes, mask: np.ndarray, ref: bytes | None, prompt: str, seed, ip_scale: float, hint: str = ""):
        return None  # демо-режим: без нейросети починки нет

    def skeleton(self, png: bytes):
        return None  # без нейросети скелет подгоняется по силуэту (rig.fit_from_mask)

    def refine(self, png: bytes, prompt: str, strength: float, seed, hint: str = ""):
        return None  # демо-режим: доработки нет


class RemoteWorker:
    kind = "remote"

    def __init__(self, url: str, token: str, proxy: bool = False):
        self.url, self.proxy = clean_url(url), proxy
        # по умолчанию системный прокси не используется; если без него связи нет, connect() пробует с ним
        self.c = httpx.Client(base_url=self.url, headers={"X-Token": token},
                              timeout=httpx.Timeout(300, connect=20), trust_env=proxy)

    def status(self) -> dict:
        try:
            r = self.c.get("/health", timeout=20); r.raise_for_status()
            return {"kind": "remote", "connected": True, "url": self.url, **r.json()}
        except (httpx.HTTPError, ValueError) as e:
            return {"kind": "remote", "connected": False, "url": self.url, "ready": False, "error": describe(e)}

    def _post(self, path, allow=(), **kw):
        """POST с понятными ошибками. Статусы из allow возвращаются как есть (например 409 need_image)."""
        try:
            r = self.c.post(path, **kw)
            if r.status_code in allow:
                return r
            r.raise_for_status(); return r
        except httpx.HTTPStatusError as e:
            code = e.response.status_code
            if code == 503 and "application/json" in e.response.headers.get("content-type", ""):
                try:
                    detail = e.response.json().get("detail")
                except ValueError:
                    detail = None
                if isinstance(detail, str):
                    raise HTTPException(503, detail) from e
            if code == 401:
                raise HTTPException(502, "Воркер отклонил токен: проверьте токен в панели подключения")
            if code == 422:
                raise HTTPException(422, "Объект не найден, кликните точнее")
            if code in (502, 503, 504, 520, 521, 522, 523, 524, 530) or "<html" in e.response.text[:300].lower():
                raise HTTPException(502, f"Туннель Cloudflare отвечает ({code}), но сам воркер в Colab не работает: процесс упал "
                                         "(часто из-за нехватки памяти) или ещё грузит модели. В Colab выполните в новой ячейке "
                                         "`!tail -n 60 server.log`, затем запустите последнюю ячейку заново.")
            raise HTTPException(502, f"Воркер вернул {code}: {e.response.text[:700]}")
        except httpx.HTTPError as e:
            raise HTTPException(502, f"Нет связи с GPU-воркером: {describe(e)}")

    def generate(self, prompt, w, h, seed, kind="scene", hint="", avoid="") -> bytes:
        r = self._post("/generate", json={"prompt": prompt, "width": w, "height": h, "seed": seed, "kind": kind, "hint": hint, "avoid": avoid})
        self.last_prompt = unquote(r.headers.get("x-prompt", "")) or None  # что реально ушло в нейросеть (после перевода)
        return r.content

    def segment(self, png, points, labels, box=None) -> np.ndarray:
        data = {"image_id": image_id(png), "points": json.dumps([list(p) for p in points]),
                "labels": json.dumps(list(labels)), **({"box": ",".join(map(str, box))} if box else {})}
        r = self._post("/segment", allow=(409,), data=data)  # без картинки: вдруг воркер её уже держит в кэше
        if r.status_code == 409:
            r = self._post("/segment", data=data, files={"image": ("bg.png", png, "image/png")})
        return np.array(Image.open(io.BytesIO(r.content)).convert("L"))

    def inpaint(self, png: bytes, mask: np.ndarray) -> bytes:
        mbuf = io.BytesIO(); Image.fromarray(mask).save(mbuf, "PNG")
        return self._post("/inpaint", files={"image": ("bg.png", png, "image/png"),
                                              "mask": ("mask.png", mbuf.getvalue(), "image/png")}).content

    def harmonize(self, png: bytes, mask: np.ndarray, prompt: str, strength: float, hint: str = "") -> bytes:
        mbuf = io.BytesIO(); Image.fromarray(mask).save(mbuf, "PNG")
        return self._post("/harmonize", data={"prompt": prompt, "strength": strength, "hint": hint},
                          files={"image": ("scene.png", png, "image/png"),
                                 "mask": ("mask.png", mbuf.getvalue(), "image/png")}).content

    def matte(self, png: bytes):
        """Отделение фона специальной моделью. None, если воркер её не поднял (тогда запасной путь через SAM)."""
        r = self._post("/matte", allow=(501,), files={"image": ("sprite.png", png, "image/png")})
        return None if r.status_code == 501 else np.array(Image.open(io.BytesIO(r.content)).convert("L"))

    def pose(self, prompt: str, seed, skeleton_png: bytes, hint: str = "", ref: bytes | None = None, ip_scale: float = .6) -> bytes:
        files = {"skeleton": ("pose.png", skeleton_png, "image/png"), **({"ref": ("ref.png", ref, "image/png")} if ref else {})}
        return self._post("/pose", data={"prompt": prompt, "hint": hint, "ip_scale": ip_scale, **({"seed": seed} if seed is not None else {})}, files=files).content

    def pose_edit(self, image: bytes, guide: bytes, action: str, seed: int) -> bytes:
        response = self._post("/pose-edit", data={"action": action, "seed": seed}, timeout=httpx.Timeout(920, connect=20),
                              files={"image": ("reference.png", image, "image/png"),
                                     "guide": ("pose.png", guide, "image/png")})
        if response.headers.get("X-Pose-Quality") != "hands-v1":
            raise HTTPException(503, "GPU-воркер не подтвердил новую проверку позы. Обновите и перезапустите воркер.")
        return response.content

    def repair(self, png: bytes, mask: np.ndarray, ref: bytes | None, prompt: str, seed, ip_scale: float, hint: str = ""):
        """Починка маски нейросетью с образцом внешности. Возвращает PNG (RGBA)."""
        mbuf = io.BytesIO(); Image.fromarray(mask).save(mbuf, "PNG")
        files = {"image": ("sprite.png", png, "image/png"), "mask": ("mask.png", mbuf.getvalue(), "image/png"),
                 **({"ref": ("ref.png", ref, "image/png")} if ref else {})}
        return self._post("/repair", data={"prompt": prompt, "hint": hint, "ip_scale": ip_scale,
                                           **({"seed": seed} if seed is not None else {})}, files=files).content

    def skeleton(self, png: bytes):
        """Скелет детектором на воркере: {'kp': 18x2 в пикселях, 'conf': 18} или None (не нашёл / детектор недоступен)."""
        r = self._post("/skeleton", allow=(501,), files={"image": ("sprite.png", png, "image/png")})
        if r.status_code == 501:
            return None
        d = r.json()
        return d if d.get("found") else None

    def refine(self, png: bytes, prompt: str, strength: float, seed, hint: str = ""):
        """SDXL img2img малой силы по деформированному спрайту. Возвращает PNG (RGBA) или None, если GPU нет."""
        return self._post("/refine", data={"prompt": prompt, "strength": strength, "hint": hint, **({"seed": seed} if seed is not None else {})},
                          files={"image": ("sprite.png", png, "image/png")}).content


class Holder:
    """Текущий воркер. Переключается без перезапуска бэкенда."""

    def __init__(self, data: Path):
        self.cfg = data / "worker.json"
        url, token, proxy = os.getenv("WORKER_URL"), os.getenv("WORKER_TOKEN", ""), False
        if not url and self.cfg.exists():
            try:
                c = json.loads(self.cfg.read_text(encoding="utf-8")); url, token, proxy = c.get("url"), c.get("token", ""), c.get("proxy", False)
            except Exception:
                url = None
        self.worker = RemoteWorker(url, token, proxy) if url else MockWorker()

    def connect(self, url: str, token: str):
        token = clean_token(token)
        for proxy in (False, True):  # сначала напрямую, затем через системный прокси/VPN
            w = RemoteWorker(url, token, proxy); st = w.status()
            if st["connected"]:
                self.worker = w
                self.cfg.write_text(json.dumps({"url": w.url, "token": token, "proxy": proxy}), encoding="utf-8")
                return st
            first = first if proxy else st.get("error")
        raise HTTPException(502, f"Воркер {w.url} не отвечает: {first}")

    def disconnect(self):
        self.worker = MockWorker()
        self.cfg.unlink(missing_ok=True)
