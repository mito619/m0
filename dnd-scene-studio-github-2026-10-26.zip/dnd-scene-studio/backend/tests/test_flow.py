import io, json, os, tempfile, zipfile
os.environ["DATA_DIR"] = tempfile.mkdtemp()
os.environ.pop("WORKER_URL", None)

import numpy as np
from fastapi.testclient import TestClient
from PIL import Image

from app.main import app

c = TestClient(app)


def scene():
    r = c.post("/api/scenes", json={"prompt": "таверна", "seed": 1}); assert r.status_code == 200, r.text
    return r.json()


def pick(s, x, y):
    r = c.post(f"/api/scenes/{s['id']}/segment", json={"points": [{"x": x, "y": y}]}); assert r.status_code == 200, r.text
    return r.json()


def test_health_mock():
    assert c.get("/api/health").json()["worker"]["kind"] == "mock"


def test_saved_scene_can_be_reopened_with_its_layers():
    s = scene()
    added = c.post(f"/api/scenes/{s['id']}/characters", json={"prompt": "chest", "kind": "object", "seed": 1}).json()
    saved = c.get("/api/scenes").json()["scenes"]
    restored = next(item for item in saved if item["id"] == s["id"])
    assert restored["layers"] == added["layers"]
    assert restored["bg_url"] == added["bg_url"]


def test_clean_background_preserves_rgb_and_can_undo(monkeypatch):
    from app.main import holder
    from app import scenes as sc
    s = scene()
    s = c.post(f"/api/scenes/{s['id']}/characters", json={"prompt": "chest", "kind": "object", "seed": 1}).json()
    layer = s["layers"][0]
    folder = sc.sdir(s["id"])
    before = np.array(Image.open(folder / layer["orig"]).convert("RGBA"))

    def matte(png):
        w, h = Image.open(io.BytesIO(png)).size
        mask = np.full((h, w), 255, np.uint8)
        mask[:, :w // 3] = 0
        return mask

    monkeypatch.setattr(holder.worker, "matte", matte)
    response = c.post(f"/api/scenes/{s['id']}/layers/{layer['id']}/matte")
    assert response.status_code == 200, response.text
    after_layer = response.json()["layers"][0]
    after = np.array(Image.open(folder / after_layer["orig"]).convert("RGBA"))
    np.testing.assert_array_equal(after[..., :3], before[..., :3])
    assert after[..., 3].sum() < before[..., 3].sum()
    assert np.all(after[..., 3] <= before[..., 3])
    assert c.post(f"/api/scenes/{s['id']}/undo").json()["layers"][0]["src"] == layer["src"]


def test_full_flow_undo_redo_export():
    s = scene(); assert s["layers"] == [] and not s["can_undo"]
    # выбираем «объект» (в mock-сцене это цветной круг) и подтверждаем
    pv = None
    for x, y in [(200, 400), (500, 500), (800, 450), (300, 550), (600, 350)]:
        r = c.post(f"/api/scenes/{s['id']}/segment", json={"points": [{"x": x, "y": y}]})
        if r.status_code == 200: pv = r.json(); break
    assert pv, "mock-сегментация ничего не нашла"
    assert c.get(pv["preview_url"]).status_code == 200
    s2 = c.post(f"/api/scenes/{s['id']}/extract", json={"mask_id": pv["mask_id"]}).json()
    assert len(s2["layers"]) == 1 and s2["bg_url"] != s["bg_url"] and s2["can_undo"]
    l = s2["layers"][0]; assert l["width"] > 0 and l["visible"]

    # правка геометрии и порядка
    l2 = {**l, "x": 10, "y": 20, "rotation": 15}
    s3 = c.put(f"/api/scenes/{s['id']}/state", json={"layers": [l2]}).json()
    assert (s3["layers"][0]["x"], s3["layers"][0]["rotation"]) == (10, 15)
    # клиент не может подменить src
    s3 = c.put(f"/api/scenes/{s['id']}/state", json={"layers": [{**l2, "src": "../../etc/passwd"}]}).json()
    assert s3["layers"][0]["src"] == l["src"]

    # undo: возвращаемся к исходной позиции, затем к пустой сцене с исходным фоном
    s4 = c.post(f"/api/scenes/{s['id']}/undo").json(); assert s4["layers"][0]["x"] == 10
    s5 = c.post(f"/api/scenes/{s['id']}/undo").json(); assert s5["layers"][0]["x"] == l["x"]
    s6 = c.post(f"/api/scenes/{s['id']}/undo").json(); assert s6["layers"] == [] and s6["bg_url"] == s["bg_url"]
    assert c.post(f"/api/scenes/{s['id']}/undo").status_code == 409
    s7 = c.post(f"/api/scenes/{s['id']}/redo").json(); assert len(s7["layers"]) == 1 and s7["can_redo"]

    # слои: дубликат, отражение, замена, удаление
    lid = s7["layers"][0]["id"]
    s8 = c.post(f"/api/scenes/{s['id']}/layers/{lid}/duplicate").json(); assert len(s8["layers"]) == 2
    s9 = c.post(f"/api/scenes/{s['id']}/layers/{lid}/flip").json(); assert s9["layers"][0]["src"] != s8["layers"][0]["src"]
    s10 = c.post(f"/api/scenes/{s['id']}/layers/{lid}/replace", json={"prompt": "бочка", "kind": "object"})
    assert s10.status_code == 200, s10.text; assert s10.json()["layers"][0]["name"] == "бочка"
    s11 = c.put(f"/api/scenes/{s['id']}/state", json={"layers": s10.json()["layers"][1:]}).json(); assert len(s11["layers"]) == 1

    z = zipfile.ZipFile(io.BytesIO(c.get(f"/api/scenes/{s['id']}/export").content))
    names = z.namelist(); assert "scene.png" in names and "background.png" in names and any(n.startswith("layers/") for n in names)
    assert Image.open(io.BytesIO(z.read("scene.png"))).size == (1024, 768)


def test_add_character_and_errors():
    s = scene()
    r = c.post(f"/api/scenes/{s['id']}/characters", json={"prompt": "гном", "kind": "character"}); assert r.status_code == 200, r.text
    assert len(r.json()["layers"]) == 1
    assert c.post(f"/api/scenes/{s['id']}/segment", json={"points": [{"x": 5000, "y": 5}]}).status_code == 400
    assert c.post(f"/api/scenes/{s['id']}/segment", json={"points": [{"x": 5, "y": 5, "label": 0}]}).status_code == 400
    assert c.post(f"/api/scenes/{s['id']}/extract", json={"mask_id": "nope"}).status_code == 404
    assert c.get("/api/scenes/..%2F..").status_code == 404


def test_negative_point_shrinks_mask():
    s = scene()
    for x, y in [(200, 400), (500, 500), (800, 450), (300, 550), (600, 350)]:
        a = c.post(f"/api/scenes/{s['id']}/segment", json={"points": [{"x": x, "y": y}]})
        if a.status_code == 200: break
    else: raise AssertionError("нет объекта")
    b = c.post(f"/api/scenes/{s['id']}/segment", json={"points": [{"x": x, "y": y}, {"x": x + 20, "y": y, "label": 0}]}).json()
    assert b["area_pct"] < a.json()["area_pct"]


def test_cyrillic_roundtrip_any_locale():
    """Регрессия: на Windows файлы читались в cp1251, и вторая правка сцены с русским именем слоя падала с 500.
    Запускайте также как `PYTHONUTF8=0 LC_ALL=C pytest`: кодировка по умолчанию станет не-UTF-8."""
    s = scene()
    for prompt in ["гном-бард с лютней", "эльфийка-следопыт", "бочка эля"]:
        r = c.post(f"/api/scenes/{s['id']}/characters", json={"prompt": prompt, "kind": "character"})
        assert r.status_code == 200, r.text
    got = c.get(f"/api/scenes/{s['id']}").json()
    assert [l["name"] for l in got["layers"]] == ["гном-бард с лютней", "эльфийка-следопыт", "бочка эля"]
    assert c.post(f"/api/scenes/{s['id']}/undo").status_code == 200


def test_people_detection_and_kind():
    from app.prompts import wants_people
    yes = ["Таверна, за столом сидят гномы", "рыцарь у костра", "a bard and a gnome by the fire", "лагерь эльфов", "дракон над замком"]
    no = ["Пустая таверна, горит камин", "Оркестр не нужен, только лес", "бардак на складе", "тёмный подвал с бочками", "магазин зелий"]
    assert all(wants_people(t) for t in yes), [t for t in yes if not wants_people(t)]
    assert not any(wants_people(t) for t in no), [t for t in no if wants_people(t)]
    seen = []
    from app.main import holder
    orig = holder.worker.generate
    holder.worker.generate = lambda *a, **k: (seen.append(a[4] if len(a) > 4 else k.get("kind")), orig(*a, **k))[1]
    try:
        c.post("/api/scenes", json={"prompt": "таверна, за столом гномы"})
        c.post("/api/scenes", json={"prompt": "таверна, за столом гномы", "people": "no"})
        c.post("/api/scenes", json={"prompt": "пустая таверна", "people": "yes"})
        c.post("/api/scenes", json={"prompt": "пустая таверна"})
    finally:
        holder.worker.generate = orig
    assert seen == ["scene_people", "scene", "scene_people", "scene"], seen


def test_blend_layer_repeatable_and_undoable():
    s = scene()
    s2 = c.post(f"/api/scenes/{s['id']}/characters", json={"prompt": "гном", "kind": "character"}).json()
    l1 = s2["layers"][0]; assert "pad" in l1  # новый спрайт вписан автоматически
    r = c.post(f"/api/scenes/{s['id']}/layers/{l1['id']}/blend"); assert r.status_code == 200, r.text
    l2 = r.json()["layers"][0]
    assert abs(l2["height"] - l1["height"]) <= 2 and abs(l2["x"] - l1["x"]) <= 2  # эффекты не накапливаются
    assert c.post(f"/api/scenes/{s['id']}/undo").json()["layers"][0]["url"] == l1["url"]


def test_final_render_mock(monkeypatch):
    from app import main
    captured = {}
    integrated = main.im.integrated_scene
    def record_scene(*args, **kwargs):
        result = integrated(*args, **kwargs)
        captured['comp'], captured['sil'] = np.array(result[0]), result[1]
        return result
    def destructive_neural_output(png, mask, *args, **kwargs):
        assert not mask[captured['sil'] > 0].any()
        h, w = mask.shape
        buf = io.BytesIO(); Image.new('RGB', (w, h), 'white').save(buf, 'PNG')
        return buf.getvalue()
    monkeypatch.setattr(main.im, 'integrated_scene', record_scene)
    monkeypatch.setattr(main.holder.worker, 'harmonize', destructive_neural_output)
    s = scene()
    assert c.post(f"/api/scenes/{s['id']}/render").status_code == 409  # без объектов рендерить нечего
    c.post(f"/api/scenes/{s['id']}/characters", json={"prompt": "гном", "kind": "character"})
    r = c.post(f"/api/scenes/{s['id']}/render"); assert r.status_code == 200, r.text
    result = c.get(r.json()["url"]); assert result.status_code == 200
    pixels = np.array(Image.open(io.BytesIO(result.content)))
    np.testing.assert_array_equal(pixels[captured['sil'] > 0], captured['comp'][captured['sil'] > 0])
    rows = np.flatnonzero(captured['sil'].any(axis=1))
    midpoint = int((rows.min() + rows.max()) / 2)
    np.testing.assert_array_equal(pixels[:midpoint], captured['comp'][:midpoint])


def _char(prompt="гном"):
    s = scene(); r = c.post(f"/api/scenes/{s['id']}/characters", json={"prompt": prompt, "kind": "character"}); assert r.status_code == 200, r.text
    s = r.json(); return s, s["layers"][0]


def _human_sprite(s, l):
    """Подменяем спрайт слоя синтетической фигурой с руками и ногами (mock рисует просто прямоугольник)."""
    import cv2
    from app import scenes as sc_
    p = sc_.sdir(s["id"]); m = sc_.load(p); lay = m["layers"][0]
    a = np.zeros((400, 200, 4), np.uint8)
    col = (200, 60, 60, 255); sk = (230, 190, 150, 255)
    cv2.circle(a, (100, 40), 28, sk, -1); cv2.rectangle(a, (70, 70), (130, 210), col, -1)
    cv2.rectangle(a, (45, 72), (68, 190), (60, 120, 200, 255), -1); cv2.rectangle(a, (132, 72), (155, 190), (60, 120, 200, 255), -1)
    cv2.rectangle(a, (72, 210), (98, 390), (50, 50, 120, 255), -1); cv2.rectangle(a, (102, 210), (128, 390), (50, 50, 120, 255), -1)
    f = f"layer_{sc_.new_id()}.png"; Image.fromarray(a, "RGBA").save(p / f)
    lay.pop("orig", None); lay.pop("pad", None); lay.update(src=f, width=100, height=200)
    sc_.commit(p, m)


def test_pose_rig_preview_apply_reset():
    s, l = _char(); _human_sprite(s, l); l = c.get(f"/api/scenes/{s['id']}").json()["layers"][0]
    base = f"/api/scenes/{s['id']}/layers/{l['id']}"
    r = c.post(base + "/rig"); assert r.status_code == 200, r.text
    rg = r.json(); assert len(rg["kp0"]) == 18 and rg["method"] == "silhouette" and rg["w"] == 200 and rg["h"] == 400
    assert c.get(rg["base_url"]).status_code == 200
    # пресет, пересчитанный под персонажа: ноги остаются на месте, рука уходит вверх
    kp = c.post(base + "/rig/retarget", json={"kp0": rg["kp0"], "pose": "wave"}).json()["kp"]
    assert len(kp) == 18 and kp[4][1] < rg["kp0"][4][1] - 40  # правое запястье поднялось
    assert abs(kp[10][1] - rg["kp0"][10][1]) < 1 and abs(kp[13][1] - rg["kp0"][13][1]) < 1
    pr = c.post(base + "/pose/preview", json={"kp0": rg["kp0"], "kp": kp}); assert pr.status_code == 200
    img = Image.open(io.BytesIO(pr.content)); fw, fh = rg["frame"][2:]; assert abs(img.width / img.height - fw / fh) < .02 and img.mode == "RGBA"
    foot_before = (l["y"] + l["height"], l["x"] + l["width"] / 2)
    r = c.post(base + "/pose/apply", json={"kp0": rg["kp0"], "kp": kp}); assert r.status_code == 200, r.text
    l2 = r.json()["layers"][0]; assert l2["url"] != l["url"] and r.json()["can_undo"]
    # ступни на той же линии сцены (с допуском на тень и округление)
    assert abs((l2["y"] + l2["height"]) - foot_before[0]) < max(12, .12 * l["height"])
    assert c.post(base + "/rig").json()["kp"] == kp  # поза запомнена
    r = c.post(base + "/pose/reset"); assert r.status_code == 200, r.text
    assert c.post(base + "/rig").json()["kp"] is not None
    # отражение не ломает скелет
    assert c.post(base + "/flip").status_code == 200
    rg2 = c.post(base + "/rig").json(); assert abs(rg2["kp0"][2][0] - (200 - rg["kp0"][5][0])) < 1.5
    # замена персонажа сбрасывает скелет
    r = c.post(base + "/replace", json={"prompt": "эльф", "kind": "character"}); assert r.status_code == 200
    assert "rig" not in __import__("app.scenes", fromlist=["x"]).load(__import__("app.scenes", fromlist=["x"]).sdir(s["id"]))["layers"][0]


def test_pose_errors_and_library():
    s, l = _char(); base = f"/api/scenes/{s['id']}/layers/{l['id']}"
    assert c.post(base + "/pose/preview", json={"kp0": [[0, 0]] * 18, "kp": [[0, 0]] * 18}).status_code == 409  # скелета ещё нет
    _human_sprite(s, l); rg = c.post(base + "/rig").json()
    assert c.post(base + "/pose/apply", json={"kp0": rg["kp0"], "kp": [[1, 1]] * 3}).status_code == 400
    assert c.post(base + "/rig/retarget", json={"kp0": rg["kp0"], "pose": "нет"}).status_code == 404
    lib = c.get("/api/poses").json(); assert len(lib) >= 10 and all("kp" not in p for p in lib)
    sv = c.post("/api/poses", json={"name": "Моя поза", "kp0": rg["kp0"], "kp": rg["kp0"]}); assert sv.status_code == 200, sv.text
    uid = sv.json()["id"]; assert any(p["user"] and p["name"] == "Моя поза" for p in c.get("/api/poses").json())
    # сохранённая поза применима к любому персонажу
    assert len(c.post(base + "/rig/retarget", json={"kp0": rg["kp0"], "pose": uid}).json()["kp"]) == 18
    assert c.post("/api/poses", json={"name": " ", "kp0": rg["kp0"], "kp": rg["kp0"]}).status_code == 400


def test_pose_variants_and_commit():
    from app.main import holder
    s, l = _char(); _human_sprite(s, l); l = c.get(f"/api/scenes/{s['id']}").json()["layers"][0]
    base = f"/api/scenes/{s['id']}/layers/{l['id']}"
    rg = c.post(base + "/rig").json()
    kp = c.post(base + "/rig/retarget", json={"kp0": rg["kp0"], "pose": "run"}).json()["kp"]
    body = {"kp0": rg["kp0"], "kp": kp, "n": 2, "regen": True}
    # без GPU: только деформация + понятная заметка
    r = c.post(base + "/pose/variants", json=body); assert r.status_code == 200, r.text
    v = r.json(); assert v["items"][0]["kind"] == "warp" and "GPU" in v["note"]
    # «воркер» с нейросетью: возвращает картинку как есть, но вызовы должны дойти с маской и образцом
    calls = []
    def fake_repair(png, mask, ref, prompt, seed, ip, hint=""):
        calls.append((mask.shape, bool(mask.any()), ref is not None, prompt)); return png
    holder.worker.repair = fake_repair
    try:
        v = c.post(base + "/pose/variants", json=body).json()
        assert [i["kind"] for i in v["items"]] == ["warp", "repair", "repair", "regen"], v
        assert len(calls) == 2 and calls[0][1] and calls[0][2] and calls[0][3].startswith("гном")
        for it in v["items"]:
            assert c.get(it["url"]).status_code == 200
        changed = [list(point) for point in kp]; changed[4][0] += 12
        stale = c.post(base + "/pose/commit", json={**body, "kp": changed, "vid": v["vid"], "index": 1})
        assert stale.status_code == 409
        foot = c.get(f"/api/scenes/{s['id']}").json()["layers"][0]; fb = foot["y"] + foot["height"]
        r = c.post(base + "/pose/commit", json={**body, "vid": v["vid"], "index": 1}); assert r.status_code == 200, r.text
        l2 = r.json()["layers"][0]; assert abs(l2["y"] + l2["height"] - fb) < max(14, .15 * foot["height"])
        # перерисовка по образцу: новый спрайт, скелет сбрасывается и подгоняется заново
        v = c.post(base + "/pose/variants", json={**body, "n": 1}).json()
        r = c.post(base + "/pose/commit", json={**body, "vid": v["vid"], "index": len(v["items"]) - 1}); assert r.status_code == 200, r.text
        assert abs(r.json()["layers"][0]["y"] + r.json()["layers"][0]["height"] - fb) < max(20, .2 * foot["height"])
        assert c.post(base + "/pose/commit", json={**body, "vid": v["vid"], "index": 0}).status_code in (404, 409)  # варианты одноразовые
        assert c.post(base + "/pose/commit", json={**body, "vid": "../x", "index": 0}).status_code in (400, 404, 409)
        restored = c.post(base + "/pose/reset"); assert restored.status_code == 200, restored.text
        from app import scenes as scenes_store
        saved = scenes_store.load(scenes_store.sdir(s["id"]))["layers"][0]
        assert "pose_original" not in saved
        assert saved["rig"]["base"] == rg["base_url"].split("/")[-1]
        assert saved["rig"]["kp"] == saved["rig"]["kp0"]
    finally:
        del holder.worker.repair


def test_new_pose_editor_does_not_silently_use_demo_generation():
    from app import scenes as store
    s, layer = _char(); _human_sprite(s, layer)
    base = f"/api/scenes/{s['id']}/layers/{layer['id']}"
    rig = c.post(base + '/rig').json()
    folder = store.sdir(s['id']); before = store.load(folder)
    response = c.post(base + '/pose/edit/variants', json={'kp0': rig['kp0'], 'kp': rig['kp'], 'action': 'sit'})
    assert response.status_code == 503, response.text
    assert store.load(folder) == before
    assert not list(folder.glob('var_*'))


def test_new_pose_editor_receives_actual_reference_and_can_restore(monkeypatch):
    from app import main, scenes as store
    s, layer = _char(); _human_sprite(s, layer)
    base = f"/api/scenes/{s['id']}/layers/{layer['id']}"
    rig = c.post(base + '/rig').json()
    folder = store.sdir(s['id']); before = store.load(folder)['layers'][0]
    raw = (folder / before['rig']['base']).read_bytes()
    original = json.loads(json.dumps(before))
    rgba = np.array(Image.open(io.BytesIO(raw)).convert('RGBA'))
    calls = []
    def edit(image, guide, action, seed):
        calls.append((image, guide, action, seed)); return raw
    monkeypatch.setattr(main.holder.worker, 'pose_edit', edit)
    monkeypatch.setattr(main, 'cutout_sprite', lambda png, kind: rgba.copy())
    body = {'kp0': rig['kp0'], 'kp': rig['kp'], 'action': 'sit while playing the lute', 'n': 2}
    response = c.post(base + '/pose/edit/variants', json=body)
    assert response.status_code == 200, response.text
    variants = response.json()
    assert [item['kind'] for item in variants['items']] == ['edit', 'edit']
    assert len(calls) == 2 and all(call[0] == raw and call[2] == body['action'] for call in calls)
    assert Image.open(io.BytesIO(calls[0][1])).size == (768, 1024)
    manifest_path = folder / f"var_{variants['vid']}.json"
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    old_manifest = {key: value for key, value in manifest.items() if key != 'quality_version'}
    manifest_path.write_text(json.dumps(old_manifest), encoding='utf-8')
    assert c.post(base + '/pose/commit', json={**body, 'vid': variants['vid'], 'index': 1}).status_code == 409
    manifest_path.write_text(json.dumps(manifest), encoding='utf-8')
    committed = c.post(base + '/pose/commit', json={**body, 'vid': variants['vid'], 'index': 1})
    assert committed.status_code == 200, committed.text
    assert store.load(folder)['layers'][0]['orig'] != original.get('orig', original['src'])
    assert c.post(base + '/pose/reset').status_code == 200
    assert store.load(folder)['layers'][0] == original
