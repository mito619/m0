import numpy as np
from PIL import Image
from app import imaging as im


def test_relighting_matches_dark_room_without_changing_distant_scenery():
    bg = Image.new("RGB", (180, 160), (55, 35, 20))
    sprite = np.zeros((60, 30, 4), np.uint8)
    sprite[3:52, 8:22] = (220, 220, 220, 255)
    layer = dict(x=60, y=50, width=30, height=60, rotation=0)
    out, sil, shadow = im.integrated_scene(bg, [(layer, Image.fromarray(sprite))])
    pixels = np.array(out)
    assert 30 < pixels[..., 0][sil > 0].mean() < 180
    np.testing.assert_array_equal(pixels[:20, :20], np.array(bg)[:20, :20])
    assert shadow.any()


def test_contact_shadow_uses_opaque_feet_not_transparent_padding():
    bg = Image.new("RGB", (160, 160), (100, 80, 50))
    sprite = np.zeros((90, 30, 4), np.uint8)
    sprite[5:50, 8:22] = (130, 100, 80, 255)
    layer = dict(x=60, y=20, width=30, height=90, rotation=0)
    _, _, ground = im.integrated_scene(bg, [(layer, Image.fromarray(sprite))])
    assert ground[68:75, 66:84].any()  # Opaque bottom is at y=69.
    assert not ground[105:115, 66:84].any()  # Padded box ends at y=110.


def test_neural_seam_does_not_repaint_face_or_distant_background():
    comp = np.full((100, 100, 3), 100, np.uint8)
    generated = np.full_like(comp, 220)
    sil = np.zeros((100, 100), np.uint8); sil[25:75, 35:65] = 255
    ring = np.zeros_like(sil); ring[22:78, 32:68] = 255; ring[28:72, 38:62] = 0
    out = im.harmonize_compose(comp, generated, sil, ring)
    np.testing.assert_array_equal(out[35:65, 42:58], comp[35:65, 42:58])
    np.testing.assert_array_equal(out[:10], comp[:10])
    np.testing.assert_array_equal(out[sil > 0], comp[sil > 0])
    assert out[23, 33, 0] > 100


def test_one_pixel_fingers_and_strings_are_never_neurally_repainted():
    comp = np.arange(80 * 80 * 3, dtype=np.uint8).reshape(80, 80, 3)
    sil = np.zeros((80, 80), np.uint8)
    sil[12:68, 30] = 255
    sil[15, 20:50] = 255
    ring = np.full_like(sil, 255)  # Even an accidentally broad neural mask.
    out = im.harmonize_compose(comp, np.zeros_like(comp), sil, ring)
    np.testing.assert_array_equal(out[sil > 0], comp[sil > 0])


def test_downsampling_averages_subpixel_alpha_without_background_color_bleed():
    sprite = np.zeros((8, 8, 4), np.uint8)
    sprite[:, ::2] = (255, 0, 0, 255)
    sprite[:, 1::2] = (0, 255, 0, 0)
    placed = im.place_layer((12, 12), Image.fromarray(sprite), dict(x=3, y=1, width=1, height=8, rotation=0))
    np.testing.assert_allclose(placed[1:9, 3, 3], .5, atol=1e-6)
    np.testing.assert_allclose(placed[1:9, 3, 0], .5, atol=1e-6)
    assert placed[..., 1].max() == 0


def test_fully_translucent_layer_is_not_discarded_by_final_compositor():
    bg = Image.new('RGB', (40, 40), (30, 30, 30))
    sprite = Image.new('RGBA', (10, 15), (200, 100, 60, 64))
    out, support, _ = im.integrated_scene(bg, [(dict(x=10, y=10, width=10, height=15), sprite)])
    assert support[15, 15] == 255
    assert not np.array_equal(np.array(out)[15, 15], np.array(bg)[15, 15])
