import numpy as np
from app import imaging as im


def test_clean_alpha_preserves_soft_edges_and_real_holes():
    mask = np.zeros((100, 100), np.uint8)
    mask[10:90, 10:90] = 255
    mask[10:90, 9] = 80
    mask[40:43, 40:43] = 0  # A real small gap must not be filled.
    mask[2, 2] = 255  # Detached background speck.
    result = im.clean_alpha(mask)
    assert np.all(result[40:43, 40:43] == 0)
    assert np.all(result[10:90, 9] == 80)
    assert result[2, 2] == 0
    assert np.all(result <= mask)


def test_soft_cut_keeps_thin_details_and_partial_opacity():
    rgb = np.full((30, 30, 3), 123, np.uint8)
    mask = np.zeros((30, 30), np.uint8)
    mask[4:26, 10:20] = 255
    mask[6:24, 9] = 90
    rgba, (x0, y0, x1, y1) = im.cut_sprite(rgb, mask, preserve_soft=True)
    np.testing.assert_array_equal(rgba[..., 3], mask[y0:y1, x0:x1])
    assert np.all(rgba[..., :3] == 123)
