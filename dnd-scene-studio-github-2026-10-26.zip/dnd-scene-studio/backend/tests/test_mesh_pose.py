import numpy as np
import pytest
from app import poses
from app.mesh_pose import deform


def fixture():
    y, x = np.mgrid[:300, :200]
    image = np.stack([x % 256, y % 256, (x + y) % 256, np.full_like(x, 255)], axis=-1).astype(np.uint8)
    source = np.asarray(poses.POSES['stand']['kp']) * [200, 300]
    return image, source


def test_zero_motion_is_exact_and_does_not_mutate_input():
    image, source = fixture()
    original = image.copy()
    result, origin, _ = deform(image, source, source)
    np.testing.assert_array_equal(result, original)
    np.testing.assert_array_equal(image, original)
    assert origin == (0, 0)


def test_small_step_preserves_protected_texture_and_has_no_interior_holes():
    image, source = fixture()
    target = source.copy()
    target[10] += (8, -4)
    result, (ox, oy), stats = deform(image, source, target, protected=[(0, 0, 199, 170)])
    # The protected region retains real pixels, not merely similar colors.
    np.testing.assert_array_equal(result[30-oy:130-oy, 25-ox:170-ox], image[30:130, 25:170])
    assert (result[30-oy:250-oy, 25-ox:170-ox, 3] > 240).all()
    assert stats['minimum_area_ratio'] >= .2


def test_conflicting_joint_or_large_motion_is_rejected():
    image, source = fixture()
    target = source.copy(); target[4] += (4, 0)
    with pytest.raises(ValueError, match='protected region'):
        deform(image, source, target, protected=[(0, 0, 199, 170)])
    target = source.copy(); target[10] += (100, 0)
    with pytest.raises(ValueError, match='needs image editing'):
        deform(image, source, target)


def test_invalid_protected_region_is_rejected():
    image, source = fixture()
    target = source.copy(); target[10] += (3, 0)
    with pytest.raises(ValueError, match='rectangle'):
        deform(image, source, target, protected=[(10, 10, 0, 0)])
