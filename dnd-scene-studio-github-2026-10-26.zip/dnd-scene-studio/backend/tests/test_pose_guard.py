import numpy as np
from app import rig


def test_occluded_hand_cannot_be_quickly_moved_from_waist_overhead():
    # Regression: the detected hands-on-waist character produced four arms.
    source = np.array([[258,79],[229,190],[131,196],[41,301],[123,406],
                       [327,184],[395,295],[384,378],[221,486],[217,707],
                       [208,902],[342,483],[345,717],[347,890],[236,63],
                       [270,62],[196,77],[276,70]], dtype=float)
    target = source.copy(); target[rig.RWR] = (80, 20)
    assert rig.needs_regeneration(source, target)
    assert not rig.needs_regeneration(source, source)
    small = source.copy(); small[rig.RWR] += (4, -5)
    assert not rig.needs_regeneration(source, small)


def test_absolute_pose_uses_target_direction_instead_of_original_arm_rotation():
    from app import poses
    stand = np.array(poses.POSES['stand']['kp']) * [.75, 1.]
    point = np.array(poses.POSES['point']['kp']) * [.75, 1.]
    source = stand.copy()
    source[rig.RWR] = [.46, .39]
    result = rig.retarget(source, point, stand, absolute=True)
    actual = result[rig.RWR] - result[rig.REL]
    expected = point[rig.RWR] - point[rig.REL]
    np.testing.assert_allclose(actual / np.linalg.norm(actual), expected / np.linalg.norm(expected), atol=1e-6)


def test_lower_body_pose_keeps_original_hand_contact_relative_to_torso():
    import cv2
    from app import poses
    stand = np.array(poses.POSES['stand']['kp']) * [750, 1000]
    sit = np.array(poses.POSES['sit']['kp']) * [750, 1000]
    source = stand.copy()
    source[rig.RWR] = (350, 390); source[rig.LWR] = (520, 300)
    result = rig.retarget(source, sit, stand, absolute=True, preserve_hands=True)
    torso = cv2.getAffineTransform(source[[rig.NECK, rig.RHIP, rig.LHIP]].astype(np.float32), result[[rig.NECK, rig.RHIP, rig.LHIP]].astype(np.float32))
    arms = [rig.RSH, rig.REL, rig.RWR, rig.LSH, rig.LEL, rig.LWR]
    np.testing.assert_allclose(result[arms], source[arms] @ torso[:, :2].T + torso[:, 2], atol=1e-3)
    assert np.linalg.norm(result[rig.RKN] - source[rig.RKN]) > 20
