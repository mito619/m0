import importlib.util
from pathlib import Path

source = Path(__file__).resolve().parents[2] / 'worker' / 'pose_quality.py'
spec = importlib.util.spec_from_file_location('pose_quality', source)
quality = importlib.util.module_from_spec(spec)
spec.loader.exec_module(quality)


def test_third_plausible_hand_is_rejected():
    ref = [{'area': .004}, {'area': .005}]
    candidate = [{'area': .004}, {'area': .004}, {'area': .003}]
    assert quality.assess(ref, candidate)['extra_hands']


def test_tiny_accessory_detection_does_not_count_as_third_hand():
    ref = [{'area': .004}, {'area': .005}]
    candidate = [{'area': .004}, {'area': .004}, {'area': .0009}]
    report = quality.assess(ref, candidate)
    assert report['candidate_hands_detected'] == 2
    assert not report['extra_hands']
    assert report['limited_check']
