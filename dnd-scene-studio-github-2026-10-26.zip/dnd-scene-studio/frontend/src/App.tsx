import { useCallback, useEffect, useRef, useState } from "react";
import { Stage, Layer as KLayer, Image as KImage, Circle, Transformer } from "react-konva";
import useImage from "use-image";
import type Konva from "konva";
import * as api from "./api";
import PoseEditor from "./PoseEditor";
import type { Layer, People, Preview, Pt, Scene, SpriteKind, WorkerStatus } from "./api";

const typing = () => ["TEXTAREA", "INPUT", "SELECT"].includes(document.activeElement?.tagName ?? "");

function Sprite({ l, selected, onSelect, onChange }: { l: Layer; selected: boolean; onSelect: () => void; onChange: (p: Partial<Layer>) => void }) {
  const [img] = useImage(l.url);
  const ref = useRef<Konva.Image>(null), tr = useRef<Konva.Transformer>(null);
  useEffect(() => { if (selected && tr.current && ref.current) { tr.current.nodes([ref.current]); tr.current.getLayer()?.batchDraw(); } }, [selected, img]);
  return (<>
    <KImage ref={ref} image={img} x={l.x} y={l.y} width={l.width} height={l.height} rotation={l.rotation} draggable
      onMouseDown={(e) => { e.cancelBubble = true; onSelect(); }} onTap={onSelect}
      onDragEnd={(e) => onChange({ x: e.target.x(), y: e.target.y() })}
      onTransformEnd={() => {
        const n = ref.current!;
        onChange({ x: n.x(), y: n.y(), rotation: n.rotation(), width: n.width() * n.scaleX(), height: n.height() * n.scaleY() });
        n.scale({ x: 1, y: 1 });
      }} />
    {selected && <Transformer ref={tr} rotateEnabled keepRatio boundBoxFunc={(o, n) => (n.width < 12 || n.height < 12 ? o : n)} />}
  </>);
}

function WorkerPanel({ st, onChange }: { st: WorkerStatus | null; onChange: () => void }) {
  const [url, setUrl] = useState(""), [token, setToken] = useState(""), [msg, setMsg] = useState(""), [open, setOpen] = useState(false);
  const label = !st ? "Проверяю связь…" : st.kind === "mock" ? "Демо-режим (без GPU)"
    : !st.connected ? "Воркер не отвечает" : !st.ready ? "Воркер грузит модели…" : st.busy ? "GPU занята" : "GPU подключена";
  const tone = !st ? "wait" : st.kind === "mock" ? "mock" : !st.connected ? "bad" : st.ready ? "ok" : "wait";
  const go = async () => { setMsg(""); try { await api.connectWorker(url, token); setToken(""); setOpen(false); onChange(); } catch (e) { setMsg((e as Error).message); } };
  return (
    <details className="worker" open={open} onToggle={(e) => setOpen((e.target as HTMLDetailsElement).open)}>
      <summary><span className={`dot ${tone}`} />{label}</summary>
      {st?.kind === "remote" && st.ready && st.lama === false && <p className="hint">Зачистка фона упрощённая: модель LaMa не загрузилась.</p>}
      <input placeholder="Адрес воркера (https://….trycloudflare.com)" value={url} onChange={(e) => setUrl(e.target.value)} aria-label="Адрес воркера" />
      <input placeholder="Токен" type="password" value={token} onChange={(e) => setToken(e.target.value)} aria-label="Токен" />
      <div className="row">
        <button disabled={!url.trim()} onClick={go}>Подключить</button>
        {st?.kind === "remote" && <button className="ghost" onClick={() => api.disconnectWorker().then(onChange)}>Демо-режим</button>}
      </div>
      {msg && <p className="err" role="alert">{msg}</p>}
    </details>
  );
}

export default function App() {
  const [prompt, setPrompt] = useState("Уютная таверна у дороги, ночь, горит камин, пустые деревянные столы");
  const [scene, setScene] = useState<Scene | null>(null);
  const [sel, setSel] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState("");
  const [finalUrl, setFinalUrl] = useState<string | null>(null);
  const [poseOpen, setPoseOpen] = useState(false);
  const [spritePrompt, setSpritePrompt] = useState("гном-бард с лютней, рыжая борода, дорожный плащ");
  const [kind, setKind] = useState<SpriteKind>("character");
  const [people, setPeople] = useState<People>("auto");
  const [points, setPoints] = useState<Pt[]>([]);
  const [preview, setPreview] = useState<Preview | null>(null);
  const [worker, setWorker] = useState<WorkerStatus | null>(null);
  const [bg] = useImage(scene?.bg_url ?? "");
  const [ov] = useImage(preview?.preview_url ?? "");
  const box = useRef<HTMLElement>(null);
  const [avail, setAvail] = useState({ w: 900, h: 600 });
  const saveChain = useRef<Promise<unknown>>(Promise.resolve());

  useEffect(() => {
    let active = true;
    api.savedScenes().then(({ scenes }) => {
      if (active && scenes.length) setScene((current) => current ?? scenes[0]);
    }).catch(() => {});
    return () => { active = false; };
  }, []);

  const refreshWorker = useCallback(() => { api.health().then(setWorker).catch(() => setWorker({ kind: "remote", connected: false })); }, []);
  useEffect(() => { refreshWorker(); const t = setInterval(refreshWorker, 10000); return () => clearInterval(t); }, [refreshWorker]);
  useEffect(() => {
    const el = box.current; if (!el) return;
    const ro = new ResizeObserver(() => setAvail({ w: el.clientWidth - 40, h: el.clientHeight - 40 }));
    ro.observe(el); return () => ro.disconnect();
  }, []);

  const scale = bg ? Math.min(avail.w / bg.width, avail.h / bg.height, 1) : 1;
  const clearPick = () => { setPoints([]); setPreview(null); };

  const run = async (label: string, fn: () => Promise<Scene | void>) => {
    setBusy(label); setErr("");
    try { await saveChain.current; const s = await fn(); if (s) setScene(s); return s ?? undefined; }
    catch (e) { setErr((e as Error).message); } finally { setBusy(null); refreshWorker(); }
  };

  // Правки геометрии: мгновенно в UI, на сервер по очереди (порядок сохранения = порядок действий).
  const commitLayers = (layers: Layer[]) => {
    setScene((s) => (s ? { ...s, layers, can_undo: true, can_redo: false } : s));
    const id = scene!.id;
    saveChain.current = saveChain.current.then(() => api.saveState(id, layers)).catch((e) => setErr((e as Error).message));
  };
  const patch = (id: string, p: Partial<Layer>) => scene && commitLayers(scene.layers.map((l) => (l.id === id ? { ...l, ...p } : l)));
  const remove = () => { if (scene && sel) { commitLayers(scene.layers.filter((l) => l.id !== sel)); setSel(null); } };
  const move = (dir: 1 | -1) => {
    if (!scene || !sel) return;
    const a = [...scene.layers], i = a.findIndex((l) => l.id === sel), j = i + dir;
    if (j < 0 || j >= a.length) return;
    [a[i], a[j]] = [a[j], a[i]]; commitLayers(a);
  };
  const layerOp = (label: string, fn: (sid: string, lid: string) => Promise<Scene>) =>
    sel && scene && run(label, () => fn(scene.id, sel));

  const undo = () => scene?.can_undo && run("Отменяю…", async () => { clearPick(); setSel(null); return api.undo(scene.id); });
  const redo = () => scene?.can_redo && run("Повторяю…", async () => { clearPick(); setSel(null); return api.redo(scene.id); });
  const confirm = () => scene && preview && run("Вырезаю объект и зачищаю фон…", async () => {
    const s = await api.extract(scene.id, preview.mask_id);
    clearPick(); setSel(s.layers[s.layers.length - 1]?.id ?? null); return s;
  });

  const pick = (x: number, y: number, mode: "new" | "add" | "sub") => {
    if (!scene) return;
    const pt: Pt = { x, y, label: mode === "sub" ? 0 : 1 };
    const next = mode === "new" || !points.length ? [pt] : [...points, pt];
    setSel(null);
    run("Ищу объект…", async () => { const p = await api.segment(scene.id, next); setPoints(next); setPreview(p); });
  };
  const onStage = (e: Konva.KonvaEventObject<MouseEvent>, right = false) => {
    if (busy || e.target.name() !== "bg") return;
    if (right) e.evt.preventDefault();
    const p = e.target.getStage()!.getPointerPosition()!;
    const x = Math.round(p.x / scale), y = Math.round(p.y / scale);
    if (right && !points.length) return;
    pick(x, y, right || e.evt.altKey ? "sub" : e.evt.shiftKey ? "add" : "new");
  };

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (typing()) return;
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === "z") { e.preventDefault(); e.shiftKey ? redo() : undo(); }
      else if (mod && e.key.toLowerCase() === "y") { e.preventDefault(); redo(); }
      else if (e.key === "Enter" && preview) confirm();
      else if (e.key === "Escape") { clearPick(); setSel(null); }
      else if ((e.key === "Delete" || e.key === "Backspace") && sel && !busy) remove();
    };
    window.addEventListener("keydown", h); return () => window.removeEventListener("keydown", h);
  });

  const sorted = scene ? [...scene.layers].reverse() : []; // верхний слой сверху списка

  return (
    <div className="app">
      <aside>
        <h1>Сцены для приключения</h1>
        <WorkerPanel st={worker} onChange={refreshWorker} />
        <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} aria-label="Описание сцены" />
        <select value={people} onChange={(e) => setPeople(e.target.value as People)} aria-label="Персонажи в сцене">
          <option value="auto">Персонажи: по тексту</option>
          <option value="yes">Персонажи: нарисовать</option>
          <option value="no">Персонажи: без них</option>
        </select>
        <button disabled={!!busy || !prompt.trim()} onClick={() => run("Рисую сцену…", async () => { setSel(null); clearPick(); return api.generate(prompt, people); })}>
          Создать сцену
        </button>

        {scene && <>
          <div className="row">
            <button className="ghost" disabled={!!busy || !scene.can_undo} onClick={undo} title="Ctrl+Z">↶ Отменить</button>
            <button className="ghost" disabled={!!busy || !scene.can_redo} onClick={redo} title="Ctrl+Shift+Z">↷ Вернуть</button>
          </div>
          <a className="btn ghost" href={api.exportUrl(scene.id)} download>Скачать сцену (ZIP со слоями)</a>

          <h2>Новый объект</h2>
          <textarea value={spritePrompt} onChange={(e) => setSpritePrompt(e.target.value)} aria-label="Описание объекта" style={{ minHeight: 70 }} />
          <select value={kind} onChange={(e) => setKind(e.target.value as SpriteKind)} aria-label="Тип">
            <option value="character">Персонаж</option><option value="object">Предмет</option>
          </select>
          <div className="row">
            <button disabled={!!busy || !spritePrompt.trim()} onClick={() => run("Рисую и вырезаю…", () => api.addSprite(scene.id, spritePrompt, kind))}>Добавить</button>
            <button className="ghost" disabled={!!busy || !sel || !spritePrompt.trim()} onClick={() => layerOp("Заменяю…", (s, l) => api.replaceLayer(s, l, spritePrompt, kind))}>Заменить выбранное</button>
          </div>

          <h2>Слои</h2>
          {sorted.length === 0 && <p className="hint">Пока пусто. Кликните по объекту на сцене.</p>}
          <ul className="layers">
            {sorted.map((l) => (
              <li key={l.id} className={sel === l.id ? "on" : ""}>
                <button className="eye" aria-label={l.visible ? "Скрыть" : "Показать"} onClick={() => patch(l.id, { visible: !l.visible })}>{l.visible ? "👁" : "·"}</button>
                <button className="name" onClick={() => setSel(l.id)}>{l.name}</button>
              </li>
            ))}
          </ul>
          <div className="tools">
            <button className="ghost" disabled={!sel || !!busy} onClick={() => move(1)} title="Выше">↑</button>
            <button className="ghost" disabled={!sel || !!busy} onClick={() => move(-1)} title="Ниже">↓</button>
            <button className="ghost" disabled={!sel || !!busy} onClick={() => layerOp("Отражаю…", api.flipLayer)}>⇋ Отразить</button>
            <button className="ghost" disabled={!sel || !!busy} onClick={() => layerOp("Копирую…", api.duplicateLayer)}>⧉ Копия</button>
            <button className="ghost" disabled={!sel || !!busy} onClick={() => layerOp("Вписываю в сцену…", api.blendLayer)} title="Подогнать свет и цвет под это место, добавить тень">☀ Вписать</button>
            <button className="ghost" disabled={!sel || !!busy} onClick={() => layerOp("Очищаю фон…", api.cleanBackground)} title="Уточнить прозрачность без перерисовки объекта. Можно отменить через Ctrl+Z">Очистить фон</button>
            <button className="ghost" disabled={!sel || !!busy} style={{ gridColumn: "1 / -1" }} onClick={() => setPoseOpen(true)}>🦴 Поза персонажа…</button>
            <button disabled={!!busy || !scene.layers.length} style={{ gridColumn: "1 / -1" }} title="Нейросеть доводит свет и тени вокруг вставленных объектов"
              onClick={async () => { setBusy("Финальный рендер (до минуты)…"); setErr(""); try { setFinalUrl((await api.finalRender(scene.id)).url); } catch (e) { setErr((e as Error).message); } finally { setBusy(null); } }}>✨ Финальный рендер</button>
            <button className="ghost danger" disabled={!sel || !!busy} onClick={remove}>Удалить</button>
          </div>
          <p className="hint">
            Клик по фону — выделить объект. <b>Shift</b>+клик — добавить область, <b>правая кнопка</b> или <b>Alt</b>+клик — убрать лишнее.
            <b> Enter</b> — вынуть, <b>Esc</b> — отмена.
          </p>
        </>}
        {err && <p className="err" role="alert">{err}</p>}
      </aside>

      <main ref={box}>
        {!scene ? <p className="empty">Опишите место, где начнётся сцена, и я нарисую его.</p> : bg && (
          <div className="stagewrap" style={{ width: bg.width * scale, height: bg.height * scale }}>
            <Stage width={bg.width * scale} height={bg.height * scale} scaleX={scale} scaleY={scale}
              onMouseDown={(e) => e.evt.button === 0 && onStage(e)} onContextMenu={(e) => onStage(e, true)}
              style={{ cursor: busy ? "wait" : "crosshair" }}>
              <KLayer><KImage name="bg" image={bg} /></KLayer>
              <KLayer>{scene.layers.filter((l) => l.visible).map((l) => (
                <Sprite key={l.url + l.id} l={l} selected={sel === l.id} onSelect={() => { clearPick(); setSel(l.id); }} onChange={(p) => patch(l.id, p)} />
              ))}</KLayer>
              {preview && <KLayer listening={false}>
                {ov && <KImage image={ov} width={bg.width} height={bg.height} />}
                {points.map((p, i) => <Circle key={i} x={p.x} y={p.y} radius={7 / scale} fill={p.label ? "#4a9a8c" : "#d9644a"} stroke="#fff" strokeWidth={2 / scale} />)}
              </KLayer>}
            </Stage>
            {preview && !busy && (
              <div className="pickbar">
                <span>Выделено {preview.area_pct}% сцены</span>
                <button onClick={confirm}>Вынуть (Enter)</button>
                <button className="ghost" onClick={clearPick}>Отмена</button>
              </div>
            )}
            {busy && <div className="busy" role="status"><span className="spin" />{busy}</div>}
          </div>
        )}
        {finalUrl && <div className="final" role="dialog" aria-label="Финальный рендер">
          <img src={finalUrl} alt="Финальный рендер" />
          <div><a href={finalUrl} download>Скачать</a><button className="ghost" onClick={() => setFinalUrl(null)}>Закрыть</button></div>
        </div>}
        {poseOpen && scene && (() => { const l = scene.layers.find((x) => x.id === sel); return l ? <PoseEditor sceneId={scene.id} layer={l} onClose={() => setPoseOpen(false)} onDone={(s) => { setScene(s); setPoseOpen(false); }} /> : null; })()}
      </main>
    </div>
  );
}
