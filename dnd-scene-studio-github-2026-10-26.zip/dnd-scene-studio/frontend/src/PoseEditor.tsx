import { useEffect, useRef, useState } from "react";
import * as api from "./api";
import type { Layer, PoseDef, Rig, Scene } from "./api";

// Скелет OpenPose (18 точек): рёбра и цвета как у ControlNet
const LIMBS: [number, number][] = [[1, 2], [1, 5], [2, 3], [3, 4], [5, 6], [6, 7], [1, 8], [8, 9], [9, 10], [1, 11], [11, 12], [12, 13], [1, 0], [0, 14], [14, 16], [0, 15], [15, 17]];
const COLORS = ["#ff0000", "#ff5500", "#ffaa00", "#ffff00", "#aaff00", "#55ff00", "#00ff00", "#00ff55", "#00ffaa", "#00ffff", "#00aaff", "#0055ff", "#0000ff", "#5500ff", "#aa00ff", "#ff00ff", "#ff00aa", "#ff0055"];
const PEL = 18;  // виртуальный таз: середина бёдер
// родитель каждой точки (для режима «Поза»: тянешь сустав, дочерние точки едут вместе с ним, длины костей сохраняются)
const PARENT: Record<number, number> = { 1: PEL, 0: 1, 2: 1, 5: 1, 3: 2, 4: 3, 6: 5, 7: 6, 8: PEL, 11: PEL, 9: 8, 10: 9, 12: 11, 13: 12, 14: 0, 15: 0, 16: 0, 17: 0 };
const kids = (j: number): number[] => Object.keys(PARENT).map(Number).filter((c) => PARENT[c] === j).flatMap((c) => [c, ...kids(c)]);
const NAMES = ["Нос", "Шея", "Пр. плечо", "Пр. локоть", "Пр. кисть", "Лев. плечо", "Лев. локоть", "Лев. кисть", "Пр. бедро", "Пр. колено", "Пр. стопа", "Лев. бедро", "Лев. колено", "Лев. стопа", "Пр. глаз", "Лев. глаз", "Пр. ухо", "Лев. ухо"];
const clone = (k: number[][]) => k.map((p) => [...p]);

export default function PoseEditor({ sceneId, layer, onClose, onDone }: { sceneId: string; layer: Layer; onClose: () => void; onDone: (s: Scene) => void }) {
  const [rig, setRig] = useState<Rig | null>(null);
  const [kp0, setKp0] = useState<number[][]>([]);
  const [kp, setKp] = useState<number[][]>([]);
  const [mode, setMode] = useState<"fit" | "pose">("fit");
  const [motionMethod, setMotionMethod] = useState<"mesh" | "edit" | "legacy">("mesh");
  const [presetAction, setPresetAction] = useState<{ name: string; description: string } | null>(null);
  const [protectedAreas, setProtectedAreas] = useState<number[][]>([]);
  const [drawingProtection, setDrawingProtection] = useState(false);
  const [draftProtection, setDraftProtection] = useState<number[] | null>(null);
  const protectionStart = useRef<[number, number] | null>(null);
  const [lib, setLib] = useState<PoseDef[]>([]);
  const [prev, setPrev] = useState<string | null>(null);
  const [nVar, setNVar] = useState(1);
  const [ipScale, setIpScale] = useState(.4);
  const [regen, setRegen] = useState(true);
  const [polish, setPolish] = useState(false);
  const [text, setText] = useState("");
  const [vars, setVars] = useState<{ vid: string; note: string; items: api.Variant[] } | null>(null);
  const [pick, setPick] = useState(0);
  const [resultView, setResultView] = useState<"result" | "source" | "skeleton">("result");
  const [busy, setBusy] = useState("");
  const [err, setErr] = useState("");
  const [hot, setHot] = useState<number | null>(null);
  const drag = useRef<number | null>(null);
  const svg = useRef<SVGSVGElement>(null);
  const edited = useRef(false);
  const parameters = useRef("");
  parameters.current = JSON.stringify({ kp, kp0, text, motionMethod, protectedAreas, ipScale, regen, polish, nVar });
  useEffect(() => { setDrawingProtection(false); setDraftProtection(null); protectionStart.current = null; }, [mode]);
  useEffect(() => { setVars(null); setPick(0); }, [kp, kp0, text, regen, polish, ipScale, protectedAreas, motionMethod]);

  const init = (r: Rig) => { setRig(r); setProtectedAreas(clone(r.protected || [])); setKp0(clone(r.kp0)); setKp(clone(r.kp)); setMode(r.kp.some((p, i) => p[0] !== r.kp0[i][0] || p[1] !== r.kp0[i][1]) ? "pose" : "fit"); };
  const loadLib = () => api.listPoses().then(setLib).catch((e) => setErr(e.message));
  useEffect(() => {
    setBusy("Подгоняю скелет под персонажа…");
    api.getRig(sceneId, layer.id).then(init).catch((e) => setErr(e.message)).finally(() => setBusy(""));
    loadLib();
  }, []);

  // живой предпросмотр позы: запрос не чаще раза в ~150 мс, устаревшие отменяются
  useEffect(() => {
    if (!rig || mode !== "pose") return;
    if (motionMethod === "edit") { setPrev((old) => { if (old) URL.revokeObjectURL(old); return null; }); setErr(""); return; }
    const ac = new AbortController();
    const t = setTimeout(() => {
      const request = motionMethod === "mesh" ? api.meshPosePreview(sceneId, layer.id, kp0, kp, protectedAreas, ac.signal) : api.posePreview(sceneId, layer.id, kp0, kp, ac.signal);
      request.then((u) => { setPrev((o) => { if (o) URL.revokeObjectURL(o); return u; }); setErr(""); })
        .catch((e) => { if (e.name !== "AbortError") { setErr(e.message); setPrev((o) => { if (o) URL.revokeObjectURL(o); return null; }); } });
    }, 150);
    return () => { clearTimeout(t); ac.abort(); };
  }, [rig, mode, kp, kp0, motionMethod, protectedAreas]);

  const toSvg = (e: React.PointerEvent): [number, number] => {
    const s = svg.current!, m = s.getScreenCTM()!.inverse(), p = new DOMPoint(e.clientX, e.clientY).matrixTransform(m);
    return [p.x, p.y];
  };
  const move = (e: React.PointerEvent) => {
    if (busy) return;
    if (protectionStart.current && rig) {
      const [x, y] = toSvg(e), [sx, sy] = protectionStart.current;
      const px = Math.max(0, Math.min(rig.w, x)), py = Math.max(0, Math.min(rig.h, y));
      setDraftProtection([Math.min(sx, px), Math.min(sy, py), Math.max(sx, px), Math.max(sy, py)]);
      return;
    }
    const i = drag.current; if (i === null || !svg.current || !rig) return;
    const [x, y] = toSvg(e);
    const [fx, fy, fw, fh] = rig.frame;
    const px = Math.min(fx + fw, Math.max(fx, x)), py = Math.min(fy + fh, Math.max(fy, y));
    edited.current = true;
    if (mode === "fit") {  // подгонка: точки двигаются по одной (нос тащит глаза и уши)
      setKp0((k) => { const n = clone(k), dx = px - n[i][0], dy = py - n[i][1]; (i === 0 ? [0, 14, 15, 16, 17] : [i]).forEach((j) => { n[j] = [n[j][0] + dx, n[j][1] + dy]; }); return n; });
      return;
    }
    setKp((k) => {  // поза: кость сохраняет длину (Shift = свободно), всё, что «ниже» по цепочке, едет вместе
      const n = clone(k), par = PARENT[i];
      const pv = par === PEL ? [(n[8][0] + n[11][0]) / 2, (n[8][1] + n[11][1]) / 2] : n[par];
      let tx = px, ty = py;
      if (!e.shiftKey && par !== undefined) {
        const L = Math.hypot(n[i][0] - pv[0], n[i][1] - pv[1]), d = Math.hypot(px - pv[0], py - pv[1]) || 1;
        tx = pv[0] + (px - pv[0]) * L / d; ty = pv[1] + (py - pv[1]) * L / d;
      }
      const dx = tx - n[i][0], dy = ty - n[i][1];
      [i, ...kids(i)].forEach((j) => { n[j] = [n[j][0] + dx, n[j][1] + dy]; });
      return n;
    });
  };

  const guard = async (msg: string, f: () => Promise<void>) => { setBusy(msg); setErr(""); try { await f(); } catch (e) { setErr((e as Error).message); } finally { setBusy(""); } };
  const preset = (p: PoseDef) => guard("Применяю заготовку…", async () => { setKp(await api.retargetPose(sceneId, layer.id, kp0, p.id, motionMethod === "edit" ? "absolute" : "relative", motionMethod !== "legacy" && !!p.preserve_hands)); setMode("pose"); setVars(null); setText(p.name.toLowerCase()); setPresetAction({ name: p.name.toLowerCase(), description: p.description || p.name }); });
  const refit = () => guard("Подгоняю скелет заново…", async () => { init(await api.getRig(sceneId, layer.id, true)); });
  const apply = () => guard("Применяю позу…", async () => { onDone(motionMethod === "mesh" ? await api.applyMeshPose(sceneId, layer.id, kp0, kp, protectedAreas) : await api.applyPose(sceneId, layer.id, kp0, kp)); });
  const variants = () => guard("Нейросеть создаёт варианты. Это может занять несколько минут…", async () => {
    setVars(null);
    const requestParameters = parameters.current;
    const v = await api.poseVariants(sceneId, layer.id, kp0, kp, { n: nVar, ip_scale: ipScale, regen, polish, strength: .25, text });
    if (requestParameters !== parameters.current) { setErr("Параметры изменились во время обработки. Создайте варианты для новой позы."); return; }
    setVars(v); setPick(v.items.length > 1 ? 1 : 0);
  });
  const editVariants = () => guard("Редактирую исходного персонажа. Первый вариант может занять несколько минут…", async () => {
    setVars(null);
    const requestParameters = parameters.current;
    const action = presetAction && text === presetAction.name ? presetAction.description : text;
    const v = await api.editPoseVariants(sceneId, layer.id, kp0, kp, action, nVar);
    if (requestParameters !== parameters.current) { setErr("Параметры изменились во время обработки. Создайте варианты для новой позы."); return; }
    setVars(v); setPick(0); setResultView("result");
  });
  const take = () => vars && guard("Применяю вариант…", async () => { onDone(await api.poseCommit(sceneId, layer.id, kp0, kp, vars.vid, pick)); });
  const label = (v: api.Variant, i: number) => v.kind === "edit" ? `Новая поза ${i + 1}` : v.kind === "warp" ? "Без нейросети" : v.kind === "regen" ? "Перерисовка" : `Починка ${i}`;
  const reset = () => guard("Возвращаю исходную позу…", async () => { onDone(await api.resetPose(sceneId, layer.id)); });
  const save = () => { const name = window.prompt("Название позы для библиотеки"); if (name) guard("Сохраняю…", async () => { await api.savePose(name, kp0, kp); await loadLib(); }); };

  const shown = mode === "fit" ? kp0 : kp;
  const [fx, fy, fw, fh] = rig?.frame ?? [0, 0, 1, 1];
  const r = fw / 70;
  const inspectingResult = mode === "pose" && motionMethod === "edit" && !!vars;
  const variantPanel = vars && <>
    {vars.note && <p className="hint">{vars.note}</p>}
    <div className="vars">{vars.items.map((v, i) => (
      <button key={v.url} className={"var" + (pick === i ? " on" : "")} onClick={() => setPick(i)} aria-pressed={pick === i}>
        <img src={v.url} alt={label(v, i)} /><span>{label(v, i)}</span></button>))}</div>
    <button disabled={!!busy} onClick={take}>Взять выбранный</button>
  </>;

  return (
    <div className="modal" role="dialog" aria-label="Редактор позы">
      <div className="box">
        <div style={{ flex: "none", width: "min(440px, 90vw)" }}>
          <div className="tabs" role="tablist">
            <button role="tab" aria-selected={mode === "fit"} className={mode === "fit" ? "" : "ghost"} onClick={() => setMode("fit")}>1. Скелет на персонаже</button>
            <button role="tab" aria-selected={mode === "pose"} className={mode === "pose" ? "" : "ghost"} onClick={() => setMode("pose")} disabled={!rig}>2. Поза</button>
          </div>
          {inspectingResult && <div className="tabs">
            <button className={resultView === "result" ? "" : "ghost"} onClick={() => setResultView("result")}>Результат</button>
            <button className={resultView === "source" ? "" : "ghost"} onClick={() => setResultView("source")}>Исходник</button>
            <button className={resultView === "skeleton" ? "" : "ghost"} onClick={() => setResultView("skeleton")}>Скелет</button>
          </div>}
          {inspectingResult && rig && resultView !== "skeleton" && <img
            src={resultView === "source" ? rig.base_url : vars!.items[pick]?.url}
            alt={resultView === "source" ? "Исходный персонаж" : "Результат новой позы"}
            style={{ width: "100%", height: "65vh", objectFit: "contain", background: "#14110d", borderRadius: 6 }} />}
          {rig && !(inspectingResult && resultView !== "skeleton") && <svg ref={svg} viewBox={`${fx} ${fy} ${fw} ${fh}`} style={{ width: "100%", maxHeight: "72vh", background: "#14110d", touchAction: "none", borderRadius: 6, display: "block" }}
            onPointerMove={move}
            onPointerDown={(e) => {
              if (!drawingProtection || mode !== "fit" || protectedAreas.length >= 16) return;
              const [x, y] = toSvg(e); protectionStart.current = [Math.max(0, Math.min(rig.w, x)), Math.max(0, Math.min(rig.h, y))];
              setDraftProtection([...protectionStart.current, ...protectionStart.current]); e.currentTarget.setPointerCapture(e.pointerId);
            }}
            onPointerUp={() => {
              drag.current = null;
              if (protectionStart.current) {
                if (draftProtection && draftProtection[2] - draftProtection[0] > 8 && draftProtection[3] - draftProtection[1] > 8) setProtectedAreas((areas) => [...areas, draftProtection]);
                protectionStart.current = null; setDraftProtection(null); setDrawingProtection(false);
              }
            }} onPointerCancel={() => { drag.current = null; protectionStart.current = null; setDraftProtection(null); }}>
            <image href={rig.base_url} x={0} y={0} width={rig.w} height={rig.h} opacity={mode === "fit" ? 1 : .18} />
            {mode === "pose" && prev && <image href={prev} x={fx} y={fy} width={fw} height={fh} />}
            <rect x={0} y={0} width={rig.w} height={rig.h} fill="none" stroke="#fff3" strokeDasharray={`${r} ${r}`} strokeWidth={r / 6} />
            {mode === "fit" && [...protectedAreas, ...(draftProtection ? [draftProtection] : [])].map(([x0, y0, x1, y1], i) => <rect key={`protection-${i}`} x={x0} y={y0} width={x1-x0} height={y1-y0} fill="#4f84" stroke="#8fc" strokeWidth={r/3} pointerEvents="none" />)}
            {mode === "pose" && LIMBS.map(([a, b], i) => <line key={"g" + i} x1={kp0[a][0]} y1={kp0[a][1]} x2={kp0[b][0]} y2={kp0[b][1]} stroke="#fff" strokeOpacity={.15} strokeWidth={r / 4} />)}
            {LIMBS.map(([a, b], i) => <line key={i} x1={shown[a][0]} y1={shown[a][1]} x2={shown[b][0]} y2={shown[b][1]} stroke={COLORS[i]} strokeWidth={r / 2.2} strokeLinecap="round" opacity={.85} />)}
            {shown.map(([x, y], i) => <g key={i}>
              <circle cx={x} cy={y} r={r * 1.7} fill="transparent" style={{ cursor: "grab" }}
                onPointerDown={(e) => { if (drawingProtection || busy) return; drag.current = i; setHot(i); (e.target as Element).setPointerCapture(e.pointerId); }}
                onPointerEnter={() => setHot(i)} onPointerLeave={() => drag.current === null && setHot(null)} />
              <circle cx={x} cy={y} r={hot === i ? r * 1.2 : r * .85} fill={COLORS[i]} stroke="#000" strokeWidth={r / 8} pointerEvents="none" />
            </g>)}
            {hot !== null && <text x={shown[hot][0] + r * 2} y={shown[hot][1] - r * 1.5} fontSize={r * 1.6} fill="#fff" stroke="#000" strokeWidth={r / 6} paintOrder="stroke" pointerEvents="none">{NAMES[hot]}</text>}
          </svg>}
          {!rig && <p className="hint">{busy || "Загрузка…"}</p>}
        </div>
        <div className="side">
          <h2 style={{ margin: 0, font: "600 18px Georgia, serif" }}>Поза персонажа</h2>
          {mode === "fit" ? <>
            <p className="hint">
              {rig?.method === "detector" ? "Скелет найден нейросетью-детектором." : "Скелет подогнан по силуэту (детектор недоступен)."} Проверьте суставы: плечи, локти, кисти, бёдра, колени, стопы
              должны лежать на персонаже. Лишнее — перетащите. Нос двигает голову целиком.
            </p>
            <button className="ghost" disabled={!!busy} onClick={refit}>Подогнать заново</button>
            <button className="ghost" disabled={!!busy || protectedAreas.length >= 16} onClick={() => setDrawingProtection((value) => !value)}>{drawingProtection ? "Отменить выделение" : "Закрепить лицо или предмет рамкой"}</button>
            {drawingProtection && <p className="hint">Обведите нужную область на картинке. Она будет двигаться вместе с корпусом, сохраняя форму.</p>}
            {protectedAreas.length > 0 && <><p className="hint">Закреплённых областей: {protectedAreas.length}. Суставы внутри них тоже закреплены.</p><button className="ghost" onClick={() => setProtectedAreas([])}>Снять закрепления</button></>}
            <button disabled={!rig || !!busy} onClick={() => setMode("pose")}>Дальше: выбрать позу →</button>
          </> : <>
            <label>Способ смены позы <select disabled={!!busy} value={motionMethod} onChange={(e) => setMotionMethod(e.target.value as "mesh" | "edit" | "legacy")}><option value="mesh">Бережное движение — сохранить детали</option><option value="edit">Новая поза по исходной картинке — GPU</option><option value="legacy">Старая деформация — для сравнения</option></select></label>
            <p className="hint">{motionMethod === "edit" ? "Выберите действие и скелет-ориентир. Итог появится в вариантах после редактирования. Сравните лицо, руки и инструмент перед применением: точное совпадение всех деталей не гарантируется." : <>Для бережного режима слегка двигайте суставы. Закрепить лицо или инструмент можно на первом шаге. Большие движения будут отклонены, если сетка начнёт складываться. <b>Shift</b> — свободное перемещение.</>}</p>
            <div className="grid">{lib.map((p) => <button key={p.id} className="ghost" disabled={!!busy} onClick={() => preset(p)}>{p.user ? "★ " : ""}{p.name}</button>)}</div>
            <button className="ghost" disabled={!!busy} onClick={() => setKp(clone(kp0))}>↺ К исходной стойке</button>
            {motionMethod === "edit" ? <div className="gpu">
              <input disabled={!!busy} value={text} onChange={(e) => setText(e.target.value)} placeholder="Действие: сидит и играет на лютне…" aria-label="Действие в новой позе" />
              <label className="row">Вариантов <select value={nVar} onChange={(e) => setNVar(+e.target.value)}>{[1, 2, 3, 4].map((n) => <option key={n}>{n}</option>)}</select></label>
              <p className="hint">Закреплённые рамки относятся к бережному движению. Здесь вся картинка редактируется нейросетью.</p>
              <button disabled={!!busy} onClick={editVariants}>Создать новую позу по картинке</button>
              {variantPanel}
            </div> : <button disabled={!!busy} onClick={apply}>{motionMethod === "mesh" ? "Применить бережное движение" : "Применить старую деформацию"}</button>}
            {motionMethod !== "edit" && <details className="gpu">
              <summary>Прежний способ GPU — для сравнения</summary>
              <p className="hint">Для небольших изменений нейросеть чинит стыки. Для больших — рисует персонажа заново по скелету и образцу внешности; детали одежды и лица могут немного измениться.</p>
              <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Что делает персонаж (необязательно): бежит, сидит…" aria-label="Описание позы" />
              <p className="hint">Положение тела задаёт скелет выше. Текст уточняет действие для нейросети.</p>
              <label className="row">Вариантов <select value={nVar} onChange={(e) => setNVar(+e.target.value)}>{[1, 2, 3, 4].map((n) => <option key={n}>{n}</option>)}</select></label>
              <label className="row">Строгость образца <input type="range" min={.3} max={.9} step={.05} value={ipScale} onChange={(e) => setIpScale(+e.target.value)} /><span>{ipScale.toFixed(2)}</span></label>
              <label className="row"><input type="checkbox" checked={regen} onChange={(e) => setRegen(e.target.checked)} /> + перерисовка по образцу (для больших поз)</label>
              <label className="row"><input type="checkbox" checked={polish} onChange={(e) => setPolish(e.target.checked)} /> + лёгкая полировка</label>
              <button disabled={!!busy} onClick={variants}>Показать варианты</button>
              {variantPanel}
            </details>}
            <button className="ghost" disabled={!!busy} onClick={save}>Сохранить позу в библиотеку</button>
            <button className="ghost" disabled={!!busy} onClick={reset} title="Вернуть исходную стойку персонажа">Вернуть исходную позу</button>
          </>}
          <button className="ghost" disabled={!!busy} onClick={onClose}>Закрыть</button>
          {busy && rig && <p className="hint" role="status">{busy}</p>}
          {err && <p className="err" role="alert">{err}</p>}
        </div>
      </div>
    </div>
  );
}
