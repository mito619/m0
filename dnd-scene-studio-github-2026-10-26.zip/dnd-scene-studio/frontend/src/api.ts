export type Layer = {
  id: string; url: string; x: number; y: number; width: number; height: number; rotation: number; visible: boolean; name: string };
export type Scene = {
  prompt_en?: string | null; id: string; bg_url: string; layers: Layer[]; can_undo: boolean; can_redo: boolean };
export type Pt = { x: number; y: number; label: 0 | 1 };
export type Preview = { mask_id: string; preview_url: string; bbox: number[]; area_pct: number };
export type SpriteKind = "character" | "object";
export type WorkerStatus = { kind: "mock" | "remote"; connected: boolean; ready?: boolean; gpu?: boolean; lama?: boolean; busy?: boolean; error?: string | null; url?: string };

async function call<T>(url: string, method = "GET", body?: unknown): Promise<T> {
  let r: Response;
  try {
    r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) });
  } catch {
    throw new Error("Не удалось связаться с сервером. Подождите несколько секунд и повторите действие.");
  }
  if (!r.ok) {
    const d = (await r.json().catch(() => ({}))).detail;
    throw new Error(typeof d === "string" ? d : d ? "Некорректный запрос" : `Ошибка ${r.status}`);
  }
  return r.json();
}
const S = (id: string) => `/api/scenes/${id}`;

export const health = () => call<{ worker: WorkerStatus }>("/api/health").then((h) => h.worker);
export const connectWorker = (url: string, token: string) => call<WorkerStatus>("/api/worker", "POST", { url, token });
export const disconnectWorker = () => call<WorkerStatus>("/api/worker", "DELETE");
export const savedScenes = () => call<{ scenes: Scene[] }>("/api/scenes");

export type People = "auto" | "yes" | "no";
export type Place = "auto" | "inside" | "outside";
export const generate = (prompt: string, people: People, place: Place = "auto") => call<Scene>("/api/scenes", "POST", { prompt, people, place });
export const segment = (id: string, points: Pt[]) => call<Preview>(`${S(id)}/segment`, "POST", { points });
export const extract = (id: string, mask_id: string) => call<Scene>(`${S(id)}/extract`, "POST", { mask_id });
export const saveState = (id: string, layers: Layer[]) => call<Scene>(`${S(id)}/state`, "PUT", { layers });
export const addSprite = (id: string, prompt: string, kind: SpriteKind) => call<Scene>(`${S(id)}/characters`, "POST", { prompt, kind });
export const replaceLayer = (id: string, lid: string, prompt: string, kind: SpriteKind) => call<Scene>(`${S(id)}/layers/${lid}/replace`, "POST", { prompt, kind });
export const flipLayer = (id: string, lid: string) => call<Scene>(`${S(id)}/layers/${lid}/flip`, "POST");
export const duplicateLayer = (id: string, lid: string) => call<Scene>(`${S(id)}/layers/${lid}/duplicate`, "POST");
export const undo = (id: string) => call<Scene>(`${S(id)}/undo`, "POST");
export const redo = (id: string) => call<Scene>(`${S(id)}/redo`, "POST");
export const exportUrl = (id: string) => `${S(id)}/export`;
export const blendLayer = (id: string, lid: string) => call<Scene>(`${S(id)}/layers/${lid}/blend`, "POST");
export const cleanBackground = (id: string, lid: string) => call<Scene>(`${S(id)}/layers/${lid}/matte`, "POST");
export const finalRender = (id: string) => call<{ url: string }>(`${S(id)}/render`, "POST");
export type PoseDef = { id: string; name: string; user: boolean; description?: string; preserve_hands?: boolean };
export type Rig = { base_url: string; w: number; h: number; frame: [number, number, number, number]; kp0: number[][]; kp: number[][]; method: "detector" | "silhouette"; protected?: number[][] };
export const listPoses = () => call<PoseDef[]>("/api/poses", "GET");
export const savePose = (name: string, kp0: number[][], kp: number[][]) => call<PoseDef>("/api/poses", "POST", { name, kp0, kp });
export const getRig = (id: string, lid: string, refit = false) => call<Rig>(`${S(id)}/layers/${lid}/rig${refit ? "?refit=true" : ""}`, "POST");
export const retargetPose = (id: string, lid: string, kp0: number[][], pose: string, strategy: "relative" | "absolute" = "relative", preserveHands = false) => call<{ kp: number[][] }>(`${S(id)}/layers/${lid}/rig/retarget`, "POST", { kp0, pose, strategy, preserve_hands: preserveHands }).then((r) => r.kp);
export const applyPose = (id: string, lid: string, kp0: number[][], kp: number[][], refine = false, strength = .25) => call<Scene>(`${S(id)}/layers/${lid}/pose/apply`, "POST", { kp0, kp, refine, strength });
export const resetPose = (id: string, lid: string) => call<Scene>(`${S(id)}/layers/${lid}/pose/reset`, "POST");
export const applyMeshPose = (id: string, lid: string, kp0: number[][], kp: number[][], protectedAreas: number[][]) => call<Scene>(`${S(id)}/layers/${lid}/pose/mesh/apply`, "POST", { kp0, kp, protected: protectedAreas });
export async function meshPosePreview(id: string, lid: string, kp0: number[][], kp: number[][], protectedAreas: number[][], signal?: AbortSignal): Promise<string> {
  const r = await fetch(`${S(id)}/layers/${lid}/pose/mesh/preview`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ kp0, kp, protected: protectedAreas }), signal });
  if (!r.ok) { const error = await r.json().catch(() => ({})); throw new Error(error.detail || `Ошибка ${r.status}`); }
  return URL.createObjectURL(await r.blob());
}
export async function posePreview(id: string, lid: string, kp0: number[][], kp: number[][], signal?: AbortSignal): Promise<string> {
  const r = await fetch(`${S(id)}/layers/${lid}/pose/preview`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ kp0, kp }), signal });
  if (!r.ok) throw new Error(`Ошибка ${r.status}`);
  return URL.createObjectURL(await r.blob());
}
export type Variant = { kind: "warp" | "repair" | "regen" | "edit"; url: string };
export const editPoseVariants = (id: string, lid: string, kp0: number[][], kp: number[][], action: string, n: number) => call<{ vid: string; note: string; items: Variant[] }>(`${S(id)}/layers/${lid}/pose/edit/variants`, "POST", { kp0, kp, action, n });
export type VariantsReq = { n: number; ip_scale: number; regen: boolean; polish: boolean; strength: number; text: string };
export const poseVariants = (id: string, lid: string, kp0: number[][], kp: number[][], o: VariantsReq) => call<{ vid: string; note: string; items: Variant[] }>(`${S(id)}/layers/${lid}/pose/variants`, "POST", { kp0, kp, ...o });
export const poseCommit = (id: string, lid: string, kp0: number[][], kp: number[][], vid: string, index: number) => call<Scene>(`${S(id)}/layers/${lid}/pose/commit`, "POST", { kp0, kp, vid, index });
