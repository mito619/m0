"""Download model groups. Run with GPU Python after model-paths.ps1."""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import urllib.request

ROOT = Path(os.environ.get('DND_MODEL_ROOT', str(Path(__file__).resolve().parents[1] / '.local')))

def download(url, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.is_file():
        print('EXISTS', target, flush=True)
        return
    temporary = target.with_suffix(target.suffix + '.partial')
    print('DOWNLOAD', url, flush=True)
    urllib.request.urlretrieve(url, temporary)
    temporary.replace(target)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--group', choices=['core', 'pose-edit', 'legacy', 'all'], default='core')
    parser.add_argument('--list', action='store_true', help='Print groups without downloading')
    args = parser.parse_args()
    if args.list:
        print('core: DreamShaper XL fp16, SAM2.1, LaMa, BiRefNet, ISNet, RU-EN, Keypoint R-CNN')
        print('pose-edit: FLUX.2-klein-4B pinned + MediaPipe HandLandmarker')
        print('legacy: Xinsir OpenPose SDXL + IP-Adapter Plus SDXL ViT-H')
        print('Storage:', ROOT)
        return
    os.environ.setdefault('HF_HOME', str(ROOT / 'huggingface'))
    os.environ.setdefault('TORCH_HOME', str(ROOT / 'torch-cache'))
    os.environ.setdefault('U2NET_HOME', str(ROOT / 'rembg'))
    from huggingface_hub import snapshot_download, hf_hub_download
    if args.group in ('core', 'all'):
        snapshot_download('Lykon/dreamshaper-xl-1-0', local_dir=str(ROOT / 'models/dreamshaper-xl'),
                          allow_patterns=['*.json', '*.txt', '*/*.json', '*/*.txt', '*/*.fp16.safetensors'])
        download('https://github.com/ultralytics/assets/releases/download/v8.4.0/sam2.1_b.pt', ROOT / 'models/sam2.1_b.pt')
        download('https://github.com/enesmsahin/simple-lama-inpainting/releases/download/v0.1.0/big-lama.pt', ROOT / 'models/big-lama.pt')
        from rembg import new_session
        import gc
        for name in ('birefnet-general', 'isnet-general-use'):
            session = new_session(name, providers=['CPUExecutionProvider'])
            del session
            gc.collect()
        snapshot_download('Helsinki-NLP/opus-mt-ru-en', allow_patterns=['*.json', '*.spm', 'pytorch_model.bin'])
        from torchvision.models.detection import KeypointRCNN_ResNet50_FPN_Weights
        weights = KeypointRCNN_ResNet50_FPN_Weights.DEFAULT.get_state_dict(progress=True, check_hash=True)
        del weights
    if args.group in ('pose-edit', 'all'):
        download('https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task', ROOT / 'models/hand_landmarker.task')
        subprocess.run([sys.executable, str(Path(__file__).with_name('download-pose-editor.py'))], check=True)
    if args.group in ('legacy', 'all'):
        snapshot_download('xinsir/controlnet-openpose-sdxl-1.0', allow_patterns=['config.json', 'diffusion_pytorch_model.safetensors'])
        for filename in ('models/image_encoder/config.json', 'models/image_encoder/model.safetensors', 'sdxl_models/ip-adapter-plus_sdxl_vit-h.safetensors'):
            hf_hub_download('h94/IP-Adapter', filename)
    print('DONE', args.group, flush=True)

if __name__ == '__main__':
    main()
