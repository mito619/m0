"""Download pinned official model files as verified, resumable HTTP ranges."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import time
import requests
from huggingface_hub import HfApi

REPO = "black-forest-labs/FLUX.2-klein-4B"
REVISION = "e7b7dc27f91deacad38e78976d1f2b499d76a294"
ROOT = Path(os.environ.get("DND_MODEL_ROOT", str(Path(__file__).resolve().parents[1] / ".local"))) / "models" / "flux2-klein-4b"
PROXY = os.environ.get("HTTPS_PROXY")
PROXIES = {"http": PROXY, "https": PROXY} if PROXY else {}
BLOCK = 16 * 1024 * 1024


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def fetch(url, path, start=None, end=None):
    for attempt in range(8):
        try:
            headers = {"Range": f"bytes={start}-{end}"} if start is not None else {}
            with requests.get(url, headers=headers, proxies=PROXIES,
                              stream=True, timeout=(20, 30)) as response:
                response.raise_for_status()
                if start is not None:
                    if response.status_code != 206 or not response.headers.get("Content-Range", "").startswith(f"bytes {start}-{end}/"):
                        raise ValueError("Server returned incorrect range")
                with path.open("wb") as f:
                    for chunk in response.iter_content(1024 * 1024):
                        f.write(chunk)
            if start is not None and path.stat().st_size != end - start + 1:
                raise ValueError("Partial range")
            return
        except Exception:
            if attempt == 7:
                raise
            time.sleep(min(attempt + 1, 5))


def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    info = HfApi().model_info(REPO, revision=REVISION, files_metadata=True)
    files = [f for f in info.siblings if f.rfilename == "model_index.json"
             or f.rfilename.startswith(("scheduler/", "tokenizer/", "text_encoder/", "transformer/", "vae/"))]
    total = sum(f.size for f in files)
    print("TOTAL", total, flush=True)
    manifest = {"repo": REPO, "revision": REVISION, "files": []}
    for entry in files:
        target = ROOT / entry.rfilename
        target.parent.mkdir(parents=True, exist_ok=True)
        sha = entry.lfs.sha256 if entry.lfs else None
        manifest["files"].append({"path": entry.rfilename, "size": entry.size, "sha256": sha})
        if target.exists() and target.stat().st_size == entry.size and (not sha or digest(target) == sha):
            print("CACHED", entry.rfilename, flush=True)
            continue
        source = f"https://huggingface.co/{REPO}/resolve/{REVISION}/{entry.rfilename}"
        if entry.size < BLOCK:
            fetch(source, target)
        else:
            parts = ROOT / ".download-parts" / entry.rfilename.replace("/", "_")
            parts.mkdir(parents=True, exist_ok=True)
            count = (entry.size + BLOCK - 1) // BLOCK
            def get(index):
                begin = index * BLOCK
                end = min(entry.size, begin + BLOCK) - 1
                part = parts / str(index)
                if not part.exists() or part.stat().st_size != end - begin + 1:
                    fetch(source + f"?range_part={index}", part, begin, end)
                return part.stat().st_size
            complete = 0
            with ThreadPoolExecutor(max_workers=8) as pool:
                for number, future in enumerate(as_completed([pool.submit(get, i) for i in range(count)]), 1):
                    complete += future.result()
                    if number % 16 == 0 or number == count:
                        print("PROGRESS", entry.rfilename, complete, entry.size, flush=True)
            staging = target.with_suffix(target.suffix + ".verified-download")
            with staging.open("wb") as out:
                for index in range(count):
                    with (parts / str(index)).open("rb") as src:
                        for chunk in iter(lambda: src.read(4 * 1024 * 1024), b""):
                            out.write(chunk)
            if staging.stat().st_size != entry.size or (sha and digest(staging) != sha):
                raise ValueError(f"Checksum mismatch: {entry.rfilename}")
            staging.replace(target)
        if target.stat().st_size != entry.size or (sha and digest(target) != sha):
            raise ValueError(f"Invalid file: {entry.rfilename}")
        print("VERIFIED", entry.rfilename, flush=True)
    (ROOT / "download-manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print("MODEL COMPLETE", ROOT, flush=True)


if __name__ == "__main__":
    main()
