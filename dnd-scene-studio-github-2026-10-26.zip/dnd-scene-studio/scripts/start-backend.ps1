$ErrorActionPreference = 'Stop'
$Repo = Split-Path $PSScriptRoot -Parent
$env:WORKER_URL = 'http://127.0.0.1:8000'
Set-Location (Join-Path $Repo 'backend')
& './.venv/Scripts/python.exe' -m uvicorn app.main:app --host 127.0.0.1 --port 8001
