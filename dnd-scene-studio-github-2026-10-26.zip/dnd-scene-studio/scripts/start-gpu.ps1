. "$PSScriptRoot/model-paths.ps1"
$Python = Join-Path $Repo '.venv-gpu/Scripts/python.exe'
if (!(Test-Path -LiteralPath $Python)) { throw 'Install .venv-gpu first; see README.md' }
Set-Location (Join-Path $Repo 'worker')
& $Python -m uvicorn server:app --host 127.0.0.1 --port 8000
