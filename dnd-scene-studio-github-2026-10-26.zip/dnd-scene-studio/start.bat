@echo off
rem Запуск на Windows: бэкенд (8001) + фронтенд (5173). Первый запуск ставит зависимости.
cd /d %~dp0
if not exist backend\.venv ( python -m venv backend\.venv && backend\.venv\Scripts\pip install -q -r backend\requirements.txt )
if not exist frontend\node_modules ( cd frontend && call npm install && cd .. )
start "backend" cmd /k "cd backend && .venv\Scripts\activate && uvicorn app.main:app --port 8001"
start "frontend" cmd /k "cd frontend && npm run dev -- --open"
