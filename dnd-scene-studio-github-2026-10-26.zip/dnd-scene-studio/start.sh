#!/usr/bin/env bash
# Запуск на Linux/macOS: бэкенд (8001) + фронтенд (5173).
set -e; cd "$(dirname "$0")"
[ -d backend/.venv ] || { python3 -m venv backend/.venv && backend/.venv/bin/pip install -q -r backend/requirements.txt; }
[ -d frontend/node_modules ] || (cd frontend && npm install)
(cd backend && .venv/bin/uvicorn app.main:app --port 8001) & BE=$!
trap "kill $BE" EXIT
cd frontend && npm run dev
