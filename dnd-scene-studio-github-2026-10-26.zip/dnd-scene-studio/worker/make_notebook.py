"""Собирает colab_worker.ipynb из server.py (единый источник правды). Запуск: python make_notebook.py"""
import json, pathlib
here = pathlib.Path(__file__).parent
src = (here / "server.py").read_text(encoding="utf-8")

def code(s): return {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": s.splitlines(True)}
def md(s): return {"cell_type": "markdown", "metadata": {}, "source": s.splitlines(True)}

launch = '''import os, re, secrets, subprocess, time, json, urllib.request
# безопасный перезапуск: гасим прежних сторожей и воркеры, иначе два процесса делят одну GPU и падают по памяти
subprocess.run("pkill -f '[w]hile true; do uvicorn'; pkill -f '[u]vicorn server:app'; pkill -f '[c]loudflared tunnel'; sleep 3", shell=True, executable="/bin/bash")
TOKEN = secrets.token_urlsafe(24)
env = {**os.environ, "WORKER_TOKEN": TOKEN}
# цикл-сторож: если процесс убьют (например, по памяти), воркер сам поднимется заново на том же адресе
subprocess.Popen("while true; do uvicorn server:app --port 8000 >> server.log 2>&1; echo '--- воркер перезапущен ---' >> server.log; sleep 3; done", shell=True, env=env, executable="/bin/bash")
print("Загружаю модели (первый раз 5-10 минут)...")
for i in range(240):
    time.sleep(5)
    try:
        h = json.load(urllib.request.urlopen("http://localhost:8000/health", timeout=3))
    except Exception:
        continue
    if h.get("error"): raise SystemExit("Ошибка загрузки моделей: " + h["error"])
    if h.get("ready"): break
else:
    print(open("server.log").read()[-2000:]); raise SystemExit("Воркер не поднялся")
subprocess.Popen("./cloudflared tunnel --url http://localhost:8000 > tunnel.log 2>&1", shell=True)
url = None
for _ in range(40):
    time.sleep(2)
    m = re.search(r"https://[-a-z0-9]+\\.trycloudflare\\.com", open("tunnel.log").read())
    if m: url = m.group(0); break
print("ГОТОВО. GPU:", h.get("gpu"), "| LaMa (зачистка фона):", h.get("lama"))
if not h.get("lama"): print("ВНИМАНИЕ: LaMa не загрузилась, фон будет зачищаться упрощённо. Смотрите server.log")
print("\\nВставьте в панель «GPU» в приложении:")
print("Адрес  =", url)
print("Токен  =", TOKEN)'''

nb = {"nbformat": 4, "nbformat_minor": 5,
      "metadata": {"accelerator": "GPU", "colab": {"gpuType": "T4"}, "kernelspec": {"name": "python3", "display_name": "Python 3"}},
      "cells": [
          md("# DnD Scene Studio — GPU-воркер\nGPU: **T4** (Runtime → Change runtime type). Затем **Run all**. Последняя ячейка выдаст адрес и токен, когда модели загружены. Их вставляют в панель «GPU» в приложении, бэкенд перезапускать не нужно."),
          code("!pip install -q fastapi uvicorn python-multipart ultralytics diffusers transformers accelerate safetensors sentencepiece 'rembg[cpu]'"),
          code("%%writefile server.py\n" + src),
          code("!wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -O cloudflared && chmod +x cloudflared"),
          code(launch)]}
(here / "colab_worker.ipynb").write_text(json.dumps(nb, ensure_ascii=False, indent=1), encoding="utf-8")
print("ok")
