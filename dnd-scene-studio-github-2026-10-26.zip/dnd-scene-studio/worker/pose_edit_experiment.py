"""Isolated image-edit experiment. Does not change scenes or start web servers.

Run with the separate diffusers overlay, not the production worker environment.
Encode and render run in separate processes so the 8 GB text encoder and
8 GB image transformer never occupy RAM together.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys


class PoseQualityRejected(Exception):
    pass


def embedding_metadata(args):
    return {"model": str(Path(args.model).resolve()), "prompt": prompt_for(args.action), "sequence_length": 384}


def prompt_for(action):
    return (
        "Edit the character in image 1. Image 2 is a pose guide only. "
        "Use the body pose in image 2 while keeping the SAME character from image 1: "
        "same face, hair and beard if present, body proportions, "
        "same clothes, cloak, boots, existing accessories and held objects, and art style. "
        f"Requested action: {action}. "
        "Unless that action explicitly changes the hands, keep BOTH original hands in their original grip on any held object. "
        "If the reference holds a musical instrument, keep both hands holding/playing it. "
        "Do NOT add a relaxed third arm or a hand on the knee while the original hands remain on the instrument. "
        "Move the original arms, never duplicate them. Each hand must belong to one of exactly two arms. "
        "Preserve the shape and strings of any existing instrument; do not turn it into a staff or weapon. "
        "Do not introduce objects absent from the reference. "
        "Keep the whole character and both boots inside the image, with some margin. "
        "One character, two arms, two legs, anatomically plausible hands. "
        "Plain neutral gray background, no pedestal, base, extra people or text. "
        "Do not draw the colored skeleton or guide in the output."
    )


def encode(args):
    import torch
    from diffusers import Flux2KleinPipeline

    pipe = Flux2KleinPipeline.from_pretrained(
        args.model, transformer=None, vae=None,
        torch_dtype=torch.bfloat16, local_files_only=True,
    )
    pipe.enable_sequential_cpu_offload()
    with torch.inference_mode():
        embeds, _ = pipe.encode_prompt(
            prompt=prompt_for(args.action), device=torch.device("cuda"),
            max_sequence_length=384,
        )
    embeddings_path = Path(args.embeddings)
    embeddings_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = embeddings_path.with_suffix(".tmp")
    torch.save(embeds.cpu(), temporary)
    temporary.replace(embeddings_path)
    metadata_path = embeddings_path.with_suffix(".meta.json")
    metadata_temporary = metadata_path.with_suffix(".tmp")
    metadata_temporary.write_text(json.dumps(embedding_metadata(args)), encoding="utf-8")
    metadata_temporary.replace(metadata_path)
    print("PROMPT ENCODED", flush=True)


def reference_rgb(path):
    from PIL import Image, ImageOps

    image = ImageOps.exif_transpose(Image.open(path)).convert("RGBA")
    bbox = image.getchannel("A").getbbox()
    if bbox:
        image = image.crop(bbox)
    image.thumbnail((768, 1024), Image.Resampling.LANCZOS)
    canvas = Image.new("RGBA", (768, 1024), (200, 200, 200, 255))
    canvas.alpha_composite(image, ((768 - image.width) // 2, (1024 - image.height) // 2))
    return canvas.convert("RGB")


def render(args):
    import torch
    from PIL import Image
    from diffusers import Flux2KleinPipeline

    pipe = Flux2KleinPipeline.from_pretrained(
        args.model, text_encoder=None, tokenizer=None,
        torch_dtype=torch.bfloat16, local_files_only=True,
    )
    pipe.enable_sequential_cpu_offload()
    pipe.vae.enable_tiling()
    pipe.vae.enable_slicing()
    embeds = torch.load(args.embeddings, map_location="cpu", weights_only=True)
    ref = reference_rgb(args.reference)
    guide = Image.open(args.guide).convert("RGB")
    guide.thumbnail((576, 768), Image.Resampling.LANCZOS)
    with torch.inference_mode():
        result = pipe(
            image=[ref, guide], prompt_embeds=embeds,
            height=args.height, width=args.width,
            num_inference_steps=4, guidance_scale=1.0,
            generator=torch.Generator("cpu").manual_seed(args.seed),
        ).images[0]
    from pose_quality import inspect
    hand_model = Path(args.model).parent / "hand_landmarker.task"
    quality = inspect(args.reference, result, hand_model)
    print("HAND CHECK", json.dumps(quality), flush=True)
    if quality["extra_hands"]:
        result.save(Path(args.output).with_name(f"rejected-{args.seed}.png"))
        raise PoseQualityRejected("More than two plausible hands detected")
    result.save(args.output)
    Path(args.output).with_suffix(".json").write_text(json.dumps({
        "model": str(args.model), "reference": str(args.reference),
        "guide": str(args.guide), "seed": args.seed,
        "prompt": prompt_for(args.action), "quality": quality, "experimental": True,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print("EXPERIMENT SAVED", args.output, flush=True)
    print("PEAK GPU MB", round(torch.cuda.max_memory_allocated() / 1024**2), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=["all", "encode", "render"])
    parser.add_argument("--model", required=True)
    parser.add_argument("--reference", required=True)
    parser.add_argument("--guide", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--action", required=True)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--width", type=int, default=512)
    parser.add_argument("--height", type=int, default=768)
    parser.add_argument("--embeddings")
    args = parser.parse_args()
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    if args.embeddings is None:
        args.embeddings = str(Path(args.output).with_suffix(".embeddings.pt"))
    for filename in (args.reference, args.guide):
        if not Path(filename).is_file():
            parser.error(f"Input image does not exist: {filename}")
    if args.stage == "all":
        rest = sys.argv[2:]
        metadata_file = Path(args.embeddings).with_suffix(".meta.json")
        cached = False
        if Path(args.embeddings).is_file() and metadata_file.is_file():
            cached = json.loads(metadata_file.read_text(encoding="utf-8")) == embedding_metadata(args)
        for stage in (["render"] if cached else ["encode", "render"]):
            subprocess.run([sys.executable, str(Path(__file__).resolve()), stage, *rest], check=True)
    elif args.stage == "encode":
        encode(args)
    else:
        render(args)


if __name__ == "__main__":
    try:
        main()
    except PoseQualityRejected as exc:
        print("POSE_QUALITY_REJECTED", str(exc), flush=True)
        sys.exit(42)
