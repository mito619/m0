"""Conservative extra-hand screen, not a complete anatomy/identity guarantee."""
from pathlib import Path
import numpy as np
from PIL import Image


def hand_detections(image, model):
    import mediapipe as mp
    from mediapipe.tasks import python
    from mediapipe.tasks.python import vision

    rgba = image.convert("RGBA")
    background = Image.new("RGBA", rgba.size, (200, 200, 200, 255))
    background.alpha_composite(rgba)
    pixels = np.asarray(background.convert("RGB"))
    height, width = pixels.shape[:2]
    # A hand wrapped around a narrow instrument neck is often missed in the
    # full frame. Overlapping crops recover it without generating new pixels.
    boxes = [(0, 0, width, height)] + [
        (int(x * width), int(y * height), int(min(1, x + .65) * width), int(min(1, y + .6) * height))
        for x in (0, .35) for y in (0, .25, .4)
    ]
    options = vision.HandLandmarkerOptions(
        base_options=python.BaseOptions(model_asset_path=str(model)), num_hands=4,
        min_hand_detection_confidence=.5, min_hand_presence_confidence=.5,
    )
    detections = []
    with vision.HandLandmarker.create_from_options(options) as detector:
        for x0, y0, x1, y1 in boxes:
            result = detector.detect(mp.Image(image_format=mp.ImageFormat.SRGB,
                data=np.ascontiguousarray(pixels[y0:y1, x0:x1])))
            for hand in result.hand_landmarks:
                points = np.array([(point.x * (x1 - x0) + x0, point.y * (y1 - y0) + y0) for point in hand])
                center = points[[0, 5, 9, 13, 17]].mean(axis=0)
                if any(np.linalg.norm(center - np.asarray(old["center"])) < .055 * max(width, height) for old in detections):
                    continue
                extent = np.ptp(points, axis=0)
                detections.append({"center": center.tolist(), "area": float(np.prod(extent) / height**2)})
    return detections


def assess(reference_hands, candidate_hands):
    # Very small leather tassels can resemble a tiny fist. Calibrate plausible
    # hand size against this reference, rather than a fixed skin-color rule.
    reference_sizes = sorted((hand["area"] for hand in reference_hands), reverse=True)[:2]
    minimum_size = max(.0008, .4 * min(reference_sizes)) if reference_sizes else .0008
    significant = [hand for hand in candidate_hands if hand["area"] >= minimum_size]
    return {"reference_hands_detected": len(reference_hands), "candidate_hands_detected": len(significant),
            "extra_hands": len(significant) > 2, "minimum_hand_area": minimum_size,
            "limited_check": True}


def inspect(reference_path, result, model_path):
    model = Path(model_path)
    if not model.is_file():
        raise RuntimeError("The hand-check model is missing")
    return assess(hand_detections(Image.open(reference_path), model), hand_detections(result, model))
