"""GPU-воркер: генерация (diffusers), сегментация по точкам (SAM), зачистка фона (LaMa).

Запуск: WORKER_TOKEN=секрет uvicorn server:app --port 8000

Принципы:
- все тяжёлые операции идут под одним локом: GPU одна, параллельные запросы встают в очередь;
- эмбеддинг картинки в SAM считается один раз на image_id, а последующие клики стоят ~десятки мс;
- LaMa (big-lama, TorchScript) грузится напрямую через torch.jit, без pip-пакетов с жёсткими пинами;
  если не загрузилась, inpaint честно откатывается на cv2 (в /health видно lama=false).
"""
import gc, hashlib, io, json, os, re, subprocess, sys, tempfile, threading, urllib.request
from pathlib import Path
os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")  # меньше фрагментации VRAM
os.environ.setdefault("OMP_NUM_THREADS", "4")
import numpy as np, torch
from fastapi import FastAPI, Form, Header, HTTPException, UploadFile
from urllib.parse import quote

from fastapi.responses import JSONResponse, Response
from PIL import Image
from pydantic import BaseModel

TOKEN = os.getenv("WORKER_TOKEN", "")
T2I_MODEL = os.getenv("T2I_MODEL", "Lykon/dreamshaper-xl-1-0")  # дообученный SDXL: лучше слушается фэнтези-описаний
SAM_WEIGHTS = os.getenv("SAM_WEIGHTS", "sam2.1_b.pt")  # "sam3.pt" после получения доступа к весам
LAMA_URL = os.getenv("LAMA_URL", "https://github.com/enesmsahin/simple-lama-inpainting/releases/download/v0.1.0/big-lama.pt")
LAMA_PATH = os.getenv("LAMA_PATH", os.path.expanduser("~/.cache/dnd/big-lama.pt"))
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
OFFLOAD = os.getenv("T2I_OFFLOAD", "0") == "1"  # 1 = веса SDXL в RAM (медленнее и жрёт 7 ГБ RAM; нужно только при нехватке VRAM)

app, _cache = FastAPI(), {}
GPU = threading.Lock()  # одна тяжёлая задача за раз


def vram_report():
    """Сколько видеопамяти занято и какими моделями (общие веса считаются один раз)."""
    if not torch.cuda.is_available():
        return None
    gb = lambda b: round(b / 2**30, 2)
    seen, models = set(), {}
    for name, obj in list(_cache.items()):
        comps = getattr(obj, "components", None)
        for m in (comps.values() if isinstance(comps, dict) else [obj]):
            if not hasattr(m, "parameters"):
                continue
            try:
                for p_ in m.parameters():
                    if p_.is_cuda and p_.data_ptr() not in seen:
                        seen.add(p_.data_ptr()); models[name] = models.get(name, 0) + p_.numel() * p_.element_size()
            except Exception:
                pass
    free, total = torch.cuda.mem_get_info()
    return {"free_gb": gb(free), "total_gb": gb(total), "allocated_gb": gb(torch.cuda.memory_allocated()),
            "reserved_gb": gb(torch.cuda.memory_reserved()), "models_gb": {k: gb(v) for k, v in models.items()}}


@app.exception_handler(Exception)
async def any_error(request, exc):
    """Любая ошибка воркера возвращается текстом (виден в интерфейсе), а не безликим «Internal Server Error»."""
    import traceback; traceback.print_exc()
    msg = (f"Не хватило видеопамяти GPU. Отчёт: {vram_report()}" if isinstance(exc, torch.OutOfMemoryError)
           else f"{type(exc).__name__}: {str(exc)[:300]}")
    return JSONResponse({"detail": msg}, status_code=500)


def auth(token: str | None):
    if TOKEN and token != TOKEN:
        raise HTTPException(401, "bad token")


# ───────────────────────────── модели ─────────────────────────────
def free_mem():
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


def local_first(loader, *args, **kwargs):
    """Use downloaded weights without a network HEAD request on every mode switch."""
    try:
        return loader(*args, local_files_only=True, **kwargs)
    except OSError:
        return loader(*args, local_files_only=False, **kwargs)


def configure_pipeline(pipe):
    if DEVICE == "cpu":
        pipe.to("cpu")
    elif OFFLOAD:
        if os.getenv("T2I_SEQUENTIAL_OFFLOAD", "0") == "1":
            pipe.enable_sequential_cpu_offload()
        else:
            pipe.enable_model_cpu_offload()
    else:
        pipe.to("cuda")
    pipe.vae.enable_tiling(); pipe.vae.enable_slicing()
    return pipe


def load_pipeline(key, cls, **extra):
    if _cache.get(key) is None:
        # Pipelines created with from_pipe share modules and offload hooks.
        # Keep one owner instead, so switching modes cannot leave meta weights
        # or IP-Adapter projections attached to another cached pipeline.
        for name in ("t2i", "inp", "i2i", "ad", "ip_enc", "rembg"):
            _cache.pop(name, None)
        free_mem()
        pipe = local_first(cls.from_pretrained, T2I_MODEL, torch_dtype=torch.float16, variant="fp16",
                                   use_safetensors=True, low_cpu_mem_usage=True, **extra)
        _cache[key] = configure_pipeline(pipe)
    return _cache[key]


def t2i():
    from diffusers import AutoPipelineForText2Image
    return load_pipeline("t2i", AutoPipelineForText2Image)


def sam_predictor():
    """SAM2Predictor с кэшем эмбеддинга. Возвращает None, если API недоступно (тогда fallback на SAM())."""
    if "sam_pred" not in _cache:
        try:
            from ultralytics.models.sam import SAM2Predictor, Predictor
            ov = dict(conf=0.25, task="segment", mode="predict", imgsz=1024, model=SAM_WEIGHTS, save=False, verbose=False)
            pred = (SAM2Predictor if "sam2" in SAM_WEIGHTS else Predictor)(overrides=ov)
            try:  # прогрев: грузим веса сейчас, а не на первом клике
                pred.set_image(Image.new("RGB", (256, 256)))
            except Exception as e:
                print("SAM warmup skipped:", repr(e), flush=True)
            _cache["sam_pred"] = pred
        except Exception as e:
            print("SAM predictor unavailable, fallback to SAM():", repr(e), flush=True)
            _cache["sam_pred"] = None
    return _cache["sam_pred"]


def sam_simple():
    if "sam" not in _cache:
        from ultralytics import SAM
        _cache["sam"] = SAM(SAM_WEIGHTS)
    return _cache["sam"]


def lama():
    """big-lama TorchScript. None, если загрузить не удалось."""
    if "lama" not in _cache:
        try:
            if not os.path.exists(LAMA_PATH):
                os.makedirs(os.path.dirname(LAMA_PATH), exist_ok=True)
                urllib.request.urlretrieve(LAMA_URL, LAMA_PATH + ".part"); os.replace(LAMA_PATH + ".part", LAMA_PATH)
            _cache["lama"] = torch.jit.load(LAMA_PATH, map_location=DEVICE).eval()
        except Exception as e:
            print("LaMa unavailable, inpaint will use cv2:", repr(e), flush=True)
            _cache["lama"] = None
    return _cache["lama"]


def matter():
    """Модель удаления фона (rembg/isnet). None, если не установилась."""
    if "rembg" not in _cache:
        try:
            from rembg import new_session
            import onnxruntime as ort
            options = ort.SessionOptions()
            options.enable_cpu_mem_arena = False
            options.enable_mem_pattern = False
            model = os.getenv("MATTE_MODEL", "birefnet-general")
            try:
                _cache["rembg"] = new_session(model, sess_opts=options)
            except Exception:
                if model == "isnet-general-use":
                    raise
                print("BiRefNet unavailable, using ISNet", flush=True)
                _cache["rembg"] = new_session("isnet-general-use", sess_opts=options)
            _cache["matte_available"] = True
        except Exception as e:
            print("rembg unavailable, sprites will use SAM:", repr(e), flush=True); _cache["rembg"] = None
    return _cache["rembg"]


def inpaint_pipe():
    from diffusers import AutoPipelineForInpainting
    return load_pipeline("inp", AutoPipelineForInpainting)


class ip_adapter:
    """IP-Adapter (образец внешности): на время вызова подключается к общему unet и после снимается, чтобы остальные
    операции (генерация, поза, вписывание) работали как раньше. Если не загрузился, работаем без него: .ok == False."""
    def __init__(self, pipe, scale: float | dict):
        self.pipe, self.scale, self.ok = pipe, scale, False

    def __enter__(self):
        try:
            # Materialise offloaded weights before adding/removing modules.
            self.pipe.remove_all_hooks()
            self.pipe.to("cpu")
            if "ip_enc" not in _cache:
                from transformers import CLIPVisionModelWithProjection
                _cache["ip_enc"] = local_first(CLIPVisionModelWithProjection.from_pretrained,
                    "h94/IP-Adapter", subfolder="models/image_encoder", torch_dtype=torch.float16)
            self.pipe.register_modules(image_encoder=_cache["ip_enc"])
            local_first(self.pipe.load_ip_adapter, "h94/IP-Adapter", subfolder="sdxl_models", weight_name="ip-adapter-plus_sdxl_vit-h.safetensors",
                                      image_encoder_folder=None)
            self.pipe.set_ip_adapter_scale(self.scale)
            configure_pipeline(self.pipe)
            self.ok = True
        except Exception as e:
            print("ip-adapter unavailable:", repr(e), flush=True)
            self._off()
            raise HTTPException(503, "Не удалось подключить образец внешности: " + str(e)[:200]) from e
        return self

    def _off(self):
        try:
            self.pipe.remove_all_hooks()
            self.pipe.to("cpu")
            self.pipe.unload_ip_adapter()
            self.pipe.register_modules(image_encoder=None)
            configure_pipeline(self.pipe)
        except Exception as e:
            print("ip-adapter unload:", repr(e), flush=True)

    def __exit__(self, *a):
        if self.ok:
            self._off()
        free_mem()


def _ref_image(ref: UploadFile | None, face_crop: bool = True):
    """Образец внешности: RGBA-спрайт на нейтральном фоне, квадрат."""
    if ref is None:
        return None
    r = Image.open(ref.file).convert("RGBA")
    # Reference the face and upper costume, not the original hands-on-waist
    # stance; otherwise a strong IP-Adapter recreates those old hands.
    bounds = r.getchannel("A").getbbox()
    if bounds and face_crop:
        x0, y0, x1, y1 = bounds
        r = r.crop((x0, y0, x1, min(y1, y0 + max(32, int((y1 - y0) * .36)))))
    bg = Image.new("RGBA", r.size, (200, 200, 200, 255)); bg.alpha_composite(r)
    side = max(r.size); sq = Image.new("RGB", (side, side), (200, 200, 200)); sq.paste(bg.convert("RGB"), ((side - r.width) // 2, (side - r.height) // 2))
    return sq.resize((512, 512), Image.LANCZOS)


def pose_pipe():
    """Own a ControlNet pipeline: stronger skeleton control than the light adapter."""
    if _cache.get("ad") is None:
        try:
            from diffusers import StableDiffusionXLControlNetPipeline, ControlNetModel, EulerAncestralDiscreteScheduler
            control = ControlNetModel.from_pretrained("xinsir/controlnet-openpose-sdxl-1.0", torch_dtype=torch.float16,
                                                       use_safetensors=True, local_files_only=True)
            pipe = load_pipeline("ad", StableDiffusionXLControlNetPipeline, controlnet=control)
            pipe.scheduler = EulerAncestralDiscreteScheduler.from_config(pipe.scheduler.config)
        except Exception as e:
            print("pose control unavailable:", repr(e), flush=True); _cache["ad"] = None
        free_mem()
    return _cache["ad"]


_ARMED = re.compile(r"fire|flame|torch|sword|staff|weapon|axe|spear|magic|glow|огон|пламя|факел|меч|посох|оруж|топор|копь|магия|шар|свет", re.I)


def neg_for(kind: str, *texts, avoid: str = "") -> str:
    """Негативный запрос. Персонажу без упоминания огня/оружия запрещаем их: иначе нейросеть дорисовывает меч и пламя сама."""
    n = NEG[kind]
    if kind == "character" and not _ARMED.search(" ".join(texts)):
        n += ", fire, flames, torch, sword, weapon, staff, glowing orb"
    return n + (", " + avoid if avoid else "")


def png_response(img, text: str):
    buf = io.BytesIO(); img.save(buf, "PNG")
    return Response(buf.getvalue(), media_type="image/png", headers={"X-Prompt": quote(text[:500])})


def to_en(text: str) -> str:
    """SDXL понимает английский: русские описания переводим (Marian, на CPU)."""
    if not re.search("[а-яА-ЯёЁ]", text):
        return text
    try:
        if "tr" not in _cache:
            from transformers import MarianMTModel, MarianTokenizer
            name = "Helsinki-NLP/opus-mt-ru-en"
            _cache["tr"] = (local_first(MarianTokenizer.from_pretrained, name), local_first(MarianMTModel.from_pretrained, name))
        tok, mdl = _cache["tr"]
        out = mdl.generate(**tok([text], return_tensors="pt", truncation=True), max_new_tokens=200)
        translated = tok.decode(out[0], skip_special_tokens=True)
        # Marian can translate fantasy race names as honorifics (гном -> Mr.).
        if re.search(r"\bгном[а-яё]*", text, re.I) and not re.search(r"dwarf|gnome", translated, re.I):
            translated = "dwarf, " + translated
        return translated
    except Exception:
        return text


# ───────────────────────────── генерация ─────────────────────────────
STYLE = ", dungeons and dragons fantasy art, highly detailed, dramatic lighting, digital painting"
ISOLATED = ", plain light gray background, no scenery"
KIND = {
    "scene": ", wide establishing shot of the location, atmospheric",
    "scene_people": ", wide shot of the location with characters in it, detailed characters, atmospheric",
    "character": ", solo, head to boots, plain light gray background, no scenery",
    "object": ", single object, isolated item, whole object fully visible" + ISOLATED,
}
NEG = {
    "scene": "text, watermark, blurry, deformed, people, person, characters, figures, isometric, diorama, miniature, 3d render, cutaway, white background",
    "scene_people": "text, watermark, blurry, deformed, extra limbs, bad anatomy, mutated hands, extra fingers, empty room, isometric, diorama, miniature, tilt-shift, 3d render, cutaway, white background",
    "character": "pedestal, plinth, display base, oval base, figurine, statue, miniature, toy, text, watermark, blurry, deformed, extra arms, extra hands, extra limbs, cropped, multiple people, character sheet, multiple views, grid, collage, panels, duplicate character, busy background, floor tiles, walls, scenery, cast shadow",
    "object": "text, watermark, blurry, deformed, cropped, people, person, busy background, shadows on floor, floor tiles, ground plane, walls, scenery, cast shadow",
}


class Gen(BaseModel):
    prompt: str
    width: int = 1024
    height: int = 768
    seed: int | None = None
    kind: str = "scene"
    hint: str = ""
    avoid: str = ""  # что НЕ рисовать (добавляется к негативному запросу)


@app.post("/generate")
def generate(g: Gen, x_token: str | None = Header(None)):
    auth(x_token)
    kind = g.kind if g.kind in KIND else "scene"
    gen = torch.Generator("cpu").manual_seed(g.seed) if g.seed is not None else None
    with GPU:
        # The CPU matting session can hold large temporary buffers. Generation
        # needs that RAM for offloaded SDXL weights; reload matting on demand.
        _cache.pop("rembg", None)
        free_mem()
        en = to_en(g.prompt)
        if re.search(r"gnome|dwarf|halfling", en, re.I):  # SDXL любит рисовать их высокими
            en += ", short stocky body proportions, small stature"
        lead = "several detailed characters, " if kind == "scene_people" else ""  # без слова scene: SDXL рисует изометрические диорамы
        if kind == "character":
            lead = "One living fantasy character, full body, both boots visible, "
            if re.search(r"lute|лютн", en + " " + g.prompt, re.I):
                lead += "holding a wooden lute with both hands, clearly visible musical instrument, "
        text = lead + en + (", " + g.hint if g.hint else "") + KIND[kind] + (", fantasy illustration" if kind in ("character", "object") else STYLE)
        print("PROMPT:", text, flush=True)

        def draw():
            negative = neg_for(kind, g.prompt, en, avoid=g.avoid)
            if kind == "character" and re.search(r"lute|лютн|guitar|гитар", g.prompt + " " + en, re.I):
                negative += ", empty hands, hands on hips"
            return t2i()(text, negative_prompt=negative, width=g.width // 8 * 8, height=g.height // 8 * 8,
                         num_inference_steps=30, generator=gen).images[0]
        try:
            img = draw()
        except torch.cuda.OutOfMemoryError:  # не хватило VRAM: один раз переключаемся на режим с выгрузкой в RAM
            print("CUDA OOM: SDXL переключён на cpu offload", flush=True)
            free_mem(); _cache["t2i"].to("cpu"); _cache["t2i"].enable_model_cpu_offload(); free_mem()
            img = draw()
        finally:
            free_mem()
    return png_response(img, text)


# ───────────────────────────── сегментация ─────────────────────────────
def _first_mask(res) -> np.ndarray | None:
    if res.masks is None or len(res.masks.data) == 0:
        return None
    m = res.masks.data[0].cpu().numpy().astype(np.uint8) * 255
    return m if m.any() else None


def _segment(img: Image.Image, image_id: str, points, labels, box) -> np.ndarray | None:
    """Пробуем по очереди: предиктор с кэшем -> обычный SAM(). Подсказки: точки (+/-) и/или рамка."""
    pts = [[[float(x), float(y)] for x, y in points]] if points else None
    lbl = [[int(v) for v in labels]] if points else None
    kw = {}
    if pts: kw.update(points=pts, labels=lbl)
    if box: kw["bboxes"] = [float(v) for v in box]

    pred = sam_predictor()
    if pred is not None:
        try:
            if _cache.get("sam_img") != image_id:
                pred.set_image(img); _cache["sam_img"] = image_id
            m = _first_mask(pred(**kw)[0])
            if m is not None:
                return m
        except Exception as e:
            _cache["sam_img"] = None
            print("SAM predictor error:", repr(e), flush=True)
    try:
        return _first_mask(sam_simple()(img, verbose=False, **kw)[0])
    except Exception as e:
        print("SAM error:", repr(e), flush=True)
        return None


@app.post("/segment")
def segment(image_id: str = Form(...), points: str = Form("[]"), labels: str = Form("[]"),
            box: str | None = Form(None), image: UploadFile | None = None,
            x_token: str | None = Header(None)):
    """points = JSON [[x,y],...], labels = JSON [1,0,...] (1 = «это объект», 0 = «это не он»).
    Если image_id воркеру неизвестен и картинка не приложена, отвечаем 409 need_image."""
    auth(x_token)
    pts, lbl = json.loads(points), json.loads(labels)
    if len(pts) != len(lbl):
        raise HTTPException(400, "points/labels разной длины")
    with GPU:
        if _cache.get("img_id") != image_id:
            if image is None:
                raise HTTPException(409, "need_image")
            _cache["img"], _cache["img_id"] = Image.open(image.file).convert("RGB"), image_id
        img = _cache["img"]
        mask = _segment(img, image_id, pts, lbl, [float(v) for v in box.split(",")] if box else None)
        if mask is None and pts and lbl[0] == 1 and len(pts) == 1:  # крайний случай: клик мимо, пробуем рамку вокруг
            x, y = pts[0]; mask = _segment(img, image_id, None, None, [x - 48, y - 48, x + 48, y + 48])
        free_mem()
    if mask is None:
        raise HTTPException(422, "Объект не найден, кликните точнее")
    out = Image.fromarray(mask).resize(img.size, Image.NEAREST)
    buf = io.BytesIO(); out.save(buf, "PNG")
    return Response(buf.getvalue(), media_type="image/png")


# ───────────────────────────── inpaint ─────────────────────────────
def lama_inpaint(rgb: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """rgb HxWx3 uint8, mask HxW uint8 (>0 = закрасить). Возвращает HxWx3 uint8."""
    h, w = mask.shape
    ph, pw = (-h) % 8, (-w) % 8  # модель требует кратность 8
    img = np.pad(rgb, ((0, ph), (0, pw), (0, 0)), mode="symmetric")
    msk = np.pad((mask > 0).astype(np.float32), ((0, ph), (0, pw)), mode="symmetric")
    t_img = torch.from_numpy(img.astype(np.float32) / 255).permute(2, 0, 1)[None].to(DEVICE)
    t_msk = torch.from_numpy(msk)[None, None].to(DEVICE)
    with torch.inference_mode():
        out = _cache["lama"](t_img, t_msk)[0].permute(1, 2, 0).cpu().numpy()
    return np.clip(out * 255, 0, 255).astype(np.uint8)[:h, :w]


@app.post("/inpaint")
def inpaint(image: UploadFile, mask: UploadFile, x_token: str | None = Header(None)):
    auth(x_token)
    rgb = np.array(Image.open(image.file).convert("RGB"))
    m = np.array(Image.open(mask.file).convert("L"))
    if m.shape != rgb.shape[:2]:
        raise HTTPException(400, "маска и картинка разного размера")
    with GPU:
        engine = "lama" if lama() is not None else "telea"
        if engine == "lama":
            out = lama_inpaint(rgb, m)
        else:
            import cv2
            out = cv2.cvtColor(cv2.inpaint(cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR), (m > 0).astype(np.uint8) * 255, 5, cv2.INPAINT_TELEA), cv2.COLOR_BGR2RGB)
        free_mem()
    buf = io.BytesIO(); Image.fromarray(out).save(buf, "PNG")
    return Response(buf.getvalue(), media_type="image/png", headers={"X-Inpaint-Engine": engine})


# ───────────────────────────── фон и позы ─────────────────────────────
@app.post("/matte")
def matte(image: UploadFile, x_token: str | None = Header(None)):
    """Маска переднего плана (мягкая, 0..255) моделью удаления фона."""
    auth(x_token)
    img = Image.open(image.file).convert("RGB")
    with GPU:
        # Matting and diffusion are separate stages; do not retain both models'
        # CPU working sets on machines with limited RAM/commit space.
        for key in ("t2i", "i2i", "inp", "ad", "ip_enc"):
            _cache.pop(key, None)
        free_mem()
        sess = matter()
        if sess is None:
            raise HTTPException(501, "rembg unavailable")
        from rembg import remove
        try:
            m = remove(img, session=sess, only_mask=True)
        finally:
            _cache.pop("rembg", None)
            del sess
            free_mem()
    buf = io.BytesIO(); m.convert("L").save(buf, "PNG")
    return Response(buf.getvalue(), media_type="image/png")


@app.post("/pose")
def pose(skeleton: UploadFile, prompt: str = Form(...), hint: str = Form(""), seed: int | None = Form(None),
         ref: UploadFile | None = None, ip_scale: float = Form(.75), x_token: str | None = Header(None)):
    """Персонаж в заданной позе: SDXL + ControlNet OpenPose, тот же seed и описание."""
    auth(x_token)
    skel = Image.open(skeleton.file).convert("RGB").resize((768, 1024))
    gen = torch.Generator("cpu").manual_seed(seed) if seed is not None else None
    with GPU:
        pipe = pose_pipe()
        if pipe is None:
            raise HTTPException(503, "Модель управления позой ещё не скачана. Для первой загрузки нужен рабочий VPN; после установки она работает локально.")
        en = to_en(prompt)
        if re.search(r"gnome|dwarf|halfling", en, re.I):
            en += ", short stocky body proportions, small stature"
        text = "Full body, head to boots, entire person visible, facing viewer, " + en + KIND["character"] + ", fantasy illustration" + (", " + hint if hint else "")
        print("POSE PROMPT:", text, flush=True)
        refimg = _ref_image(ref, face_crop=False)
        ipc = ip_adapter(pipe, {"up": {"block_0": [0.0, min(max(ip_scale, .2), 1.0), 0.0]}}) if refimg is not None else None
        if ipc is not None:
            ipc.__enter__()
        def run():
            kw = dict(prompt=text, negative_prompt=neg_for("character", prompt, en, avoid="crossed arms, hands on hips, back view" if re.search(r"attack|атак|cast|колду|wave|машет", prompt, re.I) else ""), image=skel, controlnet_conditioning_scale=1.15,
                      width=skel.width // 8 * 8, height=skel.height // 8 * 8, num_inference_steps=30, generator=gen)
            if ipc is not None and ipc.ok:
                kw["ip_adapter_image"] = refimg
            return pipe(**kw).images[0]
        free_mem()
        if torch.cuda.is_available():
            print("VRAM свободно перед позой, ГБ:", round(torch.cuda.mem_get_info()[0] / 2**30, 1), flush=True)
        try:
            try:
                img = run()
            except torch.OutOfMemoryError:  # один повтор после очистки кэша
                print("pose OOM: повтор после очистки", flush=True); free_mem(); img = run()
        finally:
            if ipc is not None:
                ipc.__exit__()
            free_mem()
    return png_response(img, text)



# ───────────────────────────── скелет и доработка кукольной деформации ─────────────────────────────
def keypoint_model():
    """Детектор ключевых точек тела (torchvision Keypoint R-CNN, COCO-17). Лицензия весов позволяет коммерческое использование."""
    if "kpr" not in _cache:
        try:
            from torchvision.models.detection import keypointrcnn_resnet50_fpn
            m = keypointrcnn_resnet50_fpn(weights="DEFAULT", box_score_thresh=.05, box_detections_per_img=5).eval().to(DEVICE)
            _cache["kpr"] = m
        except Exception as e:
            print("keypoint model unavailable:", repr(e), flush=True); _cache["kpr"] = None
    return _cache["kpr"]


# COCO: 0 нос,1 л.глаз,2 п.глаз,3 л.ухо,4 п.ухо,5 л.плечо,6 п.плечо,7 л.локоть,8 п.локоть,9 л.кисть,10 п.кисть,
#       11 л.бедро,12 п.бедро,13 л.колено,14 п.колено,15 л.стопа,16 п.стопа
# OpenPose-18: 0 нос,1 шея,2 п.плечо,3 п.локоть,4 п.кисть,5 л.плечо,6 л.локоть,7 л.кисть,8 п.бедро,9 п.колено,10 п.стопа,
#              11 л.бедро,12 л.колено,13 л.стопа,14 п.глаз,15 л.глаз,16 п.ухо,17 л.ухо
_OP_FROM_COCO = [0, None, 6, 8, 10, 5, 7, 9, 12, 14, 16, 11, 13, 15, 2, 1, 4, 3]


@app.post("/skeleton")
def skeleton(image: UploadFile, x_token: str | None = Header(None)):
    """Скелет персонажа на RGBA-спрайте: 18 точек в пикселях и уверенность каждой (0..1). Пусто, если человека не нашли."""
    auth(x_token)
    rgba = Image.open(image.file).convert("RGBA")
    bg = Image.new("RGBA", rgba.size, (128, 128, 128, 255)); bg.alpha_composite(rgba)
    with GPU:
        m = keypoint_model()
        if m is None:
            raise HTTPException(501, "Детектор скелета не загрузился: смотрите server.log")
        t = torch.from_numpy(np.array(bg.convert("RGB"))).permute(2, 0, 1).float().div(255).to(DEVICE)
        with torch.inference_mode():
            r = m([t])[0]
        free_mem()
    if len(r["scores"]) == 0:
        return JSONResponse({"found": False})
    i = int(r["scores"].argmax())
    k = r["keypoints"][i].cpu().numpy(); sc = torch.sigmoid(r["keypoints_scores"][i]).cpu().numpy()
    pts, conf = [], []
    for c in _OP_FROM_COCO:
        if c is None:
            pts.append(((k[5, :2] + k[6, :2]) / 2).tolist()); conf.append(float(min(sc[5], sc[6])))
        else:
            pts.append(k[c, :2].tolist()); conf.append(float(sc[c]))
    return {"found": True, "score": float(r["scores"][i]), "kp": pts, "conf": conf}


@app.post("/refine")
def refine(image: UploadFile, prompt: str = Form(""), strength: float = Form(.4), seed: int | None = Form(None),
           hint: str = Form(""), x_token: str | None = Header(None)):
    """Доработка деформированного спрайта: SDXL img2img с малой силой убирает артефакты швов и дорисовывает складки.
    Поза и силуэт задаются входной картинкой, поэтому персонаж остаётся тем же. Возвращает RGBA."""
    auth(x_token)
    rgba = Image.open(image.file).convert("RGBA")
    a0 = np.array(rgba)[..., 3]
    ys, xs = np.nonzero(a0 > 8)
    if len(xs) == 0:
        raise HTTPException(400, "пустой спрайт")
    pad = int(.08 * max(rgba.size))
    box = (max(xs.min() - pad, 0), max(ys.min() - pad, 0), min(xs.max() + pad + 1, rgba.width), min(ys.max() + pad + 1, rgba.height))
    crop = rgba.crop(box)
    k = 1024 / max(crop.size)  # SDXL работает хорошо около 1024 px по большей стороне
    W, H = (max(64, int(round(crop.width * k / 8)) * 8), max(64, int(round(crop.height * k / 8)) * 8))
    bg = Image.new("RGBA", crop.size, (200, 200, 200, 255)); bg.alpha_composite(crop)
    init = bg.convert("RGB").resize((W, H), Image.LANCZOS)
    gen = torch.Generator("cpu").manual_seed(seed) if seed is not None else None
    with GPU:
        from diffusers import AutoPipelineForImage2Image
        pipe = load_pipeline("i2i", AutoPipelineForImage2Image)
        en = to_en(prompt) if prompt.strip() else "fantasy character"
        text = en + (", " + hint if hint else "") + KIND["character"] + ", fantasy illustration"
        try:
            out = pipe(prompt=text, negative_prompt=neg_for("character", prompt, en), image=init,
                                strength=min(max(strength, .15), .7), num_inference_steps=30, guidance_scale=6.0, generator=gen).images[0]
        finally:
            free_mem()
        del pipe
        _cache.pop("i2i", None)
        free_mem()
        sess = matter()
        if sess is not None:
            from rembg import remove
            m = remove(out, session=sess, only_mask=True).convert("L")
        else:
            m = None
    out = out.resize(crop.size, Image.LANCZOS)
    alpha = crop.getchannel("A") if m is None else m.resize(crop.size, Image.LANCZOS)
    if m is not None:  # маску не расширяем за пределы исходного силуэта более чем на пару пикселей: поза уже задана
        import cv2
        a = np.array(alpha); base = cv2.dilate(np.array(crop.getchannel("A")), np.ones((9, 9), np.uint8))
        alpha = Image.fromarray(np.minimum(a, base))
    res = out.convert("RGBA"); res.putalpha(alpha)
    full = Image.new("RGBA", rgba.size, (0, 0, 0, 0)); full.paste(res, box[:2])
    buf = io.BytesIO(); full.save(buf, "PNG")
    return Response(buf.getvalue(), media_type="image/png")



@app.post("/repair")
def repair(image: UploadFile, mask: UploadFile, ref: UploadFile | None = None, prompt: str = Form(""), hint: str = Form(""),
           seed: int | None = Form(None), ip_scale: float = Form(.6), strength: float = Form(.95), x_token: str | None = Header(None)):
    """Починка стыков после деформации: нейросеть перерисовывает ТОЛЬКО маску (дыры, согнутые суставы, недостающие конечности),
    остальные пиксели персонажа остаются как были. Образец внешности (IP-Adapter) удерживает тот же костюм и лицо. Возвращает RGBA."""
    auth(x_token)
    import cv2
    rgba = Image.open(image.file).convert("RGBA"); m0 = np.array(Image.open(mask.file).convert("L"))
    if m0.shape != (rgba.height, rgba.width):
        raise HTTPException(400, "маска и картинка разного размера")
    a0 = np.array(rgba)[..., 3]
    gray = Image.new("RGBA", rgba.size, (200, 200, 200, 255)); gray.alpha_composite(rgba)
    k = 1024 / max(rgba.size)
    W, H = max(64, int(round(rgba.width * k / 8)) * 8), max(64, int(round(rgba.height * k / 8)) * 8)
    init = gray.convert("RGB").resize((W, H), Image.LANCZOS)
    mk = Image.fromarray(((m0 > 0) * 255).astype(np.uint8)).resize((W, H), Image.NEAREST)
    gen = torch.Generator("cpu").manual_seed(seed) if seed is not None else None
    with GPU:
        pipe = inpaint_pipe()
        en = to_en(prompt) if prompt.strip() else "fantasy character"
        text = en + ", same character and clothes" + (", " + hint if hint else "") + KIND["character"] + ", fantasy illustration"
        refimg = _ref_image(ref)
        try:
            with ip_adapter(pipe, min(max(ip_scale, .2), 1.0)) as ip:
                kw = dict(prompt=text, negative_prompt=neg_for("character", prompt, en), image=init, mask_image=mk,
                          strength=min(max(strength, .5), 1.0), num_inference_steps=30, guidance_scale=6.0,
                          padding_mask_crop=24, generator=gen)
                if ip.ok and refimg is not None:
                    kw["ip_adapter_image"] = refimg
                try:
                    out = pipe(**kw).images[0]
                except torch.OutOfMemoryError:
                    print("repair OOM: повтор после очистки", flush=True); free_mem(); out = pipe(**kw).images[0]
                used_ip = ip.ok and refimg is not None
        finally:
            free_mem()
        out = out.convert("RGB").resize(rgba.size, Image.LANCZOS)
        del pipe, ip
        _cache.pop("inp", None)
        _cache.pop("ip_enc", None)
        free_mem()
        sess = matter()
        alpha_m = None
        if sess is not None:
            from rembg import remove
            alpha_m = np.array(remove(out, session=sess, only_mask=True).convert("L"))
    soft = cv2.GaussianBlur(((m0 > 0) * 255).astype(np.uint8), (0, 0), 2.0).astype(np.float32)[..., None] / 255
    rgb = np.array(out).astype(np.float32) * soft + np.array(gray.convert("RGB")).astype(np.float32) * (1 - soft)
    near = cv2.dilate(((m0 > 0) * 255).astype(np.uint8), np.ones((7, 7), np.uint8))
    if alpha_m is not None:  # в зоне починки прозрачность берём у модели удаления фона, за её пределами не трогаем
        alpha_weight = cv2.GaussianBlur((m0 > 0).astype(np.float32), (0, 0), 2.)
        a = np.clip(a0 * (1 - alpha_weight) + alpha_m * alpha_weight, 0, 255).astype(np.uint8)
    else:
        a = np.maximum(a0, ((m0 > 0) * 255).astype(np.uint8))
    res = np.dstack([np.clip(rgb, 0, 255).astype(np.uint8), a])
    # исходные пиксели вне маски возвращаем без потерь от ресайза
    keep = soft[..., 0] < .01
    res[keep, :3] = np.array(rgba)[keep, :3]
    buf = io.BytesIO(); Image.fromarray(res, "RGBA").save(buf, "PNG")
    return Response(buf.getvalue(), media_type="image/png", headers={"X-IP": "1" if used_ip else "0"})


# ───────────────────────────── вписывание ─────────────────────────────
@app.post("/harmonize")
def harmonize(image: UploadFile, mask: UploadFile, prompt: str = Form(""), strength: float = Form(.5), hint: str = Form(""),
              seed: int | None = Form(None), x_token: str | None = Header(None)):
    """Inpaint SDXL с малой силой по маске вокруг вставленных объектов: свет, тени, стыки. Вне маски ничего не меняется."""
    auth(x_token)
    img = Image.open(image.file).convert("RGB"); m = Image.open(mask.file).convert("L")
    if m.size != img.size:
        raise HTTPException(400, "маска и картинка разного размера")
    gen = torch.Generator("cpu").manual_seed(seed) if seed is not None else None
    with GPU:
        text = to_en(prompt) + (", " + hint if hint else "") + ", characters seamlessly integrated into the scene, lit by the scene light, cast shadows on the ground, color graded to match" + STYLE
        try:
            out = inpaint_pipe()(prompt=text, negative_prompt="text, watermark, blurry, deformed, extra limbs",
                                image=img, mask_image=m, strength=min(max(strength, .15), .7), num_inference_steps=30,
                                guidance_scale=6.0, padding_mask_crop=48, generator=gen).images[0]
        finally:
            free_mem()
    buf = io.BytesIO(); out.resize(img.size).save(buf, "PNG")
    return Response(buf.getvalue(), media_type="image/png")


# ───────────────────────────── служебное ─────────────────────────────
def pose_edit_paths():
    model = Path(os.getenv("POSE_EDIT_MODEL", "models/flux2-klein-4b")).resolve()
    packages = Path(os.getenv("POSE_EDIT_PACKAGES", "pose-edit-packages")).resolve()
    available = ((model / "download-manifest.json").is_file() and (packages / "diffusers").is_dir()
                 and (packages / "mediapipe").is_dir() and (model.parent / "hand_landmarker.task").is_file())
    return model, packages, available


@app.post("/pose-edit")
def edit_character_pose(image: UploadFile, guide: UploadFile, action: str = Form(""),
                        seed: int = Form(42), x_token: str | None = Header(None)):
    """Edit the supplied character using a pose guide, in an isolated low-memory runner."""
    auth(x_token)
    model, packages, available = pose_edit_paths()
    if not available:
        raise HTTPException(503, "Новый редактор позы ещё не установлен: нужны веса FLUX.2 Klein и отдельные зависимости.")
    if not torch.cuda.is_available():
        raise HTTPException(503, "Для нового редактора позы нужна подключённая GPU.")
    if len(action) > 1500:
        raise HTTPException(400, "Слишком длинное описание действия")
    with GPU:
        for name in ("t2i", "inp", "i2i", "ad", "ip_enc", "rembg", "sam", "sam_pred", "sam_img", "lama", "kpr"):
            _cache.pop(name, None)
        free_mem()
        translated = to_en(action.strip()) if action.strip() else "Follow the pose guide while preserving the reference character."
        from pose_edit_experiment import prompt_for
        temp_root = Path(os.getenv("TEMP", tempfile.gettempdir())).resolve()
        temp_root.mkdir(parents=True, exist_ok=True)
        job = Path(tempfile.mkdtemp(prefix="dnd-pose-edit-", dir=temp_root)).resolve()
        cache = temp_root / "dnd-pose-prompt-cache"
        cache.mkdir(exist_ok=True)
        cache_key = hashlib.sha256((str(model) + prompt_for(translated) + "384-v1").encode()).hexdigest()
        ref_path, guide_path, output = job / "reference.png", job / "guide.png", job / "output.png"
        Image.open(image.file).convert("RGBA").save(ref_path)
        Image.open(guide.file).convert("RGB").save(guide_path)
        env = os.environ.copy()
        env["PYTHONPATH"] = str(packages)
        env["HF_HUB_OFFLINE"] = "1"
        env["TRANSFORMERS_OFFLINE"] = "1"
        embeddings_path = cache / f"{cache_key}.pt"
        metadata_path = embeddings_path.with_suffix(".meta.json")
        cached = False
        if embeddings_path.is_file() and metadata_path.is_file():
            try:
                cached = json.loads(metadata_path.read_text(encoding="utf-8")) == {
                    "model": str(model), "prompt": prompt_for(translated), "sequence_length": 384}
            except (OSError, ValueError):
                pass
        command = [sys.executable, str(Path(__file__).with_name("pose_edit_experiment.py")), "render",
                   "--model", str(model), "--reference", str(ref_path), "--guide", str(guide_path),
                   "--output", str(output), "--action", translated, "--seed", str(seed),
                   "--embeddings", str(embeddings_path)]
        try:
            for stage in (["render"] if cached else ["encode", "render"]):
                command[2] = stage
                for attempt in range(3 if stage == "render" else 1):
                    command[command.index("--seed") + 1] = str((seed + 1009 * attempt) % 2**31)
                    result = subprocess.run(command, env=env, capture_output=True, text=True, encoding="utf-8",
                                            errors="replace", timeout=180 if stage == "encode" else 220,
                                            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
                    print("POSE EDIT", stage, attempt, result.stdout[-3000:], result.stderr[-3000:], flush=True)
                    if result.returncode == 42:
                        if attempt < 2:
                            continue
                        raise HTTPException(503, "Проверка обнаружила возможные лишние кисти в трёх вариантах. Вариант не применён. Уточните действие и попробуйте ещё раз.")
                    if result.returncode:
                        raise HTTPException(503, "Новый редактор не завершил обработку: " + result.stderr[-700:])
                    break
            if not output.is_file():
                raise HTTPException(503, "Новый редактор не вернул изображение. Исходный персонаж сохранён.")
            return Response(output.read_bytes(), media_type="image/png", headers={"X-Pose-Engine": "flux2-klein-4b", "X-Pose-Quality": "hands-v1"})
        except subprocess.TimeoutExpired as exc:
            raise HTTPException(503, "Обработка новой позы заняла слишком много времени. Исходный персонаж сохранён.") from exc
        finally:
            free_mem()
            # Only our explicitly created job's known files are removed.
            if job.parent == temp_root:
                for name in ("reference.png", "guide.png", "output.png", "output.json"):
                    (job / name).unlink(missing_ok=True)
                try:
                    job.rmdir()
                except OSError:
                    pass


@app.on_event("startup")
def preload():
    if os.getenv("WORKER_PRELOAD", "1") == "0":
        _cache["ready"] = True
        return
    def go():
        threading.Event().wait(6)  # даём uvicorn занять порт: лишний процесс с занятым портом не должен успеть залезть в VRAM
        try:
            with GPU:
                to_en("привет"); t2i(); sam_predictor(); lama(); matter(); keypoint_model()
                _cache.pop("rembg", None)
                free_mem()
                _cache["ready"] = True
        except Exception as e:  # причина видна в /health
            _cache["error"] = repr(e)
    threading.Thread(target=go, daemon=True).start()


@app.get("/health")
def health():
    return {"ok": True, "gpu": torch.cuda.is_available(), "ready": _cache.get("ready", False),
            "lama": _cache.get("lama") is not None, "matte": _cache.get("matte_available", False), "busy": GPU.locked(), "error": _cache.get("error"),
            "vram_used_mb": int(torch.cuda.memory_allocated() / 2**20) if torch.cuda.is_available() else 0,
            "pose_loaded": _cache.get("ad") is not None, "skeleton": _cache.get("kpr") is not None,
            "vram": vram_report(),
            "offload": OFFLOAD, "pose_edit": pose_edit_paths()[2]}
